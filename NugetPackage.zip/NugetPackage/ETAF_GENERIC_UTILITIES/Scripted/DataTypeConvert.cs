﻿using System;
using System.Collections.Generic;
using System.Text;

namespace etaf.generic.utilities
{
    public class ConvertDataType
    {

        public static object ConvertedData;
        public static object DataTypeConvert(object ToConvertData, String ToDataType)
        {
            //object ConvertedData;

            switch (ToDataType.ToUpper())
            {
                case "INT64":

                    ConvertedData = (Int64)Convert.ChangeType(ToConvertData, typeof(Int64));

                    break;

                case "INT32":

                    ConvertedData = (Int32)Convert.ChangeType(ToConvertData, typeof(Int32));

                    break;

                case "LONG":

                    //actual = (long)ToConvertData;

                    ConvertedData = (long)Convert.ChangeType(ToConvertData, typeof(long));

                    break;

                case "STRING":

                    //actual = (string)jObject.SelectToken(lukout);

                    if (ToConvertData != null) ToConvertData = ToConvertData.ToString().Trim();

                    ConvertedData = (string)ToConvertData;

                    break;
            }

            return ConvertedData;

        }
    }
}
