﻿using Newtonsoft.Json;
using System;
using System.IO;
using TechTalk.SpecFlow;

namespace etaf.generic.utilities.Custom_Functions
{
    public class Gen_Utilities
    {
        public static int RandomID(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public static string GetDataFromTable(Table Table, Int32 RowIndex, Int32 ColumnIndex) // function can be used with Specflow table
        {
            string Result = Table.Rows[RowIndex][ColumnIndex].ToString();

            return Result.ToUpper();
        }
    }
}
