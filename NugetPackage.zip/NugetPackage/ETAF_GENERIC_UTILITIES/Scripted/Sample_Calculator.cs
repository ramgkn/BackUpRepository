﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace etaf.generic.utilities
{
    public class Sample_Calculator
    {
        public static int FirstNumber { get; set; }
        public static int SecondNumber { get; set; }

        public static int Add()
        {
            return FirstNumber + SecondNumber;
        }

        public static int Substract()
        {
            return FirstNumber - SecondNumber;
        }
        public static int Multiply()
        {
            return FirstNumber * SecondNumber;
        }
    }
}
