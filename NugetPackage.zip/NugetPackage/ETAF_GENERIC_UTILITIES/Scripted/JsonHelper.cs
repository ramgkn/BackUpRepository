﻿using Newtonsoft.Json;
using System.IO;
using TechTalk.SpecFlow;

namespace etaf.generic.utilities.Custom_Functions
{
    public class CreateJsonRequest
    {
        private static string jsonString;

        
        public static string WithTemplate(string TemplatePath,Table table)
        {

            jsonString = File.ReadAllText(TemplatePath);
            
            foreach (var rws in table.Rows)
            {
                
                jsonString = jsonString.Replace("$" + ((string[])rws.Values)[0], ((string[])rws.Values)[1]);

            }

            return jsonString;

        }


    }
    
}
