﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ETAF_WEB_UTILITIES.Scripted.Web
{
    public class SeleniumContext
    {

        public SeleniumContext(BrowserType browserType, String DriverPath, [Optional] String NodeUrl)
        {

            switch (browserType)
            {

                case BrowserType.CHROME:

                    var chromeoptions = new ChromeOptions();

                    chromeoptions.AddAdditionalCapability(CapabilityType.AcceptSslCertificates, true, true);

                    chromeoptions.AddArgument("ignore-certificate-errors");

                    WebDriver = new ChromeDriver(DriverPath, chromeoptions);

                    break;

                case BrowserType.CHROMEHEADLESS:

                    ChromeOptions option = new ChromeOptions();

                    option.AddAdditionalCapability("browser", "Chrome", true);

                    option.AcceptInsecureCertificates = true;

                    option.AddArgument("--headless");

                    WebDriver = new ChromeDriver(DriverPath, option);

                    break;

                case BrowserType.FIREFOX:

                    FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(DriverPath, "geckodriver.exe");

                    service.FirefoxBinaryPath = @"C:\Program Files\Mozilla Firefox\firefox.exe";

                    service.HideCommandPromptWindow = true;

                    service.SuppressInitialDiagnosticInformation = true;

                    WebDriver = new FirefoxDriver(service);

                    break;

                case BrowserType.RM_IE:

                    InternetExplorerOptions Options = new InternetExplorerOptions();

                    Options.AddAdditionalCapability(CapabilityType.AcceptInsecureCertificates, true);

                    WebDriver = new RemoteWebDriver(new Uri(NodeUrl), Options);

                    break;

                case BrowserType.RM_EDGE:

                    EdgeOptions edgOptions = new EdgeOptions();

                    edgOptions.AcceptInsecureCertificates = true;

                    //edgOptions.AddAdditionalCapability(CapabilityType.AcceptInsecureCertificates, true);

                    WebDriver = new RemoteWebDriver(new Uri(NodeUrl), edgOptions);

                    break;

                case BrowserType.RM_CHROME:

                    ChromeOptions rm_chromeoptions = new ChromeOptions();

                    rm_chromeoptions.AddArgument("ignore-certificate-errors");

                    //rm_chromeoptions.AcceptInsecureCertificates = true;

                    rm_chromeoptions.AddAdditionalCapability("browser", "Chrome", true);

                    WebDriver = new RemoteWebDriver(new Uri(NodeUrl), rm_chromeoptions);

                    break;

                case BrowserType.RM_FIREFOX:

                    FirefoxOptions rm_firefoxOptions = new FirefoxOptions();

                    //rm_firefoxOptions.AcceptInsecureCertificates = true;

                    rm_firefoxOptions.AddArgument("ignore-certificate-errors");

                    WebDriver = new RemoteWebDriver(new Uri(NodeUrl), rm_firefoxOptions);

                    break;

                case BrowserType.RM_CHROMEHEADLESS:

                    ChromeOptions rm_chromeheadless = new ChromeOptions();

                    rm_chromeheadless.AcceptInsecureCertificates = true;

                    rm_chromeheadless.AddArgument("--headless");

                    rm_chromeheadless.AddAdditionalCapability("browser", "Chrome", true);

                    WebDriver = new RemoteWebDriver(new Uri(NodeUrl), rm_chromeheadless);

                    break;


                default:
                    WebDriver = new ChromeDriver(DriverPath);

                    break;
            }


            WebDriver.Manage().Window.Maximize();

        }

        public enum BrowserType
        {
            CHROME,
            CHROMEHEADLESS,
            FIREFOX,
            RM_CHROME,
            RM_EDGE,
            RM_IE,
            RM_FIREFOX,
            RM_CHROMEHEADLESS
        }
        //public IWebDriver WebDriver { get; private set; }
        public RemoteWebDriver WebDriver { get; private set; }
    }
}
