﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;


using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace ETAF_WEB_UTILITIES.Scripted.Web
{
    public class WebHandlers
    {
        public static Actions action = new Actions(LaunchBrowsers.driver);
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static IWebElement getElement(IWebDriver driver, By locator)
        {
            IWebElement element = driver.FindElement(locator);
            return element;
        }

        public static By webElementToBy(IWebElement webEle)
        {
            if (webEle == null) throw new NullReferenceException();

            var attributes =
                ((IJavaScriptExecutor)LaunchBrowsers.driver).ExecuteScript(
                    "var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;",
                    webEle) as Dictionary<string, object>;
            if (attributes == null) throw new NullReferenceException();

            var selector = "//" + webEle.TagName;
            selector = attributes.Aggregate(selector, (current, attribute) =>
                 current + "[@" + attribute.Key + "='" + attribute.Value + "']");

            return By.XPath(selector);
        }

        public static void enterText(IWebElement locator, String value)
        {
            try
            {
                locator.SendKeys(value);
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }

        public static void divSpanListBox(IWebElement locator, String value)
        {
            try
            {
                WebWaitHelper.waitForElement(locator);
                locator.Click();
                IReadOnlyCollection<IWebElement> listSpan = locator.FindElements(By.TagName("span"));
                foreach (IWebElement span in listSpan.ToList<IWebElement>())
                {
                    if (span.Text.Trim().ToLower().Equals(value.ToLower()))
                    {
                        span.Click();
                        break;
                    }
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }

        public static void click(IWebElement locator)
        {
            try
            {
                // Need to add the assertions when we decide the reporting
                WebWaitHelper.waitForElement(locator);
                IWebDriver driver = LaunchBrowsers.driver;
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
                locator.Click();
                LaunchBrowsers.pageWait();
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.Message);                
                try
                {
                    locator.Click();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                    throw new WebAutomationException(locator, ex.Message);
                }
                log.Error(e.Message);
                throw new WebAutomationException(locator, e.Message);
            }
        }
        public static void clickForLogout(IWebElement locator)
        {
            try
            {
                // Need to add the assertions when we decide the reporting
                locator.Click();
                LaunchBrowsers.pageWait();
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.Message);                
                try
                {
                    locator.Click();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                    throw new WebAutomationException(locator, ex.Message);
                }
                log.Error(e.Message);
                throw new WebAutomationException(locator, e.Message);
            }
        }

        public static void clickByJsExecutor(By locator)
        {
            try
            {

            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }

        public static bool verifyText(IWebElement locator, String strVText)
        {
            bool vflag = true;
            String actualText = "";
            try
            {
                if (locator.TagName.Equals("select"))
                {
                    SelectElement seleObj = new SelectElement(locator);
                    actualText = seleObj.SelectedOption.Text.Trim();
                    vflag = compareText(actualText, strVText);
                }
                else
                {
                    WebWaitHelper.waitForElementPresence(locator);
                    actualText = locator.Text;
                    if (String.IsNullOrEmpty(actualText))
                    {
                        actualText = locator.GetAttribute("innerText");
                        if (String.IsNullOrEmpty(actualText))
                        {
                            actualText = locator.GetAttribute("value");
                            vflag = compareText(actualText, strVText);
                        }
                        else
                        {
                            vflag = compareText(actualText, strVText);
                        }

                    }
                    else
                    {
                        vflag = compareText(actualText, strVText);
                    }
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return vflag;
        }

        public static bool compareText(String strActualText, String strCompText)
        {
            bool compFlag = false;
            try
            {
                if (strActualText.Equals(strCompText))
                {
                    compFlag = true;
                }
                else
                {
                    compFlag = false;
                    Console.WriteLine(strActualText + "doesnot match with" + strCompText);
                    //System.out.println(strActualText + "doesnot match with" + strCompText);// Jiju This will not work
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return compFlag;
        }

        public static bool existText(IWebElement locator)
        {
            bool flag = true;
            try
            {
                WebWaitHelper.waitForElement(locator);
                if ((String.IsNullOrEmpty(locator.GetAttribute("value"))))
                    flag = false;
                else
                    flag = true;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return flag;
        }

        public static void clearText(IWebElement locator)
        {
            try
            {
                WebWaitHelper.waitForElement(locator);
                locator.Clear();
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }

        public static bool objDisabled(IWebElement locator)
        {
            bool eFlag = false;
            try
            {
                if (!locator.Enabled)
                {
                    eFlag = true;
                }
                else
                {
                    eFlag = false;
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return eFlag;
        }

        public static String fetchPropertyVal(IWebElement locator, String property)
        {
            String propValue = "";
            try
            {
                propValue = locator.GetAttribute(property).ToString();
                return propValue;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return propValue;
            }
        }

        public void verifyProperty(IWebElement locator, String property, String expected)
        {
            String actual = "";
            try
            {
                actual = fetchPropertyVal(locator, property);
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                throw new WebAutomationException(locator, e.Message);//Jiju Need to check
            }
            if (!expected.Equals(actual))
            {
                throw new WebAutomationException(locator, expected, actual);
            }
        }

        public static void doubleClick(IWebElement locator)
        {
            try
            {
                WebWaitHelper.waitForElement(locator);
                action.DoubleClick(locator).Perform();
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }

        }

        public static void rightClick(IWebElement locator)
        {
            try
            {
                WebWaitHelper.waitForElement(locator);
                action.ContextClick(locator).Perform();
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }

        public static bool chkboxIsChecked(IWebElement locator)
        {
            WebWaitHelper.waitForElement(locator);
            bool eFlag = false;
            try
            {
                if (locator.Selected)
                {
                    eFlag = true;
                }
                else
                {
                    eFlag = false;
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return eFlag;
            }
            return eFlag;
        }

        public static bool radiobtnNotChecked(IWebElement locator)
        {
            WebWaitHelper.waitForElementPresence(locator);
            bool eFlag = false;
            try
            {
                if (!locator.Selected)
                {
                    eFlag = true;
                }
                else
                {
                    eFlag = false;
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return eFlag;
            }
            return eFlag;
        }

        public static bool radioBtnIsSelected(IWebElement locator)
        {
            WebWaitHelper.waitForElementPresence(locator);

            bool eFlag = false;
            try
            {
                if (locator.Selected)
                {
                    eFlag = true;
                }
                else
                {
                    eFlag = false;
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return eFlag;
            }
            return eFlag;

        }

        public static bool radioBtnIsNotSelected(IWebElement locator)
        {
            WebWaitHelper.waitForElementPresence(locator);
            bool eFlag = false;
            try
            {
                if (!locator.Selected)
                {
                    eFlag = true;
                }
                else
                {
                    eFlag = false;
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return eFlag;
            }
            return eFlag;

        }

        public static Dictionary<int, string> sltCtrlReadAllVal(IWebElement locator) // Jiju Need to check the functionality
        {
            Dictionary<int, string> comboValuesMap = new Dictionary<int, string>();
            try
            {
                WebWaitHelper.waitForElement(locator);
                comboValuesMap = new Dictionary<int, string>();

                SelectElement dropdown = new SelectElement(locator);
                List<IWebElement> lstValues = dropdown.Options.ToList();

                for (int j = 0; j < lstValues.Count(); j++)
                {
                    comboValuesMap[j] = lstValues[j].Text;
                }
                Console.WriteLine(comboValuesMap);
                return comboValuesMap;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return comboValuesMap;
            }
        }

        public static String dropDownGetCurrentSelection(IWebElement locator)
        {
            String cmbSelectedValue = "";
            try
            {
                WebWaitHelper.waitForElement(locator);
                SelectElement seleObj = new SelectElement(locator);
                cmbSelectedValue = seleObj.SelectedOption.Text.Trim();
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return cmbSelectedValue;
            }
            return cmbSelectedValue;
        }

        public static void dropDownSelectByIndex(IWebElement locator, int index)
        {
            try
            {
                WebWaitHelper.waitForElement(locator);
                String cmbSelectedValue = "";
                SelectElement dropdown = new SelectElement(locator);
                List<IWebElement> cmbOptions = dropdown.Options.ToList();
                cmbSelectedValue = cmbOptions[index].Text;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }

        private static bool IsElementPresent(By by)
        {
            try
            {
                LaunchBrowsers.driver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public static bool dropDownSetByVal(IWebElement locator, String value)
        {
            bool flag = false;
            try
            {
                WebWaitHelper.waitForElement(locator);
                SelectElement dropdown = new SelectElement(locator);
                List<IWebElement> cmbOptions = dropdown.Options.ToList();
                for (int i = 0; i <= cmbOptions.Count; i++)
                {
                    if (value.ToLower().Equals(cmbOptions[i].Text.ToLower()))
                    {
                        dropdown.SelectByIndex(i);
                        flag = true;
                        break;
                    }
                }
                return flag;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return flag;
            }

            #region Old code
            //bool flag = false;
            //try
            //{
            //    List<IWebElement> cmbOptions = (List<IWebElement>)locator.FindElement(By.XPath("//*[@id='ui']/div/div[2]/div[2]/div/div[2]/form/div[6]/div[2]/div/div/div[2]")).FindElements(By.ClassName("item")).ToList();

            //    for (int i = 1; i <= cmbOptions.Count; i++)
            //    {
            //        if (IsElementPresent((By.TagName("span"))))
            //        {
            //            string webEl = cmbOptions[i].FindElement(By.TagName("span")).GetAttribute("textContent");
            //            if (value.ToLower().Equals(webEl.ToLower()))
            //            {
            //                SelectElement seSelected = new SelectElement(cmbOptions[i]);
            //                seSelected.SelectByIndex(i);
            //                flag = true;
            //                break;
            //            }
            //        }
            //        else
            //        {
            //            if (value.ToLower().Equals(cmbOptions[i].Text.ToLower()))
            //            {
            //                SelectElement seSelected = new SelectElement(cmbOptions[i]);
            //                seSelected.SelectByIndex(i);
            //                flag = true;
            //                break;
            //            }
            //        }



            //    }
            //    return flag;
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //    return flag;
            //    //Console.WriteLine(e.Message);
            //}
            //return flag; 
            #endregion
        }

        public static bool dropDownSetByIndex(IWebElement locator, int index)
        {
            bool flag = false;
            try
            {
                WebWaitHelper.waitForElement(locator);
                SelectElement dropdown = new SelectElement(locator);
                List<IWebElement> cmbOptions = dropdown.Options.ToList();
                for (int i = 0; i <= cmbOptions.Count; i++)
                {
                    if (!string.IsNullOrEmpty(cmbOptions[i].Text))
                    {
                        dropdown.SelectByIndex(index);
                        flag = true;
                        break;
                    }
                }
                return flag;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return flag;

            #region Old code
            //bool flag = false;
            //try
            //{
            //    WebWaitHelper.waitForElement(locator);

            //    List<IWebElement> cmbOptions = (List<IWebElement>)locator.FindElement(By.TagName("option"));
            //    for (int i = 0; i <= cmbOptions.Count; i++)
            //    {
            //        if (!(cmbOptions[1].Text == string.Empty))
            //        {
            //            SelectElement seSelected = new SelectElement(cmbOptions[i]);
            //            seSelected.SelectByIndex(index);
            //            flag = true;
            //            break;
            //        }
            //    }
            //    return flag;
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //    return flag;
            //    //Console.WriteLine(e.Message);
            //}
            ////return flag; 
            #endregion
        }

        public void switchToFrame(IWebElement locator)// Jiju need to check
        {
            String actual = "";
            try
            {
                //actual = String.valueOf(locator.isDisplayed());
                actual = locator.Displayed.ToString();

                LaunchBrowsers.driver.SwitchTo().Frame(locator);
                if (actual == null)
                    throw new WebAutomationException(locator, "Switch to Frame", "Frame not Found");
                actual = actual.Trim().ToLower();
            }
            catch (WebAutomationException e)
            {
                log.Error(e.Message);
                throw new WebAutomationException(locator, e.Message);
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                throw new WebAutomationException(locator, e.Message);
            }
        }

        public void swithBackFromFrame()
        {
            try
            {
                LaunchBrowsers.driver.SwitchTo().DefaultContent();
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                throw new WebAutomationException(e.Message);               
            }
        }

        public static bool multiDeselectByText(IWebElement locator, String options)
        {
            bool flag = false;
            ArrayList optionList = null;
            try
            {
                WebWaitHelper.waitForElement(locator);
                optionList = optionsSplit(options);
                for (int i = 0; i < optionList.Count; i++)
                {
                    SelectElement multiple = new SelectElement(locator);
                    multiple.DeselectByText(optionList[i].ToString());

                }

                flag = true;
                return flag;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return flag;

            #region OLD
            //bool flag = false;
            //ArrayList optionList = null;
            //try
            //{
            //    WebWaitHelper.waitForElement(locator);
            //    SelectElement seMultiple = new SelectElement(locator);
            //    List<IWebElement> cmbOptions = (List<IWebElement>)locator.FindElement(By.TagName("option"));

            //    optionList = optionsSplit(options);
            //    for (int index = 0; index < optionList.Count; index++)
            //    {
            //        for (int i = 0; i <= cmbOptions.Count; i++)
            //        {
            //            if (!(cmbOptions[1].Text == optionList[i].ToString()))
            //            {
            //                seMultiple.DeselectByText(optionList[i].ToString());
            //                flag = true;
            //                break;
            //            }
            //        }
            //    }

            //    flag = true;
            //    return flag;
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //    return flag;
            //    //Console.WriteLine(e.Message);
            //} 
            #endregion
        }

        public static bool multiDeselectAll(IWebElement locator)
        {
            bool flag = false;
            try
            {
                WebWaitHelper.waitForElement(locator);
                SelectElement multiple = new SelectElement(locator);
                multiple.DeselectAll();
                flag = true;
                return flag;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return flag;
                //Console.WriteLine(e.Message);
            }
            //return flag;

        }

        public static bool multiSelectByText(IWebElement locator, String options)
        {
            bool flag = false;
            ArrayList optionList = null;
            try
            {
                WebWaitHelper.waitForElement(locator);
                optionList = optionsSplit(options);
                for (int i = 0; i < optionList.Count; i++)
                {
                    SelectElement multiple = new SelectElement(locator);
                    multiple.SelectByText(optionList[i].ToString());
                }
                flag = true;
                return flag;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return flag;
            }


        }

        public static bool multiSelectByIndex(IWebElement locator, String indexes)
        {
            bool flag = false;
            ArrayList indexList = null;
            try
            {
                WebWaitHelper.waitForElement(locator);
                indexList = optionsSplit(indexes);
                ArrayList intList = new ArrayList(indexList.OfType<int>().ToArray());

                SelectElement multiple = new SelectElement(locator);
                for (int i = 0; i < intList.Count; i++)
                {

                    multiple.SelectByIndex((int)intList[i]);
                }

                flag = true;
                return flag;

            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return flag;
            }
        }

        public static ArrayList optionsSplit(String options)
        {
            ArrayList tempOptionList = null;
            try
            {
                String[] items = options.Split(':');
                tempOptionList = new ArrayList(items);
                return tempOptionList;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
                return tempOptionList;
            }

        }

        public static Dictionary<String, int> getTblHeaderVal(IWebElement locator)
        {
            Dictionary<String, int> headermap = new Dictionary<String, int>();
            try
            {
                WebWaitHelper.waitForElement(locator);
                IWebElement mytableHead = locator.FindElement(By.TagName("thead"));
                List<IWebElement> rowsTable = mytableHead.FindElements(By.TagName("tr")).ToList<IWebElement>();
                for (int row = 0; row < rowsTable.Count; row++)
                {
                    List<IWebElement> colRow = rowsTable[row].FindElements(By.TagName("th")).ToList<IWebElement>();
                    for (int column = 0; column < colRow.Count; column++)
                    {
                        headermap[colRow[column].Text] = column;
                    }
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return headermap;
        }

        public static Dictionary<String, int> getTblBodyVal(IWebElement locator)
        {
            Dictionary<String, int> bodymap = new Dictionary<String, int>();
            try
            {
                WebWaitHelper.waitForElement(locator);
                IWebElement mytableBody = locator.FindElement(By.TagName("tbody"));
                List<IWebElement> rowsTable = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>();
                for (int row = 0; row < rowsTable.Count; row++)
                {
                    List<IWebElement> colRow = rowsTable[row].FindElements(By.TagName("td")).ToList<IWebElement>();
                    for (int column = 0; column < colRow.Count; column++)
                    {
                        bodymap[colRow[column].Text] = column;
                    }
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return bodymap;
        }

        public static String getTblTdVal(IWebElement locator, int rowIndex, int colIndex)
        {
            IWebElement ele = null;
            IWebElement rowele = null;
            String tblCellValue = "";

            try
            {
                WebWaitHelper.waitForElement(locator);
                List<IWebElement> mytables = locator.FindElements(By.TagName("tr")).ToList<IWebElement>();
                rowele = mytables[rowIndex];
                List<IWebElement> rowsTable = rowele.FindElements(By.TagName("td")).ToList<IWebElement>();
                ele = rowsTable[colIndex];
                tblCellValue = ele.Text;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return tblCellValue;
        }

        public static String getTblThVal(IWebElement locator, int rowIndex, int colIndex)
        {

            IWebElement ele = null;
            IWebElement tblEle = null;
            IWebElement rowEle = null;

            IWebElement myTblHead = null;
            List<IWebElement> myTblHeadRow = null;
            List<IWebElement> myTblHeadRowCol = null;
            String tblCellValue = "";
            try
            {
                WebWaitHelper.waitForElement(locator);
                myTblHead = locator.FindElement(By.TagName("thead"));
                myTblHeadRow = myTblHead.FindElements(By.XPath("tr")).ToList<IWebElement>();
                for (int row = 0; row < myTblHeadRow.Count; row++)
                {
                    tblEle = myTblHeadRow[row];
                    myTblHeadRowCol = tblEle.FindElements(By.TagName("th")).ToList<IWebElement>();
                    List<IWebElement> hdrRowCol = rowEle.FindElements(By.TagName("th")).ToList<IWebElement>();
                    ele = myTblHeadRowCol[colIndex];
                    tblCellValue = ele.Text;
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return tblCellValue;

        }

        public static String getIndexofVal(IWebElement locator, String value)
        {
            IWebElement mytableBody = null;
            List<IWebElement> mytableBodyrow = null;
            IWebElement tblEle = null;
            List<IWebElement> mytableBodycol = null;
            String indexVal = "";
            try
            {
                WebWaitHelper.waitForElement(locator);
                mytableBody = locator.FindElement(By.TagName("tbody"));
                mytableBodyrow = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>();
                for (int row = 0; row < mytableBodyrow.Count; row++)
                {
                    tblEle = mytableBodyrow[row];
                    mytableBodycol = tblEle.FindElements(By.TagName("td")).ToList<IWebElement>();
                    for (int column = 0; column < mytableBodycol.Count; column++)
                    {
                        if (mytableBodycol[column].Text.ToLower().Equals(value.ToLower()))
                        {
                            Console.WriteLine("Index of " + value + "is (" + row + "," + column + ")");
                            indexVal = row + "," + column;
                            break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return indexVal;

        }

        public static Dictionary<String, String> getColMapByHdrVal(IWebElement locator, String colHeader)
        {
            Dictionary<String, String> colMap = new Dictionary<String, String>();
            Dictionary<String, int> headerMap = new Dictionary<String, int>();
            IWebElement mytableBody = null;
            List<IWebElement> mytableBodyrow = null;
            IWebElement tblEle = null;
            List<IWebElement> mytableBodycol = null;
            try
            {
                WebWaitHelper.waitForElement(locator);
                headerMap = getTblHeaderVal(locator);
                int colNum = headerMap[colHeader];
                mytableBody = locator.FindElement(By.TagName("tbody"));
                mytableBodyrow = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>();
                for (int row = 0; row < mytableBodyrow.Count; row++)
                {
                    tblEle = mytableBodyrow[row];
                    mytableBodycol = tblEle.FindElements(By.TagName("td")).ToList<IWebElement>();
                    colMap[mytableBodycol[colNum].Text] = "Row Number is " + row.ToString();
                }
                return colMap;

            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return colMap;
        }

        public static Dictionary<String, int> getRowMapByIndxVal(IWebElement locator, int rowIndex)
        {
            Dictionary<String, int> rowMap = new Dictionary<String, int>();
            Dictionary<String, int> bodyMap = new Dictionary<String, int>();
            IWebElement mytableBody = null;
            List<IWebElement> mytableBodyrow = null;
            try
            {
                WebWaitHelper.waitForElement(locator);
                mytableBody = locator.FindElement(By.TagName("tbody"));
                mytableBodyrow = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>();
                for (int i = 0; i < mytableBodyrow[rowIndex].FindElements(By.TagName("td")).Count; i++)
                {
                    rowMap[mytableBodyrow[rowIndex].FindElements(By.TagName("td"))[i].Text] = i;
                }
                return rowMap;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return rowMap;
        }

        public static Dictionary<String, int> getRowMapByHdrVal(IWebElement locator, String rowHeader)
        {
            Dictionary<String, int> rowMap = new Dictionary<String, int>();
            Dictionary<String, int> bodyMap = new Dictionary<String, int>();
            IWebElement mytableBody = null;
            List<IWebElement> mytableBodyrow = null;
            try
            {
                WebWaitHelper.waitForElement(locator);
                bodyMap = getTblBodyVal(locator);
                int rowNum = bodyMap[rowHeader];

                mytableBody = locator.FindElement(By.TagName("tbody"));
                mytableBodyrow = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>(); ;
                for (int i = 0; i < mytableBodyrow[(rowNum)].FindElements(By.TagName("td")).Count; i++)
                {
                    rowMap[mytableBodyrow[rowNum].FindElements(By.TagName("td"))[i].Text] = i;
                }
                return rowMap;

            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return rowMap;
        }

        public static Dictionary<String, int> getColMapByIndxVal(IWebElement locator, int colIndex)
        {
            Dictionary<String, int> colMap = new Dictionary<String, int>();
            IWebElement mytableBody = null;
            List<IWebElement> mytableBodyrow = null;
            IWebElement mytableBodyrowCol = null;
            try
            {
                WebWaitHelper.waitForElement(locator);
                mytableBody = locator.FindElement(By.TagName("tbody"));
                mytableBodyrow = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>(); ;
                for (int i = 0; i < mytableBodyrow.Count; i++)
                {
                    mytableBodyrowCol = mytableBodyrow[i].FindElements(By.TagName("td"))[colIndex];
                    colMap[mytableBodyrowCol.Text + i] = colIndex;
                    Console.WriteLine(i);
                }
                return colMap;
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
            return colMap;
        }

        public static void TblCelChkboxClick(IWebElement locator, String value)
        {
            IWebElement mytableBody = null;
            List<IWebElement> mytableBodyrow = null;
            try
            {
                String index = getIndexofVal(locator, value);
                String[] arrSplit = index.Split(',');

                WebWaitHelper.waitForElement(locator);
                mytableBody = locator.FindElement(By.TagName("tbody"));
                mytableBodyrow = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>(); ;
                IWebElement eleRow = mytableBodyrow[(Convert.ToInt32(arrSplit[0]))];
                IWebElement eleRowCol = eleRow.FindElements(By.TagName("td"))[Convert.ToInt32(arrSplit[1]) - 1];
                eleRowCol.Click();
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }

        public static void TblCelLinkClick(IWebElement locator, String value)
        {
            IWebElement mytableBody = null;
            List<IWebElement> mytableBodyrow = null;
            try
            {
                String index = getIndexofVal(locator, value);
                String[] arrSplit = index.Split(',');
                WebWaitHelper.waitForElement(locator);
                mytableBody = locator.FindElement(By.TagName("tbody"));
                mytableBodyrow = mytableBody.FindElements(By.TagName("tr")).ToList<IWebElement>(); ;
                IWebElement eleRow = mytableBodyrow[Convert.ToInt32(arrSplit[0])];
                IWebElement eleRowCol = eleRow.FindElements(By.TagName("td"))[Convert.ToInt32(arrSplit[1])];
                IWebElement ele = eleRowCol.FindElement(By.TagName("a"));
                ele.Click();
            }
            catch (Exception e)
            {
                log.Error(e.Message);
            }
        }


    }
}
