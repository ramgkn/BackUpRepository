﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Runtime.InteropServices;

namespace ETAF_WEB_UTILITIES.Scripted.Web
{
    public static class LogGenerator
    {

        public static StringBuilder LogStringBuilder = new StringBuilder();

        private static string FileName = "Logger.txt";
   

        public static void StartTestCase(String TestCaseName)
        {
            

            DateTime dt = DateTime.Now;


            LogStringBuilder.Append(dt.ToString() + ":               " + "---------" + TestCaseName + "------" + "\r\n");
        }

        public static void EndTestCase(String TestCaseName)
        {
            DateTime dt = DateTime.Now;

            LogStringBuilder.Append(dt.ToString() + ":               " + "---------" + "--E-N-D--" + TestCaseName + "------" + "\r\n");
        }


        public static void Logger(String LogText,[Optional] string LogFilePath, [Optional] string LogFileName)
        {
            FileName = LogFilePath + LogFileName;
            DateTime dt = DateTime.Now;
            LogStringBuilder.Append(dt.ToString() + ":               " + LogText + "\r\n");
            GenerateLog();
        }

        public static void GenerateLog()
        {

            File.WriteAllText(FileName, LogStringBuilder.ToString());


        }

    }
}
