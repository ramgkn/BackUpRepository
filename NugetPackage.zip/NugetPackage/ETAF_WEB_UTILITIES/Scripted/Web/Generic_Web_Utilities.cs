﻿using OpenQA.Selenium;
//using HtmlControls = Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
//using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
using System;


namespace ETAF_WEB_UTILITIES.Scripted.Web
{
    public class Generic_Web_Utilities
    {
        public static int RandomID(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public static void HighlightElement(IWebElement element, IWebDriver driver)
        {
            var jsDriver = (IJavaScriptExecutor)driver;
            string highlightJavascript = @"$(arguments[0]).css({ ""border-width"" : ""2px"", ""border-style"" : ""solid"", ""border-color"" : ""red"", ""background"" : ""yellow"" });";
            jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
        }

        //public static void HtmlLinkClick(HtmlControls.HtmlHyperlink htmlLink, string ob, String TestMethodName)
        //{
            
        //    //USTTestAutomationHelper.DriverEngineHelper obj = new USTTestAutomationHelper.DriverEngineHelper();
        //    try
        //    {
        //        htmlLink.WaitForControlExist();
        //        if (htmlLink.Exists)
        //        {
        //            Mouse.Click(htmlLink, new Point(3, 3));
        //            obj.addTestMethodExecutionDetails(TestLogData, TestMethodName, ob + " Link Exist", "Pass", ob + " Link Clicked");
        //        }
        //        else
        //        {
        //            obj.addTestMethodExecutionDetails(TestLogData, TestMethodName, ob + " Link does not exist", "Fail", ob + " Failed to Click");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        obj.addTestMethodExecutionDetails(TestLogData, TestMethodName, "Exception", "Fail", ex.Message);
        //    }

        //}


    }
}
