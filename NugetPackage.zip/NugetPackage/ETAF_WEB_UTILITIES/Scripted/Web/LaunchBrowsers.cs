﻿using System;
using System.IO;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;

namespace ETAF_WEB_UTILITIES.Scripted.Web
{
    public class LaunchBrowsers
    {
        public static IWebDriver driver { get; set; }
        public static IWebDriver idriver = null;
        public static String strBrowserName = null;
        public static string dirPath = System.IO.Path.GetFullPath(Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, @"..\"));
        public static string strBinPath = dirPath + @"\bin\Debug\netcoreapp2.1\";
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static IWebDriver funcGetWebdriver()
        {            
            try
            {
                if (driver == null)
                {
                    //strBrowserName = ConfigDriver.Config("browserName").ToLower();
                }
                else
                {
                    return driver;
                }
                if (!string.IsNullOrEmpty(strBrowserName))
                {
                    switch (strBrowserName)
                    {
                        case "firefox":

                            driver = new FirefoxDriver(strBinPath);

                            break;

                        case "ie":

                            driver = getIEDriver();
                            break;


                        case "chrome":

                            driver = getChromeDriver();
                            break;

                        default:
                            //if there is no browser details is configured
                            Assert.Fail("Please add the configuration for " + strBrowserName + " in the BrowserManger");
                            break;
                    }
                }
                //if no browser key value is provided in the app.config
                else
                {
                    Assert.Fail("No browser input key is provided, please check and verify");
                }
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                driver.Manage().Cookies.DeleteAllCookies();
                driver.Manage().Window.Maximize();
            }
            catch (Exception e)
            {
                log.Error(e);
            }
            return driver;
        }

        public static void launchWebURL(String strURL)
        {
            try
            {
                driver.Url = strURL;
                driver.Navigate();
                pageWait();
            }
            catch (Exception e)
            {
                driver.Close();
                log.Error(e);
            }
        }

        public static void closeBrowser()
        {
            try
            {
                if (driver != null)
                {
                    driver.Close();
                    driver = null;
                }
            }
            catch (Exception e)
            {
                log.Error(e);
            }
        }
        public static void pageWait()
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
        }


        //To intiate chrome browser
        public static IWebDriver getChromeDriver()
        {            
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.AddUserProfilePreference("safebrowsing.enabled", true);
            chromeOptions.AddUserProfilePreference("credentials_enable_service", false);
            chromeOptions.AddUserProfilePreference("profile.password_manager_enabled", false);
            chromeOptions.AddArgument("no-sandbox");
            IWebDriver driver = new ChromeDriver(strBinPath, chromeOptions);
            return driver;
        }

        //To initiate internet explorer
        public static IWebDriver getIEDriver()
        {
            var internetExplorerOptions = new InternetExplorerOptions
            {
                IntroduceInstabilityByIgnoringProtectedModeSettings = true,
                IgnoreZoomLevel = true,
                EnableNativeEvents = true
            };

            return Directory.Exists(strBinPath)
           ? new InternetExplorerDriver(strBinPath, internetExplorerOptions)
           : new InternetExplorerDriver(internetExplorerOptions);
        }

    }
}
