﻿using System;
using System.Data.OleDb;
using System.Data;

namespace ETAF_WEB_UTILITIES.Scripted.Web
{    
    public class DataDriven
    {
        OleDbConnection excelConnect;
        string DataLocation;
        private  DataDriven() { }
        public DataDriven(String FileLocation)
        {
            DataLocation = FileLocation;
        }
        public void OpenConnectionWithExcel()
        {
            //ReadWriteConfigFile ReadUpdateXML = new ReadWriteConfigFile();              


            //excelConnect = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Schroders_Automation\\Schroders_Automation\\Schroders_Automation\\TestData\\FIA_MOC_TestData.xls;Extended Properties=Excel 8.0");
            if (DataLocation.EndsWith(".xlsx"))
            {
                excelConnect = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DataLocation + "Extended Properties=Excel 12.0");
            }
            else if (DataLocation.EndsWith(".xls"))
            {
                excelConnect = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + DataLocation + ";Extended Properties=Excel 8.0");
            }
        }

        //Method to  store the data from Excel Sheet to a DataTable
        public int StoreDataFromExcelToDataTable()
        {
            OpenConnectionWithExcel();            
            OleDbDataAdapter excelData = new OleDbDataAdapter();            
            OleDbCommand excelCommand = new OleDbCommand("SELECT * FROM [Driver$] ", excelConnect);
            excelConnect.BeginTransaction(); //after connection.open()
            excelData.SelectCommand = excelCommand;
            DataTable dt = new DataTable();
            excelData.Fill(dt);               
            excelConnect.Close();            
            return (0);
        }
        public DataTable GetAllValueFromSheet(string sheetName)
        {
            OpenConnectionWithExcel();
            OleDbDataAdapter excelData = new OleDbDataAdapter();
            OleDbCommand excelCommand = new OleDbCommand("SELECT * FROM [" + sheetName + "$] ", excelConnect);
            excelData.SelectCommand = excelCommand;
            DataTable dt = new DataTable();
            excelData.Fill(dt);
            excelConnect.Close();
            return (dt);
        }
        // Method for fetching value from test data usng row name and column name
        public DataTable FetchValueFromTestDataUsingRowNameAndColumnName(string valueToBeSelectedFrom, string sheetName, string rowName, string rowValue)
        {
            OpenConnectionWithExcel();
            OleDbDataAdapter excelData = new OleDbDataAdapter();
            OleDbCommand excelCommand = new OleDbCommand("SELECT " + valueToBeSelectedFrom + " FROM [" + sheetName + "$] " + " WHERE " + rowName + "= '" + rowValue + "' ", excelConnect);
            //OleDbCommand excelCommand = new OleDbCommand("SELECT ExecutionFlag FROM [Driver$] " + " WHERE Counter = 'C1' ", excelConnect);
            excelData.SelectCommand = excelCommand;
            DataTable dt = new DataTable();
            excelData.Fill(dt);
            excelConnect.Close();
            return (dt);
        }

        // Method to get a value from Column
        public string GetAValueFromColumn(string sheetName, string columnName, string rowValue)
        {
            //try
            // {
            OpenConnectionWithExcel();
            OleDbDataAdapter excelData = new OleDbDataAdapter();
            OleDbCommand excelCommand = new OleDbCommand("SELECT * FROM [" + sheetName + "$] " + " WHERE " + columnName + "= '" + rowValue + "' ", excelConnect);
            //OleDbCommand excelCommand = new OleDbCommand("SELECT * FROM [" + sheetName + "$] " + " WHERE " + columnName + " = 'Yes'", excelConnect);
            excelData.SelectCommand = excelCommand;
            DataTable dt = new DataTable();
            excelData.Fill(dt);
            excelConnect.Close();
            string value = dt.Rows[0].ToString();
            return (value);

        }


        public string GetAValueFromColumn_TestData(string columnName, string rowValue)
        {
              string sheetName="TestData";
              string Coulmnname1 = "TestCaseID";
            //try
            // {
              OpenConnectionWithExcel();
            OleDbDataAdapter excelData = new OleDbDataAdapter();
            OleDbCommand excelCommand = new OleDbCommand("SELECT [" + rowValue + "] FROM [" + sheetName + "$] " + " WHERE " + Coulmnname1 + "= '" + columnName + "' ", excelConnect);
            
            //OleDbCommand excelCommand = new OleDbCommand("SELECT * FROM [" + sheetName + "$] " + " WHERE " + columnName + " = 'Yes'", excelConnect);
            excelData.SelectCommand = excelCommand;
            DataTable dt = new DataTable();
            excelData.Fill(dt);
            excelConnect.Close();
            string valuesa = dt.Rows[0][0].ToString();
            return valuesa;

        }




        // Method for getting the total number of row count by specifying the sheet name
        public int GetTotalNumberOfRowCountBySpecyingSheetName(string sheetName)
        {
            OpenConnectionWithExcel();
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            OleDbCommand command;
            command = new OleDbCommand("SELECT COUNT(*) FROM [" + sheetName + "$]", excelConnect);
            adapter.SelectCommand = command;
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            excelConnect.Close();
            return (0);
        }

        public int GetTotalNumberOfColumnCountBySpecyingSheetName(string sheetName)
        {
            OpenConnectionWithExcel();
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            OleDbCommand command;
            command = new OleDbCommand("SELECT * FROM [" + sheetName + "$]", excelConnect);
            adapter.SelectCommand = command;
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            int columncount=dt.Columns.Count;
            excelConnect.Close();
            return (columncount);
        }
        //Method to get a counter value in a particular sheet
        public int GetACounterValueInAParticularSheet(string sheetName)
        {
            OpenConnectionWithExcel();
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            OleDbCommand command;

            command = new OleDbCommand("SELECT COUNT(*) FROM [" + sheetName + "$]", excelConnect);

            adapter.SelectCommand = command;
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            excelConnect.Close();
            return 0;
        }

        // Method to get a value from the Batch file
        public int GetAValueFromBatchFile(string sheetName1, string sheetName2, string sheetNAme3, string sheetName4)
        {
            int count1, count2, count3, count4 = 0;
            count1 = GetTotalNumberOfRowCountBySpecyingSheetName(sheetName1);
            count2 = GetTotalNumberOfRowCountBySpecyingSheetName(sheetName2);
            count3 = GetTotalNumberOfRowCountBySpecyingSheetName(sheetNAme3);
            count4 = GetTotalNumberOfRowCountBySpecyingSheetName(sheetName4);
            return (count1 + count2 + count3 + count4);
        }

        // Method to get the count of the number of records in a spreadsheet
        public void GetCountOfNumberOfRecordsInASpreadSheet()
        {

        }

        // Method to update a value in a row at a particular column in the spreadsheet
        public void UpdateAValueInARowAtAParticularCoulmnInSpreadSheet(string ColumnNameToUpdateValue, string valueToBeUpdated, string ColumnName, string refValue)
        {
            //System.Data.OleDb.OleDbConnection MyConnection;
            //System.Data.OleDb.OleDbCommand myCommand = new System.Data.OleDb.OleDbCommand();
            string sql;
            //MyConnection = new System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source='C:\\Automation\\Test\\Test MOC\\Test MOC\\Test MOC\\Batch.xls';Extended Properties=Excel 8.0;");
            //myCommand.Connection = MyConnection;
            //MyConnection.Open();
            OpenConnectionWithExcel();
            sql = "Update [Driver$] set " + ColumnNameToUpdateValue + "= '" + valueToBeUpdated + "' where " + ColumnName + "= '" + refValue + "'";
            //sql = "Update [Driver$] set ExecutionFlag = 'Yes' where Counter='C1'";
            OleDbCommand objCmdSelect = new OleDbCommand(sql, excelConnect);
            objCmdSelect.ExecuteNonQuery();
            excelConnect.Close();
            StoreDataFromExcelToDataTable();
        }

        // Method to update the value in a row in the spreadsheet
        public void UpdateValueInARowInSpreadSheet(string ColumnNameToUpdateValue, string valueToBeUpdated, string ColumnName, string refValue)
        {
            //System.Data.OleDb.OleDbConnection MyConnection;
            //System.Data.OleDb.OleDbCommand myCommand = new System.Data.OleDb.OleDbCommand();
            string sql;
            //MyConnection = new System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source='C:\\Automation\\Test\\Test MOC\\Test MOC\\Test MOC\\Batch.xls';Extended Properties=Excel 8.0;");
            //myCommand.Connection = MyConnection;
            //MyConnection.Open();

            sql = "Update [Driver$] set " + ColumnNameToUpdateValue + "= '" + valueToBeUpdated + "' where " + ColumnName + "= '" + refValue + "'";
            //sql = "Update [Driver$] set ExecutionFlag = 'Yes' where Counter='C1'";
            OleDbCommand objCmdSelect = new OleDbCommand(sql, excelConnect);
            objCmdSelect.ExecuteNonQuery();
            excelConnect.Close();
            StoreDataFromExcelToDataTable();
        }

       
        public string GetNumberOfRows(string sheetName, string sqlquery)
        {
            string count = "";
            //if (filename.EndsWith(".xlsx"))
            //{
            //    connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filename + ";Mode=ReadWrite;Extended Properties=\"Excel 12.0;HDR=NO\"";
            //}
            //else if (filename.EndsWith(".xls"))
            //{
            //    connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filename + ";Mode=ReadWrite;Extended Properties=\"Excel 8.0;HDR=NO;\"";
            //}
            ////string SQL = "SELECT COUNT (*) FROM [" + sheetName + "$]";
            //using (OleDbConnection conn = new OleDbConnection(connectionString))
            OpenConnectionWithExcel();
            using (excelConnect)
            {

                using (OleDbCommand cmd = new OleDbCommand(sqlquery, excelConnect))
                {
                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        reader.Read();
                        //reader.FieldCount;
                        count = reader[0].ToString();
                        //count = reader[1].ToString();
                        //count = reader[2].ToString();
                    }
                }

                excelConnect.Close();
            }
            return count;
        }

        public void InserValueIntOExcel(string SheetName, string ColumnNames, string ColumnValues)
        {
            OpenConnectionWithExcel();
            excelConnect.Open();
            string newColumnValues = "'" + string.Join("','", ColumnValues) + "'";
            string sql;
            sql = "INSERT INTO [" + SheetName + "$] (" + ColumnNames + ") VALUES (" + newColumnValues + ")";
            OleDbCommand objCmdSelect = new OleDbCommand(sql, excelConnect);
            objCmdSelect.CommandText = sql;
            objCmdSelect.ExecuteNonQuery();
            excelConnect.Close();
        }
    }
}
