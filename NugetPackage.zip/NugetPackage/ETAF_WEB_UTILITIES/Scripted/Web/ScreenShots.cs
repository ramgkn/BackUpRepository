using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ETAF_WEB_UTILITIES.Scripted.Web
{
    public class GetScreenShot
    {
        public static string Capture(IWebDriver driver, string screenShotName,string filepath)
        {
            ITakesScreenshot ts = (ITakesScreenshot)driver;

            Screenshot screenshot = ts.GetScreenshot();

            //string pth = System.IO.Path.GetFullPath(Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, @"..\"));

            string finalpth = filepath + @"\ExtentReport_Local\" + screenShotName + ".png";

            string localpath = new Uri(finalpth).LocalPath;

            screenshot.SaveAsFile(localpath, OpenQA.Selenium.ScreenshotImageFormat.Png);

            return localpath;
        }
    }
}