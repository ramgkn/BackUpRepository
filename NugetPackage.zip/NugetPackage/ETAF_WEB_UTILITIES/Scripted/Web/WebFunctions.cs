﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace ETAF_WEB_UTILITIES.Scripted.Web
{
    public class WebFunctions
    {

        private static int returnRow;
        public static string dropdownvaluecheck(IWebElement dropDownElement, string optionToSelect)
        {
            if (dropDownElement.Text.Contains(optionToSelect))
            {
                return optionToSelect;
            }
            else
            {
                return "";
            }
        }

        public static Func<IWebDriver, bool> ElementIsVisible(IWebElement element)
        {
            return (driver) =>
            {
                try
                {
                    return element.Displayed;
                }
                catch (Exception)
                {
                    // If element is null, stale or if it cannot be located
                    return false;
                }
            };
        }

        public static int rowindextfromtable(IWebElement sourceDatatable, string lookupValue)
        {
            IList<IWebElement> tableRow = sourceDatatable.FindElements(By.TagName("tr"));

            IList<IWebElement> rowTD;

            int ticker = 0;

            Boolean Check = false;

            foreach (IWebElement row in tableRow)
            {
                rowTD = row.FindElements(By.TagName("td"));

                if (rowTD.Count > 0)
                {
                    if (rowTD[0].Text == lookupValue)
                    {
                        Check = true;
                        break;

                    }
                }

                ticker++;
            }

            if (Check == false) ticker = 0;

            return ticker;

        }


        public static int Searchindatatable(IWebElement sourceDatatable, string lookupValue, int columntolookfor)
        {

            int ticker = 0;

            ICollection<IWebElement> allElement = sourceDatatable.FindElements(By.TagName("tr"));

            foreach (IWebElement elementrows in allElement)
            {
                ICollection<IWebElement> elementdata = elementrows.FindElements(By.TagName("td"));

                if (elementdata.Count != 0) ticker = ticker + 1;

                foreach (IWebElement elements in elementdata)

                {

                    IWebElement lookupdata = elements.FindElement(By.XPath("//tr[" + ticker + "]//td[" + columntolookfor + "]"));


                    if (lookupdata.Text.ToUpper() == lookupValue.ToUpper())
                    {
                        returnRow = ticker;                       

                        break;
                    }

                    //var iname = elements.GetAttribute("src");

                    //IWebElement ImgName1 = atr.FindElement(By.XPath("//tr[" + ticker + "]//td[5]//img[1]"));

                    //IWebElement ImgName3 = atr.FindElement(By.XPath("//td[5]//img[1]"));

                    //Generic_Web_Utilities.HighlightElement(_driver.FindElement(By.XPath("//h1[contains(text(),'Execute Automation Selenium')]")), _driver);

                    // Generic_Web_Utilities.HighlightElement(ImgName3, _driver);

                }

                if (returnRow != 0) break;

            }

            return returnRow;
        }

    }
}
