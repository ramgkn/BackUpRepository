﻿using System;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Collections.Generic;

namespace etaf.api.utilities.Scripted.api
{
    public class RequestParams
    {
        private String uri;
        private String url;
        private String contenttype;
        private String proxy;
        private int port;
        private JToken jsonBody;
        private String restMethodType;
        private String accept;
        private String apiJsonRequestPath = "resources/apijsonrequest/";
        private Dictionary<String, String> arrRequestParams = new Dictionary<String, String>();
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        /// <summary>
        /// constructors
        /// </summary>
        public RequestParams()
        {
        }

        /**
         * @param uri
         * @param contentType
         * @param mediaType
         * @param basePath
         * @param baseURI
         * @param body
         * @param header
         * @param proxy
         * @param host
         * @param port
         * @param scheme
         * @param proxy_URI
         * @param iSrelaxedHTTPSValidation
         * @param protocol
         * @param file
         * @param password
         * @param path
         * @param keystore
         * @param headersMap
         */
        public RequestParams(String uri, String contentType, String proxy, int port, String body, String restMethodType)
        {
            this.uri = uri;
            this.contenttype = contentType;
            this.proxy = proxy;
            this.port = port;
            //this.body = body;
            this.restMethodType = restMethodType;
        }

        

        public String GetUri()
        {
            return uri;
        }
        public void SetUri(String uri)
        {
            this.uri = uri;
        }
        public String GetUrl()
        {
            return url;
        }
        public void SetUrl(String url)
        {
            this.url = url;
        }

        public String GetContenttype()
        {
            return contenttype;
        }
        public void SetContenttype(String contenttype)
        {
            this.contenttype = contenttype;
        }


        public String GetProxy()
        {
            return proxy;
        }
        public void SetProxy(String proxy)
        {
            this.proxy = proxy;
        }

        public void SetProxyAndPort(String proxy, int port)
        {
            this.proxy = proxy;
            this.port = port;
        }

        public int GetPort()
        {
            return port;
        }
        public void SetPort(int port)
        {
            this.port = port;
        }

        public String GetRestMethodType()
        {
            return restMethodType;
        }
        public void SetRestMethodType(String restMethodType)
        {
            this.restMethodType = restMethodType;
        }

        public String GetAccept()
        {
            return this.accept;
        }
        public void SetAccept(String accept)
        {
            this.accept = accept;
        }

        public JToken GetJsonbody()
        {
            return jsonBody;
        }
        public void SetJsonbody(String fileName)
        {
            try
            {
                String requestFilePath = GetProp.getFilePath(apiJsonRequestPath + fileName + ".txt");

                using (StreamReader file = File.OpenText(requestFilePath))
                using (JsonTextReader reader = new JsonTextReader(file))
                {
                    jsonBody = JToken.ReadFrom(reader);
                }
            }
            catch (Exception e)
            {
                log.Error(e);
            }
        }

        public Dictionary<String,String> GetParameters()
        {
            return this.arrRequestParams;
        }
        public void SetParameters(Dictionary<String, String> arrRequestParams)
        {
            this.arrRequestParams = arrRequestParams;
        }
    }
}
