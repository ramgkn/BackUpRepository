﻿using System;
using System.Collections.Generic;
using System.Net;
using System.IO;
using NUnit.Framework;
using Newtonsoft.Json.Linq;
using System.Xml;
using RestSharp;
using System.Xml.XPath;
using etaf.api.utilities.Scripted;
using etaf.api.utilities.Scripted.api;

namespace Tetaf.api.utilities.Scripted.api
{
    public class RestAssuredWrapper 
    {

        GetProp getPropertiesInMap = new GetProp();
        Dictionary<String, String> propMap = new Dictionary<String, String>();
        Dictionary<String, Object> ObjMap = new Dictionary<String, Object>();

        private static String filename = null;
        private WebResponse apiResponse = null;

        private static RestClient restSpecClient = new RestClient();
        private static RestRequest objReq;
        public static IRestResponse response;

        public static RestClient RestSpecClient { get => restSpecClient; set => restSpecClient = value; }
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        //public string ContentType { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        /// <summary>
        /// Accept empty RequestParams objs and fill the value from config file and return the same 
        /// Prerequisite- config file should be set
        /// </summary>
        public RequestParams CreateRequest(RequestParams objReqParams)
        {
            log.Info("API:Wrapper- Creating request.");
            try
            {
                if (!string.IsNullOrEmpty(filename))
                    propMap = getPropertiesInMap.getPropValues("resources/apiproperties/" + filename);
                else return objReqParams;
                

                bool isPropMapEmpty = false;
                if (propMap.Count == 0)
                    isPropMapEmpty = true;

                
                if (isPropMapEmpty == false)
                {
                    foreach (KeyValuePair<string, string> it in propMap)
                    {
                        KeyValuePair<string, string> reqParams = it;

                        if (reqParams.Key.Equals("uri"))
                        {
                            objReqParams.SetUri(reqParams.Value.ToString());
                        }
                        else if (reqParams.Key.Equals("url"))
                        {
                            objReqParams.SetUrl(reqParams.Value.ToString());
                        }

                        else if (reqParams.Key.Equals("proxyAndPort"))
                        {
                            String proxyPort = reqParams.Value.ToString();
                            String[] splitproxyPort = proxyPort.Split(':');
                            objReqParams.SetProxyAndPort(splitproxyPort[0], Convert.ToInt32(splitproxyPort[1]));
                        }
                        else if (reqParams.Key.Equals("contenttype"))
                        {
                            if (reqParams.Value.ToString().Contains("json"))
                            {
                                objReqParams.SetContenttype("application/json; charset=utf-8");
                            }
                            else if (reqParams.Value.ToString().Contains("xml"))
                            {
                                objReqParams.SetContenttype("application/xml; charset=utf-8");
                            }
                        }
                        else if (reqParams.Key.Equals("accept"))
                        {
                            if (reqParams.Value.ToString().Contains("json"))
                            {
                                objReqParams.SetAccept("application/json");
                            }
                            else if (reqParams.Value.ToString().Contains("xml"))
                            {
                                objReqParams.SetAccept("application/xml");
                            }
                        }

                        else if (reqParams.Key.Equals("restMethodType"))
                        {
                            if (reqParams.Value.ToString().Equals("POST"))
                            {
                                objReqParams.SetRestMethodType("POST");
                            }
                            else if (reqParams.Value.ToString().Equals("PUT"))
                            {
                                objReqParams.SetRestMethodType("PUT");
                            }
                            else if (reqParams.Value.ToString().Equals("GET"))
                            {
                                objReqParams.SetRestMethodType("GET");
                            }
                            else if (reqParams.Value.ToString().Equals("DELETE"))
                            {
                                objReqParams.SetRestMethodType("DELETE");
                            }
                        }
                    }                    
                }

            }
            catch (Exception e)
            {
                log.Error(e);
            }
            return objReqParams;
        }

        public static void setAPIFileProName(String fileName)
        {
            try
            {
                log.Info("API:Wrapper-Setting file.");
                filename = fileName;
            }
            catch (Exception e)
            {

                log.Error(e);
            }
        }

        //public static Dictionary<String, Object> ConvertObjectToMap(RequestParams raWrapper)
        //{

        //    Type pomclass = raWrapper.GetType();
        //    MethodInfo[] methods = pomclass.GetMethods();

        //    Dictionary<String, Object> map = new Dictionary<String, Object>();
        //    foreach (MethodInfo infoItem in methods)
        //    {
        //        if (infoItem.Name.StartsWith("get") && !infoItem.Name.StartsWith("getClass"))
        //            map.Add(infoItem.Name, infoItem);
        //    }


        //    return map;
        //}

        public IRestResponse sendRequest(RequestParams reqSpec)
        {
            try
            {
                string content = string.Empty;
                log.Info("API:Wrapper- Sending API request.");
                //Set proxy
                if (!(string.IsNullOrEmpty(reqSpec.GetProxy()) && reqSpec.GetPort() > 0))
                    restSpecClient.Proxy = new WebProxy(reqSpec.GetProxy(), reqSpec.GetPort());

                if (!string.IsNullOrEmpty(reqSpec.GetUrl()))
                    restSpecClient.BaseUrl = new Uri(reqSpec.GetUrl());

                if (!string.IsNullOrEmpty(reqSpec.GetRestMethodType()))
                {
                    if (reqSpec.GetRestMethodType().Equals("POST"))
                    {
                        if (!(string.IsNullOrEmpty(reqSpec.GetUri())))
                        {
                            objReq = new RestRequest(reqSpec.GetUri(), Method.POST);
                        }
                        else if (!(string.IsNullOrEmpty(reqSpec.GetUrl())))
                        {
                            restSpecClient = new RestClient();
                            objReq = new RestRequest(reqSpec.GetUrl(), Method.POST);
                        }
                    }
                    else if (reqSpec.GetRestMethodType().Equals("PUT"))
                    {
                        if (!(string.IsNullOrEmpty(reqSpec.GetUri())))
                        {
                            objReq = new RestRequest(reqSpec.GetUri(), Method.PUT);
                        }
                        else if (!(string.IsNullOrEmpty(reqSpec.GetUrl())))
                        {
                            restSpecClient = new RestClient();
                            objReq = new RestRequest(reqSpec.GetUrl(), Method.PUT);
                        }
                    }
                    else if (reqSpec.GetRestMethodType().Equals("GET"))
                    {
                        if (!(string.IsNullOrEmpty(reqSpec.GetUri())))
                        {
                            objReq = new RestRequest(reqSpec.GetUri(), Method.GET);
                        }
                        else if (!(string.IsNullOrEmpty(reqSpec.GetUrl())))
                        {
                            restSpecClient = new RestClient();
                            objReq = new RestRequest(reqSpec.GetUrl(), Method.GET);
                        }
                    }
                    else if (reqSpec.GetRestMethodType().Equals("DELETE"))
                    {
                        if (!(string.IsNullOrEmpty(reqSpec.GetUri())))
                        {
                            objReq = new RestRequest(reqSpec.GetUri(), Method.DELETE);
                        }
                        else if (!(string.IsNullOrEmpty(reqSpec.GetUrl())))
                        {
                            restSpecClient = new RestClient();
                            objReq = new RestRequest(reqSpec.GetUrl(), Method.DELETE);
                        }
                    }
                }
                //Set accept Type
                if (!string.IsNullOrEmpty(reqSpec.GetAccept()))
                    objReq.AddHeader("Accept", reqSpec.GetAccept());

                //Set Content Type
                if (!string.IsNullOrEmpty(reqSpec.GetContenttype()))
                    objReq.AddHeader("Content-Type", reqSpec.GetContenttype());

                //Set Request params
                if (reqSpec.GetParameters().Count > 0)
                {
                    foreach (KeyValuePair<string, string> item in reqSpec.GetParameters())
                    {
                        objReq.AddParameter(item.Key, item.Value, ParameterType.GetOrPost);
                    }
                }
                if (reqSpec.GetJsonbody() != null)
                    //objReq.AddJsonBody(reqSpec.GetJsonbody().ToObject(typeof(JsonClass)));



                // client.Authenticator = new HttpBasicAuthenticator(username, password);

                response = restSpecClient.Execute(objReq);
            }
            catch (Exception e)
            {
                log.Error(e);
            }

            return response;
        }
       
       
        public void sendGetRequestWithParams(RequestParams reqSpec)
        {
            //WebResponse response = reqSpec.when().get(uri);
            //String responseBody = response.getBody().asString();
            //setReponse(response);
        }

        private void setReponse(WebResponse response)
        {
            try
            {
                log.Info("API:Wrapper- Setting response.");
                apiResponse = response;
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();
                Console.WriteLine(responseFromServer);
                reader.Close();
                dataStream.Close();
                response.Close();
            }
            catch (Exception e)
            {
                log.Error(e);
            }
        }

        private string getResponse()
        {
            try
            {
                Console.WriteLine(response.StatusDescription);                
            }
            catch (Exception e)
            {
                log.Error(e);
            }
            return response.Content;
        }

        public void valResponseCode(ResponseStatus respCode,ResponseStatus statusCode)
        {
            Assert.AreEqual(respCode, statusCode);
        }

        public void valJsonResponseVal(String jsonPath, string expValue)
        {
            try
            {
                JObject jsonResult = JObject.Parse(getResponse());
                string strJResult = (string)jsonResult.SelectToken(jsonPath);
                Assert.AreEqual(expValue, strJResult, "Mismatch in the response - JsonPath :" + jsonPath);
                log.Info("Success");
            }
            catch (Exception e)
            {
                log.Error(e);
            }
        }

        public void valXmlResponseVal(String xmlPath, Object expValue)
        {
            try
            {
                String strValue = getResponse();
                XmlReaderSettings settings = new XmlReaderSettings { ConformanceLevel = ConformanceLevel.Fragment, IgnoreWhitespace = true, IgnoreComments = true };
                XmlReader reader = XmlReader.Create(new StringReader(strValue), settings);
                XPathDocument document = new XPathDocument(reader);
                reader.Read();
                XPathNavigator navigator = document.CreateNavigator();
                String currentValue = navigator.SelectSingleNode(xmlPath).TypedValue.ToString();
                Assert.AreEqual(expValue, currentValue);
            }
            catch (Exception e)
            {
                log.Error(e);
            }
            
        }

        public void setGetQueryParams(RestAssuredWrapper param)
        {
            try
            {
                GetProp objGetProp = new GetProp();
                Dictionary<string, string> prop = objGetProp.getPropValues("resources/apiproperties/" + filename);
                foreach (var item in prop.Keys)
                {
                    if (item.Contains("uri"))
                    {
                        HttpWebRequest objReq = (HttpWebRequest)WebRequest.Create(prop[item]);
                        if (item.Contains("proxyAndPort"))
                        {
                            string[] straProxy = prop[item].ToString().Split(':');
                            WebProxy objProxy = new WebProxy(straProxy[0], Convert.ToInt32(straProxy[1]));
                            objReq.Proxy = objProxy;
                        }

                        if (item.Contains("contenttype"))
                        {
                            objReq.ContentType = prop[item].ToString();
                        }
                        if (item.Contains("restMethodType"))
                        {
                            objReq.Method = prop[item].ToString();
                        }
                        if (item.Contains("accept"))
                        {
                            objReq.Accept = prop[item].ToString();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                log.Error(e);
            }

        }

        
    }

}

