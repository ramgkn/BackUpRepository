﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Authenticators;

namespace etaf.api.utilities.CustomFunctions
{
    public class JiraExtension
    {
        private static IRestResponse jiraResponse;

        //public static Dictionary<string, string> CreateJiraTicket(String JiraEndPoint, String jiraUserName, String jiraPassword, String jiraProjectID, [Optional] ExtentTest testScenario, [Optional] String ErrorDescription, [Optional] String[] jiraAttachments)
        public static Dictionary<string, string> CreateJiraTicket(String JiraEndPoint, String jiraUserName, String jiraPassword, String jiraProjectID, Dictionary<string,string> ScenarioDetails, [Optional] String[] jiraAttachments)
        {

            Dictionary<string, string> JiraTicketResponse = new Dictionary<string, string>();

            var client = new RestClient(JiraEndPoint);

            var request = new RestRequest("rest/api/2/issue/", Method.POST);

            client.Authenticator = new HttpBasicAuthenticator(jiraUserName, jiraPassword);

            var issue = new Issue
            {
                fields =
                    new Fields
                    {
                        //description = JiraStepGenerator(testScenario) + Environment.NewLine + "Failure Reason: " + ErrorDescription,

                        description = Convert.ToString(ScenarioDetails["ScenarioTitle"] + Environment.NewLine + "Steps To Reproduce Problem Statement:" + Environment.NewLine + ScenarioDetails["TestSteps"]),

                        //summary = Convert.ToString(testScenario.Model.Parent.Name),

                        summary = Convert.ToString(ScenarioDetails["FeatureName"]),

                        project = new Project { key = jiraProjectID },

                        //issuetype = new IssueType { name = "Issue" }

                        issuetype = new IssueType { name = "Problem" }
                    }
            };

            request.AddJsonBody(issue);

            jiraResponse = client.Execute<Issue>(request);

            if (jiraResponse.StatusCode == HttpStatusCode.Created)
            {
                JiraTicketResponse.Add("JiraTicket", Convert.ToString(JObject.Parse(jiraResponse.Content).SelectToken("key")));

                JiraTicketResponse.Add("JiraTicketLink", JiraEndPoint + "/browse/" + Convert.ToString(JObject.Parse(jiraResponse.Content).SelectToken("key")));
            }

            JiraTicketResponse.Add("JiraTicketCreationResponse", jiraResponse.Content);

            if (jiraResponse.StatusCode == HttpStatusCode.Created && jiraAttachments != null)
            {
                request = new RestRequest(string.Format("rest/api/2/issue/{0}/attachments", JObject.Parse(jiraResponse.Content).SelectToken("key")), Method.POST);

                request.AddHeader("X-Atlassian-Token", "nocheck");

                foreach (var eachFile in jiraAttachments)
                {
                    var file = File.ReadAllBytes(eachFile);

                    request.AddHeader("Content-Type", "multipart/form-data");

                    request.AddFileBytes("file", file, eachFile);

                }

                jiraResponse = client.Execute(request);

                if (jiraResponse.StatusCode == HttpStatusCode.OK)
                {
                    JArray parsedArray = JArray.Parse(jiraResponse.Content);

                    int ticker = 0;

                    foreach (JObject parsedObject in parsedArray.Children<JObject>())
                    {
                        foreach (JProperty parsedProperty in parsedObject.Properties())
                        {
                            string propertyName = parsedProperty.Name;

                            if (propertyName.Equals("filename"))
                            {
                                JiraTicketResponse.Add("JiraTicketAttachments" + ticker, Convert.ToString(parsedProperty.Value));

                                ticker++;
                            }
                        }
                    }
                }

                JiraTicketResponse.Add("JiraTicketAttachmentResponse", jiraResponse.Content);


            }

            //return (jiraResponse);
            return JiraTicketResponse;

        }

        //private static String JiraStepGenerator(ExtentTest tempSceanario)
        //{
        //    var _tempScenario = tempSceanario.Model.NodeContext;

        //    var testSteps = "Scenario: " + tempSceanario.Model.Name;

        //    foreach (var teststep in _tempScenario.GetEnumerator())
        //    {

        //        testSteps = testSteps + Environment.NewLine + "\t" + teststep.BehaviorDrivenTypeName + ": " + teststep.Name;
        //    }

        //    return testSteps;

        //}

    }

    public class Issue
    {
        public string id { get; set; }
        public string key { get; set; }
        public Fields fields { get; set; }
    }

    public class Fields
    {
        public Project project { get; set; }
        public IssueType issuetype { get; set; }
        public string summary { get; set; }
        public string description { get; set; }
    }

    public class Project
    {
        public string id { get; set; }
        public string key { get; set; }
    }

    public class IssueType
    {
        public string id { get; set; }
        public string name { get; set; }
    }

}