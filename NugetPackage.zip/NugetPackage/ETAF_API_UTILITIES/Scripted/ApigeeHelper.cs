﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;

namespace etaf.api.utilities.CustomFunctions
{
    public class ApigeeHelper
    {

        private static RestClient apiService;
        private static IRestResponse response;
        private static IRestRequest request;
        private static Uri tmpUri;
        private static HttpClientHandler myHttpHandle;
        private static HttpClient myClient;
        private static string EndPoint;

        public static void SetEndPoint(string endPoint)
        {
            apiService = new RestClient(endPoint);
            EndPoint = endPoint;
        }

        public static IRestResponse PostRequest(string access_token, string queryString, [Optional] Object requestBody, [Optional] Dictionary<string, string> Headers, [Optional] Dictionary<string, string> QueryParams)
        {
            request = new RestRequest(queryString, Method.POST);

            SetArgsParams(requestBody, Headers, QueryParams);

            response = apiService.Execute(request);

            return response;

        }

        public static IRestResponse PutRequest(string access_token, string queryString, [Optional] Object requestBody, [Optional] Dictionary<string, string> Headers, [Optional] Dictionary<string, string> QueryParams)
        {


            request = new RestRequest(queryString, Method.PUT);

            request.RequestFormat = DataFormat.Json;

            SetArgsParams(requestBody, Headers, QueryParams);

            response = apiService.Execute(request);

            return response;

        }

        public static IRestResponse DeleteRequest(string access_token, string queryString, [Optional] Object requestBody, [Optional] Dictionary<string, string> Headers, [Optional] Dictionary<string, string> QueryParams)
        {
            request = new RestRequest(queryString, Method.DELETE);

            SetArgsParams(requestBody, Headers, QueryParams);

            response = apiService.Execute(request);

            return response;

        }

        public static IRestResponse GetRequest(string access_token, string queryString, [Optional] Object requestBody, [Optional] Dictionary<string, string> Headers, [Optional] Dictionary<string, string> QueryParams)
        {

            request = new RestRequest(queryString, Method.GET);

            request.RequestFormat = DataFormat.Json;

            SetArgsParams(requestBody, Headers, QueryParams);

            response = apiService.Execute(request);

            return response;
        }

        public static IRestResponse GetRequestHttpClient(String QueryString, Object RequestBody)
        {
            myHttpHandle = new HttpClientHandler();

            myClient = new HttpClient(myHttpHandle);

            tmpUri = new Uri(EndPoint + QueryString);

            var myRequest = new HttpRequestMessage
            {
                Method = HttpMethod.Get,

                RequestUri = tmpUri,

                Content = new StringContent(JsonConvert.SerializeObject(RequestBody), Encoding.UTF8, "application/json"),

            };

            myClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer" + "test");

            var myResponse = myClient.SendAsync(myRequest).ConfigureAwait(false).GetAwaiter().GetResult();

            string resultstr = myResponse.Content.ReadAsStringAsync().ConfigureAwait(false).GetAwaiter().GetResult();

            IRestResponse convertResponse = new RestResponse();

            convertResponse.StatusCode = myResponse.StatusCode;

            convertResponse.Content = myResponse.Content.ReadAsStringAsync().ConfigureAwait(false).GetAwaiter().GetResult();

            //convertResponse.Headers = myResponse.Headers.ToList(); need to map with linq all relatives fields

            convertResponse.ResponseUri = myResponse.RequestMessage.RequestUri;

            convertResponse.ErrorMessage = myResponse.ReasonPhrase;

            return convertResponse;
        }

        public static IRestResponse PutRequestHttpClient(String QueryString, Object RequestBody, [Optional] String Authentication)
        {
            myHttpHandle = new HttpClientHandler();

            myClient = new HttpClient(myHttpHandle);

            tmpUri = new Uri(EndPoint + QueryString);

            myClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer" + "test");

            var myResponse = myClient.PutAsJsonAsync(tmpUri, RequestBody).Result;

            IRestResponse convertResponse = new RestResponse();

            convertResponse.StatusCode = myResponse.StatusCode;

            convertResponse.Content = myResponse.Content.ReadAsStringAsync().ConfigureAwait(false).GetAwaiter().GetResult();

            convertResponse.ResponseUri = myResponse.RequestMessage.RequestUri;

            convertResponse.ErrorMessage = myResponse.ReasonPhrase;

            return convertResponse;
        }

        public static IRestResponse DeleteRequestHttpClient(String QueryString, Object RequestBody)
        {
            myHttpHandle = new HttpClientHandler();

            myClient = new HttpClient(myHttpHandle);

            tmpUri = new Uri(EndPoint + QueryString);

            myClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer" + "test");

            var myResponse = myClient.DeleteAsync(tmpUri).Result;
            
            IRestResponse convertResponse = new RestResponse();

            convertResponse.StatusCode = myResponse.StatusCode;

            convertResponse.Content = myResponse.Content.ReadAsStringAsync().ConfigureAwait(false).GetAwaiter().GetResult();

            convertResponse.ResponseUri = myResponse.RequestMessage.RequestUri;

            convertResponse.ErrorMessage = myResponse.ReasonPhrase;

            return convertResponse;
        }

        public static void RequestParams(Dictionary<string, string> myDictionary, String Argument)
        {

            foreach (KeyValuePair<string, string> entry in myDictionary)
            {
                switch (Argument)
                {


                    case "Headers":

                        request.AddHeader(entry.Key.ToString(), entry.Value.ToString());

                        break;

                    case "QueryParams":

                        request.AddQueryParameter(entry.Key.ToString(), entry.Value.ToString());

                        break;
                }

            }

        }
        public static void SetArgsParams([Optional] Object requestBody, [Optional] Dictionary<string, string> Headers, [Optional] Dictionary<string, string> QueryParams)
        {
            if (Headers.ContainsKey("accept") == false) Headers.Add("accept", "text/plain");

            if (Headers != null && Headers.Count > 0) RequestParams(Headers, "Headers");

            if (QueryParams != null && QueryParams.Count > 0) RequestParams(QueryParams, "QueryParams");

            if (requestBody != null)

            {

                request.AddJsonBody(requestBody);

            }
        }
        public static bool CheckUrlExists(string uriInput)
        {

            // Variable to Return
            bool CheckStatus;
            // Create a request for the URL.
            WebRequest request = WebRequest.Create(uriInput);
            request.Timeout = 15000; // 15 Sec

            WebResponse response;
            try
            {
                response = request.GetResponse();
                CheckStatus = true; // Uri does exist                 
                response.Close();
            }
            catch (Exception)
            {
                CheckStatus = false; // Uri does not exist
            }
            // Result
            return CheckStatus;

        }

    }

}
