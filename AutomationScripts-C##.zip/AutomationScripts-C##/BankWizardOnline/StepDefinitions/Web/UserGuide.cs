﻿using BankWizardOnlineSpecflow.Pages;
using NUnit.Framework;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class UserGuide
    {
        private readonly RemoteWebDriver _localDriver;

        private static BWO_UserGuide bwo_userguide;

        public UserGuide(RemoteWebDriver driver)
        {
            bwo_userguide= new BWO_UserGuide(driver);
            _localDriver = driver;
        }

        public void ClickLinksOnUserGuide(string eventItem)
        {
            string[] tempEventItem = eventItem.Split(",");

            _localDriver.Manage().Window.Maximize();

            Assert.Multiple(() =>
            {
                foreach (var eventitem in tempEventItem)
                {
                    bwo_userguide.ClickHyperLink(eventitem).Click();

                    WebFunctions.HighlightElement(bwo_userguide.HdrlinkText(eventitem.Trim()), _localDriver, true);

                    Assert.AreEqual(eventitem.Trim().ToUpper(), bwo_userguide.HdrlinkText(eventitem.Trim()).Text.Trim().ToUpper());

                    WebFunctions.HighlightElement(bwo_userguide.HdrlinkText(eventitem.Trim()), _localDriver, false);

                }

            });
        }

    }
}
