﻿using BankWizardOnlineSpecflow.Pages;
using NUnit.Framework;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class VerifyCard
    {

        // ReSharper disable once InconsistentNaming
        private static BWO_VerifyCard bwo_verifycard;
        // ReSharper disable once InconsistentNaming
        private static Dictionary<string, string> cardDetailsStatus;
        // ReSharper disable once InconsistentNaming
        private static Dictionary<string, string> personalDetailsStatus;
        // ReSharper disable once InconsistentNaming
        private static Dictionary<string, string> addressDetailsStatus;
        // ReSharper disable once InconsistentNaming
        private static Dictionary<string, string> extraFieldStatus1;


        public VerifyCard(RemoteWebDriver driver)
        {
            bwo_verifycard = new BWO_VerifyCard(driver);
        }

        public void VerificataionTypeSelection(string fieldKeyAndValues)
        {
            switch (fieldKeyAndValues.Trim().ToUpper())
            {
                case "VERIFY ADDRESS AND CVV":
                    bwo_verifycard.btnradioVerifyAddressAndCvv.Click();

                    break;

                case "VERIFY CARD HOLDER DETAILS":
                    bwo_verifycard.btnradioVerifyCardHolderDetails.Click();

                    break;

            }

        }

        public void SectionFieldStatus(string verificataionType, string headerSelection, string status)
        {
            CardDetailsDisplayStatus(verificataionType);
            AddressDetailsDisplayStatus();

            if (verificataionType.Trim().ToUpper() == "VERIFY CARD HOLDER DETAILS")
            {
                PersonalDetailsDisplayStatus();

                Assert.Multiple(() =>
                {
                    foreach (var (key, value) in personalDetailsStatus)
                    {
                        Assert.AreEqual(bool.Parse(status), bool.Parse(value),
                            key + " Display Status Is Not " + status);
                    }

                });

            }

            Assert.Multiple(() =>
            {
                foreach (var (key, value) in cardDetailsStatus)
                {
                    Assert.AreEqual(bool.Parse(status), bool.Parse(value), key + " Display Status Is Not " + status);
                }

                foreach (var (key, value) in addressDetailsStatus)
                {
                    Assert.AreEqual(bool.Parse(status), bool.Parse(value), key + " Display Status Is Not " + status);
                }

            });

        }


        public void ExtraFieldStatus(string extraField, string extraFieldStatus)
        {
            ExtraFieldsDisplayStatus(extraField);

            Assert.Multiple(() =>
            {
                foreach (var (key, value) in extraFieldStatus1)
                {
                    Assert.AreEqual(bool.Parse(extraFieldStatus), bool.Parse(value),
                        key + " Display Status Is Not " + extraFieldStatus);
                }
            });
        }

        private void CardDetailsDisplayStatus(string verificataionType)
        {
            //string verificataionType = "VERIFY ADDRESS AND CVV";

            cardDetailsStatus = new Dictionary<string, string>
            {
                ["CardNumber"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtCardNumber)),
                ["ValidFromMonth"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtValidFromMonth)),
                ["ValidFromYear"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtValidFromYear)),
                ["ExpiresMonth"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtExpiresMonth)),
                ["ExpiresYear"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtExpiresMonth)),
                ["SecurityCodeCVV"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtSecurityCode)),
                ["IssueNumber"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtIssueNumber))
            };


            if (verificataionType.Trim().ToUpper() == "VERIFY ADDRESS AND CVV")
            {
                cardDetailsStatus["IsTheCustomerPresent"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.checkboxCustPresent));
                cardDetailsStatus["CardType"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.checkboxCustPresent));
                cardDetailsStatus["NameOnTheCard"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtNameOnCard));
            }
        }

        private void PersonalDetailsDisplayStatus()
        {
            personalDetailsStatus = new Dictionary<string, string>
            {
                ["FirstName"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtFirstName)),
                ["SurName"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtSurname)),
                ["DateOfBirth"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtDob))
            };
        }

        private void AddressDetailsDisplayStatus()
        {
            addressDetailsStatus = new Dictionary<string, string>
            {
                ["HouseNumber"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtHouseNumber)),
                ["Flat"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtFlat)),
                ["HouseName"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtHouseName)),
                ["Street"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtStreet)),
                ["PostCode"] = Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtPostCode))
            };
        }

        private void ExtraFieldsDisplayStatus(string extraFields)
        {
            string[] tempExtrafields = extraFields.Split(",");

            extraFieldStatus1 = new Dictionary<string, string>
            {
                ["Is The Customer Present"] = Convert.ToString(Boolean.TrueString),
                ["Card Type"] = Convert.ToString(Boolean.TrueString),
                ["Name On The Card"] = Convert.ToString(Boolean.TrueString),
            };

            foreach (var field in tempExtrafields)
            {
                switch (field.Trim().ToUpper())
                {
                    case "IS THE CUSTOMER PRESENT":
                        extraFieldStatus1["Is The Customer Present"] =
                            Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.checkboxCustPresent));
                        break;
                    case "CARD TYPE":
                        extraFieldStatus1["Card Type"] =
                            Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.checkboxCustPresent));
                        break;
                    case "NAME ON THE CARD":
                        extraFieldStatus1["Name On The Card"] =
                            Convert.ToString(WebFunctions.IsElementVisible(bwo_verifycard.txtNameOnCard));
                        break;
                }
            }
        }

        public void VerifyCardsDataKeyIn(string headerSelection, string fieldKeyAndValues)
        {
            string[] tempfieldKeyandValues = fieldKeyAndValues.Split(",");

            switch (headerSelection.Trim().ToUpper())
            {

                case "VERIFY ADDRESS AND CVV":

                    if (tempfieldKeyandValues[0].Split(":")[1].Trim().ToUpper() == "YES")
                        bwo_verifycard.checkboxCustPresent.Click();

                    WebFunctions.ElementIsVisible(bwo_verifycard.dropdownCardType);

                    var selectCardType = new SelectElement(bwo_verifycard.dropdownCardType);

                    if (WebFunctions.DropDownValueCheck(bwo_verifycard.dropdownCardType,
                            tempfieldKeyandValues[1].Split(":")[1].Trim()) !=
                        "") selectCardType.SelectByText(tempfieldKeyandValues[1].Split(":")[1].Trim());

                    bwo_verifycard.txtCardNumber.SendKeys(tempfieldKeyandValues[2].Split(":")[1].Trim().ToUpper());

                    var validityStartDate = tempfieldKeyandValues[3].Split(":")[1].Split("/");

                    bwo_verifycard.txtValidFromMonth.SendKeys(validityStartDate[0].Trim());

                    bwo_verifycard.txtValidFromYear.SendKeys(validityStartDate[1].Trim());

                    var validityExpiryDate = tempfieldKeyandValues[4].Split(":")[1].Split("/");

                    bwo_verifycard.txtExpiresMonth.SendKeys(validityExpiryDate[0].Trim());

                    bwo_verifycard.txtExpiresYear.SendKeys(validityExpiryDate[1].Trim());

                    bwo_verifycard.txtSecurityCode.SendKeys(tempfieldKeyandValues[5].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtIssueNumber.SendKeys(tempfieldKeyandValues[6].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtNameOnCard.SendKeys(tempfieldKeyandValues[7].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtHouseNumber.SendKeys(tempfieldKeyandValues[8].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtFlat.SendKeys(tempfieldKeyandValues[9].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtHouseName.SendKeys(tempfieldKeyandValues[10].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtStreet.SendKeys(tempfieldKeyandValues[11].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtPostCode.SendKeys(tempfieldKeyandValues[12].Split(":")[1].Trim().ToUpper());

                    break;

                case "VERIFY CARD HOLDER DETAILS":

                    bwo_verifycard.txtCardNumber.SendKeys(tempfieldKeyandValues[0].Split(":")[1].Trim().ToUpper());

                    var startDate = tempfieldKeyandValues[1].Split(":")[1].Split("/");

                    bwo_verifycard.txtValidFromMonth.SendKeys(startDate[0].Trim());

                    bwo_verifycard.txtValidFromYear.SendKeys(startDate[1].Trim());

                    var expiryDate = tempfieldKeyandValues[2].Split(":")[1].Split("/");

                    bwo_verifycard.txtExpiresMonth.SendKeys(expiryDate[0].Trim());

                    bwo_verifycard.txtExpiresYear.SendKeys(expiryDate[1].Trim());

                    bwo_verifycard.txtSecurityCode.SendKeys(tempfieldKeyandValues[3].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtIssueNumber.SendKeys(tempfieldKeyandValues[4].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtFirstName.SendKeys(tempfieldKeyandValues[5].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtSurname.SendKeys(tempfieldKeyandValues[6].Split(":")[1].Trim().ToUpper());

                    var temp_dob = tempfieldKeyandValues[7].Split(":")[1].Trim().ToUpper();

                    bwo_verifycard.txtDob.Click();

                    foreach (var date in temp_dob) { bwo_verifycard.txtDob.SendKeys(date.ToString()); }

                    bwo_verifycard.txtHouseNumber.SendKeys(tempfieldKeyandValues[8].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtFlat.SendKeys(tempfieldKeyandValues[9].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtHouseName.SendKeys(tempfieldKeyandValues[10].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtStreet.SendKeys(tempfieldKeyandValues[11].Split(":")[1].Trim().ToUpper());

                    bwo_verifycard.txtPostCode.SendKeys(tempfieldKeyandValues[12].Split(":")[1].Trim().ToUpper());


                    break;
            }

        }
    }
}
