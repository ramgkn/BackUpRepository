﻿using BankWizardOnlineSpecflow.Pages;
using NUnit.Framework;
using OpenQA.Selenium.Remote;
using System;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class VerificationResultsCheck
    {

        private readonly RemoteWebDriver _localDriver;

        private static BwoVerfiyaccount bwo_verifyaccount;

        private static BWO_VerifyCard bwo_verifycard;

        public VerificationResultsCheck(RemoteWebDriver driver) => _localDriver = driver;

        public void VerificationResultscheck(string verificationForm, string expectedResult)
        {

            String[] tempExpectedResult = expectedResult.Split(",");



            switch (Convert.ToString(verificationForm).Trim().ToUpper())
            {
                case "COMPANY ACCOUNT CHECK":

                    bwo_verifyaccount = new BwoVerfiyaccount(_localDriver);

                    Assert.Multiple(() =>
                    {

                        StringAssert.Contains(tempExpectedResult[0].Split(":")[1].Trim().ToUpper(), bwo_verifyaccount.imgbxAccountMatchStatus.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[1].Split(":")[1].Trim().ToUpper(), bwo_verifyaccount.imgCompanyNameScore.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[2].Split(":")[1].Trim().ToUpper(), bwo_verifyaccount.imgCompanyNameAndAddressScore.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[3].Split(":")[1].Trim().ToUpper(), bwo_verifyaccount.imgCompanyTypeMatchStatus.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[4].Split(":")[1].Trim().ToUpper(), bwo_verifyaccount.imgRegistrationNumberMatchStatus.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[5].Split(":")[1].Trim().ToUpper(), bwo_verifyaccount.imgProprietorDetailsScore.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[6].Split(":")[1].Trim().ToUpper(), bwo_verifyaccount.imgAccountSetupDateScore.GetAttribute("src").ToUpper());

                    });

                    break;

                case "PERSONAL ACCOUNT CHECK":


                    break;

                case "VERIFY ADDRESS AND CVV":

                    bwo_verifycard = new BWO_VerifyCard(_localDriver);

                    Assert.Multiple(() =>
                    {
                        StringAssert.Contains(tempExpectedResult[0].Split(":")[1].Trim().ToUpper(), bwo_verifycard.imgCvvMatch.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[1].Split(":")[1].Trim().ToUpper(), bwo_verifycard.imgAvsMatch.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[2].Split(":")[1].Trim().ToUpper(), bwo_verifycard.imgPostCodeMatch.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[3].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblType.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[4].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblSubType.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[5].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblScheme.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[6].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblIssuer.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[7].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblDetails.Text.ToUpper());


                    });
                    break;

                case "VERIFY CARD HOLDER DETAILS":

                    bwo_verifycard = new BWO_VerifyCard(_localDriver);

                    Assert.Multiple(() =>
                    {

                        StringAssert.Contains(tempExpectedResult[0].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblOverallResult.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[1].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblCardCheckResult.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[2].Split(":")[1].Trim().ToUpper(), bwo_verifycard.imgPersonalDetailsScore.GetAttribute("src").ToUpper());

                        StringAssert.Contains(tempExpectedResult[3].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblAddressMatch.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[4].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblType.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[5].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblSubType.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[6].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblScheme.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[7].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblIssuer.Text.ToUpper());

                        StringAssert.Contains(tempExpectedResult[8].Split(":")[1].Trim().ToUpper(), bwo_verifycard.lblDetails.Text.ToUpper());

                    });
                    break;



            }
        }
    }
}
