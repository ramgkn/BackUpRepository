﻿using System;
using System.Linq;
using BankWizardOnlineSpecflow.Pages;
using BankWizardOnlineSpecflow.ReportHelper;
using etaf.generic.utilities;
using ETAF_WEB_UTILITIES.Scripted.Web;
using NUnit.Framework;
using OpenQA.Selenium.Remote;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    [Binding]
    public class BwoStepDefinition
    {

        private readonly RemoteWebDriver _driver;

        //Page Object Initiations.
        private static BwoLandingPage bwo_landingpage;

        private static BwoAdministration bwo_administration;

        private static BwoAdministrationEditAccount bwo_administrationeditaccount;

        private static BwoValidationIban bwo_validationiban;

        //Step definition initiations
        private static VerifyAccountDataKeyIn verifyaccountpagedatakeyin;

        private static PreferencesSetting preferences;

        private static BwoVaidateaAccount bwo_validateaccount;

        private static BwoValidationResultsCheckGeneric bwo_validationresultscheckgeneric;

        private static AdditionalInformationCheck additionalinformationcheck;

        private static BwoSearch bwo_search;

        private static AdministrationEditAccount administrationeditaccount;

        private static ValidataAccountDataKeyIn validataaccountdatakeyin;

        private static VerifyCard verifycard;

        private static UserGuide userguide;

        private static AdministrationManageAgreement administrationmanageagreement;


        public BwoStepDefinition(SeleniumContext seleniumContext)
        {

            this._driver = seleniumContext.WebDriver;

            administrationeditaccount = new AdministrationEditAccount(_driver);

            verifyaccountpagedatakeyin = new VerifyAccountDataKeyIn(_driver);

            bwo_validationiban = new BwoValidationIban(_driver);

            verifycard = new VerifyCard(_driver);

        }

        [Given(@"I Am Into User Authentication Services Page On (UAT|QAT) Environment")]
        public void GivenIAmIntoUserAuthenticationServicesPageOnEnvironment(string environment)
        {
            var authservicepage = environment.Trim().ToLower() + "_authservicepage";

            var servicePage = Convert.ToString(ReadWriteConfigFile.GetXMLData(SpecFlowHooks.BinderSpecFlowHooks.BasePath + @"Configuration\bwo_config.xml", authservicepage));

            _driver.Navigate().GoToUrl(servicePage);

        }

        [Given(@"I Log-in with Username")]
        [When(@"I Log-in with Username")]
        [Then(@"I Log-in with Username")]
        public void GivenILog_InWithUsername(Table username)
        {
            BwoLoginPage loginPage = new BwoLoginPage(_driver);

            dynamic credentials = username.CreateDynamicInstance();

            string tempCredentials = ReadWriteConfigFile.GetXMLData(SpecFlowHooks.BinderSpecFlowHooks.BasePath + @"Configuration\bwo_config.xml", credentials.username);

            loginPage.EnterUserNameAndPassword(credentials.username, tempCredentials.Split(",")[0]);

            loginPage.EnterPassPhrase(tempCredentials.Split(",")[1]);

            loginPage.ClickLogin();







        }

        [Then(@"I am into landing page with Title: (.*)")]
        public void ThenIAmIntoLandingPageWithTitle(string title)
        {
            Assert.AreEqual(title.ToUpper(), _driver.Title.ToUpper());
        }


        [Then(@"Clicked (SWIFT Data|Test) On Bank Wizard Validation Page")]
        public void ThenClickedOnBankWizardValidationPage(string datalinktoexpand)
        {
            additionalinformationcheck = new AdditionalInformationCheck(_driver);

            additionalinformationcheck.AdditonalInformationExpand(datalinktoexpand);
        }

        [Then(@"Looped through Amend Details (.*) times On (.*) Page")]
        public void ThenLoopedThroughAmendDetailsTimesOnPage(int loop, string headerPage)
        {
            bwo_validationresultscheckgeneric = new BwoValidationResultsCheckGeneric(_driver);

            bwo_validateaccount = new BwoVaidateaAccount(_driver);

            bwo_search = new BwoSearch(_driver);

            for (int ticker = 0; ticker <= loop; ticker++)
            {
                if (headerPage.Trim().ToUpper() == "SEARCH")
                {
                    bwo_search.btnSearch.Click();
                }
                else
                {
                    bwo_validationresultscheckgeneric.btAmendDetails.Click();

                    bwo_validateaccount.btnSubmitValidation.Click();
                }
            }

        }



        [Given(@"Clicked The (Preferences|User Guide|Verify Card|Validate IBAN|Validate Account|Add Account|Save|Administration|ValidateIBAN|Search|Verify Account|Verify|Global Lookup|.*) (Link|Button) On (.*) Page")]
        [When(@"Clicked The (Preferences|User Guide|Verify Card|Validate IBAN|Validate Account|Add Account|Save|Administration|ValidateIBAN|Search|Verify Account|Verify|Global Lookup|.*) (Link|Button) On (.*) Page")]
        [Then(@"Clicked The (Preferences|User Guide|Verify Card|Validate IBAN|Validate Account|Add Account|Save|Administration|ValidateIBAN|Search|Verify Account|Verify|Global Lookup|.*) (Link|Button) On (.*) Page")]
        public void ThenClickedTheOnPage(string eventItem, string eventAction, string eventPage)
        {

            if (eventPage.ToUpper() == "USER GUIDE")
            {
                userguide = new UserGuide(_driver);

                userguide.ClickLinksOnUserGuide(eventItem);

            }
            else
            {
                SearchEvent searchEvent = new SearchEvent(_driver);

                searchEvent.SearchEventActivity(eventItem, eventPage);
            }

        }


        [When(@"Clicked The (Validate IBAN|Validate Account|Add Account|Save|Administration|ValidateIBAN|Search|Search01|Test) (Link|Button)")]
        [Then(@"Clicked The (Validate IBAN|Validate Account|Add Account|Save|Administration|ValidateIBAN|Search|Search01|test) (Link|Button)")]
        public void ThenClickedOnThe(string headerToAction, string actionEvent)
        {

            bwo_landingpage = new BwoLandingPage(_driver);

            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(15);

            switch (Convert.ToString(headerToAction).ToUpper())
            {
                case "VALIDATE ACCOUNT":

                    bwo_landingpage.linkValidateaccount.Click();
                    break;


                case "VALIDATE IBAN":

                    bwo_landingpage.linkValidateIban.Click();
                    break;

                case "VERIFY ACCOUNT":

                    bwo_landingpage.linkVerifyaccount.Click();
                    break;

                case "SEARCH":

                    bwo_landingpage.linkSearch.Click();

                    break;

                case "GLOBAL LOOKUP":

                    bwo_landingpage.linkGloballookup.Click();
                    break;

                case "VERIFY CARD":

                    bwo_landingpage.linkVerifycard.Click();
                    break;

                case "HOME":

                    bwo_landingpage.linkHome.Click();
                    break;

                case "ADMINISTRATION":

                    bwo_landingpage.linkAdministration.Click();
                    break;


                case "CONFIGURATION":

                    bwo_landingpage.linkConfiguration.Click();
                    break;


                case "LOGOUT":

                    bwo_landingpage.linkLogout.Click();
                    break;

                case "PREFERENCES":

                    bwo_landingpage.linkPreferences.Click();
                    break;

                case "USER GUIDE":

                    bwo_landingpage.linkUserguide.Click();

                    break;

                case "ADD ACCOUNT":

                    bwo_administration = new BwoAdministration(_driver);

                    bwo_administration.hlinkAddaccount.Click();

                    break;

                case "SAVE":

                    bwo_administrationeditaccount = new BwoAdministrationEditAccount(_driver);

                    bwo_administrationeditaccount.btnsave.Click();

                    break;

                case "VALIDATEIBAN":

                    bwo_validationiban.btnValidate.Click();

                    break;
            }
        }


        [When(@"Filled-In (WASP Account|Company|Contact|Email|Customer Database ID|Experian Contact|IBAN|BIC|Bank|Country|Address|.*) Field With (.*)")]
        [Then(@"Filled-In (WASP Account|Company|Contact|Email|Customer Database ID|Experian Contact|IBAN|BIC|Bank|Country|Address|.*) Field With (.*)")]
        public void ThenIFilled_InEFieldWith(string fieldItem, string fieldValue)
        {
            administrationeditaccount.AdminstrationEditAccountDataKeyIn(fieldItem, fieldValue);
        }

        [Given(@"I Have Landed Onto (.*) Page To Do An (.*) Check")]
        [When(@"I Have Landed Onto (.*) Page To Do An (.*) Check")]
        [Then(@"I Have Landed Onto (.*) Page To Do An (.*) Check")]
        public void ThenThatIHaveLandedOntoPageToDoAnCheck(string header, string randomString)
        {

            switch (header.ToUpper())
            {
                case "USER PREFERENCES":
                case "BANK WIZARD IBAN VALIDATION":
                case "BANK WIZARD IBAN VALIDATION - RESULTS":
                    break;

                default:
                    _driver.Navigate().Refresh();
                    break;
            }
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            if (randomString.ToUpper() == "USER GUIDE") _driver.SwitchTo().Window(_driver.WindowHandles.Last());

            StringAssert.Contains(header.ToUpper(), _driver.Title.ToUpper());

            //Assert.AreEqual(header.ToUpper(), _driver.Title.ToUpper());

        }

        [Given(@"Filled-In (Account Details|Personal Details|Account Setup Date|Company Details|.*) Section With (accountdetails|personaldetails|accountsetupdate|companydetails|.*) On (.*) Page")]
        [When(@"Filled-In (Account Details|Personal Details|Account Setup Date|Company Details|.*) Section With (accountdetails|personaldetails|accountsetupdate|companydetails|.*) On (.*) Page")]
        [Then(@"Filled-In (Account Details|Personal Details|Account Setup Date|Company Details|.*) Section With (accountdetails|personaldetails|accountsetupdate|companydetails|.*) On (.*) Page")]
        public void ThenFilled_InSectionWithOnPage(string headerSelection, string fieldKeyAndValues, string eventPage)
        {

            if (eventPage.Trim().ToUpper() == "CARD VERIFICATION")
            {
                verifycard.VerifyCardsDataKeyIn(headerSelection, fieldKeyAndValues);

            }
            else verifyaccountpagedatakeyin.PopulateTextFieldOnVerifyAccountPage(headerSelection, fieldKeyAndValues);

        }

        [Then(@"Validated (.*) Field Dispaly Status is (.*)")]
        public void ThenValidatedFieldDispalyStatusIs(string extraFields, string extraFieldStatus)
        {
            verifycard.ExtraFieldStatus(extraFields, extraFieldStatus);

        }


        [Then(@"Validated (.*): (.*) Are In (.*) Status With (.*) Page")]
        public void ThenValidatedAreInStatusWithPage(string verificataionType, string fieldSection, string status, string pageHeader)
        {

            switch (pageHeader.Trim().ToUpper())
            {
                case "CARD VERIFICATION":

                    verifycard.SectionFieldStatus(verificataionType, fieldSection, status);

                    break;

            }


        }


        [Then(@"Selected (Type|Check Context|Owner Type|.*) as (verificationtype|checkcontext|ownertype|.*) On (.*) Page")]
        public void ThenSelectedAsOnPage(string headerSelection, string fieldKeyAndValues, string eventPage)
        {
            switch (eventPage.Trim().ToUpper())
            {
                case "BANK WIZARD VERIFICATION":
                    verifyaccountpagedatakeyin.PopulateRadioButtonOnVerifyAccountPage(headerSelection, fieldKeyAndValues);
                    break;

                case "CARD VERIFICATION":
                    verifycard.VerificataionTypeSelection(fieldKeyAndValues);
                    break;

            }

        }

        [Given(@"Will Search For (.*) On (Account list|Test) Page")]
        [When(@"Will Search For (.*) On (Account list|Test) Page")]
        [Then(@"Will Search For (.*) On (Account list|Test) Page")]
        public void ThenWillSearchForOnPageAndClickOnTheSameForDeatiledView(string searchValue, string headerItem)
        {
            administrationeditaccount.AdministrationSearchWithInPage(searchValue);

        }

        [Then(@"Click On (.*) For Edit View")]
        public void ThenClickOnForEditView(string waspAccount)
        {
            administrationeditaccount.AdministrationClickForEditdView(waspAccount);
        }


        [Given(@"Validate (Company|Agreement type|Future agreement|Agreement status|Agreement tooltip) : (.*) On Account list Page For (.*)")]
        [When(@"Validate (Company|Agreement type|Future agreement|Agreement status|Agreement tooltip) : (.*) On Account list Page For (.*)")]
        [Then(@"Validate (Company|Agreement type|Future agreement|Agreement status|Agreement tooltip) : (.*) On Account list Page For (.*)")]
        public void ThenValidateOnAccountListPageFor(string fieldKey, string fieldValue, string header)
        {

            administrationeditaccount.AdministrationValidateAccountDetails(fieldKey, fieldValue);

        }


        [Given(@"Validated (.*) On (.*) Page Is (.*)")]
        [When(@"Validated (.*) On (.*) Page Is (.*)")]
        [Then(@"Validated (.*) On (.*) Page Is (.*)")]
        public void ThenValidatedOnBankWizardIBANValidation_ResultsPageIs(string lookOutHeader, string pageHeader, string displayStatus)
        {
            additionalinformationcheck = new AdditionalInformationCheck(_driver);

            additionalinformationcheck.AdditionalInformationDisplayStatusCheck(lookOutHeader, displayStatus);

        }

        [Given(@"Validated (.*) : (.*) On (.*) Page")]
        [When(@"Validated (.*) : (.*) On (.*) Page")]
        [Then(@"Validated (.*) : (.*) On (.*) Page")]
        public void ThenValidatedDetailsValidateOnIBANValidationPage(string headerToValidate, string validateDataPoints, string pageHeader)
        {
            additionalinformationcheck = new AdditionalInformationCheck(_driver);

            additionalinformationcheck.AdditionalInformationVerification(headerToValidate, validateDataPoints);

        }


        [Then(@"Cancel WASP Account: (.*)")]
        public void ThenCancelWaspAccount(string waspAccountNumber)
        {
            administrationeditaccount.AdministrationCancelAccount();
        }


        [Given(@"Select Country As: '(.*)', Bank-branch Code: '(.*)', Branch Code: (.*), Account number: (.*), Digit: (.*) and Click Validate Button")]
        [When(@"Select Country As: '(.*)', Bank-branch Code: '(.*)', Branch Code: (.*), Account number: (.*), Digit: (.*) and Click Validate Button")]
        [Then(@"Select Country As: '(.*)', Bank-branch Code: '(.*)', Branch Code: (.*), Account number: (.*), Digit: (.*) and Click Validate Button")]
        public void ThenKeyInSelectCountryAsBank_BranchCodeBranchCodeAccountNumberDigitCheckingLeavelAndClickValidateButton(string selectCountry, string bankBranchCode, string branchCode, string accountNumber, string chkDigit)
        {
            validataaccountdatakeyin = new ValidataAccountDataKeyIn(_driver);

            validataaccountdatakeyin.PopulateDataWithInFields(selectCountry, bankBranchCode, branchCode, accountNumber, chkDigit);

        }

        [Given(@"Selected Country: (.*) and (.*): (.*) on Search Page")]
        [When(@"Selected Country: (.*) and (.*): (.*) on Search Page")]
        [Then(@"Selected Country: (.*) and (.*): (.*) on Search Page")]

        public void ThenSelectedAndOnSearchPage(string country, string fieldHeader, string fieldValue)
        {
            SearchPageDataKeyIn searchpagedatakeyin = new SearchPageDataKeyIn(_driver);

            searchpagedatakeyin.PopulateSearchPage(country, fieldValue);
        }


        [Then(@"Verification Result Of (.*) Should Show (.*) On Bank Wizard Verification Page")]
        public void ThenVerificationResultOfShouldShowOnBankWizardVerificationPage(string verificationHeader, string expectedResult)
        {
            VerificationResultsCheck verificationresultcheck = new VerificationResultsCheck(_driver);

            verificationresultcheck.VerificationResultscheck(verificationHeader, expectedResult);
        }

        [Given(@"Set Preferences For Section (All|Account information section|SWIFT data section|Faster Payments data section|SEPA data section|Additional data section|.*) as (Hide|Show|.*)")]
        [When(@"Set Preferences For Section (All|Account information section|SWIFT data section|Faster Payments data section|SEPA data section|Additional data section|.*) as (Hide|Show|.*)")]
        [Then(@"Set Preferences For Section (All|Account information section|SWIFT data section|Faster Payments data section|SEPA data section|Additional data section|.*) as (Hide|Show|.*)")]
        public void GivenSetPreferencesForSectionAs(string sectionHeader, string sectionStatus)
        {
            preferences = new PreferencesSetting(_driver);

            if (sectionHeader.ToUpper() != "ALL") sectionHeader = sectionHeader + " SECTION";

            preferences.SetPreferences(sectionHeader, sectionStatus);

        }

        [When(@"Validation Result Of (.*) Should Show (.*)")]
        [Then(@"Validation Result Of (.*) Should Show (.*)")]
        public void ThenValidationResultOfShouldShow(string validationForm, string expectedResult)
        {
            ValidationResultsCheck validationResultsCheck = new ValidationResultsCheck(_driver);

            validationResultsCheck.ValidationResultCheck(validationForm, expectedResult);

        }

        [Given(@"Cancel (All|.*) In-Force Agreements")]
        [When(@"Cancel (All|.*) In-Force Agreements")]
        [Then(@"Cancel (All|.*) In-Force Agreements")]
        public void ThenCancelIn_ForceAgreements(string agreementsStatus)
        {
            administrationmanageagreement = new AdministrationManageAgreement(_driver);

            administrationmanageagreement.CancelAgreements();
        }



        [Then(@"Validate (.*) : (.*) Error Message Is Displayed")]
        public void ThenValidateErrorMessageIsDisplayed(string field, string validationmessage)
        {          
            administrationeditaccount.ValidationMessage(field, validationmessage);
        }



        [Given(@"Validate Agreement In-Force Satus: (.*) Using (.*)")]
        [When(@"Validate Agreement In-Force Satus: (.*) Using (.*)")]
        [Then(@"Validate Agreement In-Force Satus: (.*) Using (.*)")]
        public void ThenValidateAgreementIn_ForceSatusUsing(string agreementsatus, string agreementtype)
        {
            administrationmanageagreement = new AdministrationManageAgreement(_driver);

            administrationmanageagreement.AgreementValidataionAssertion(agreementsatus);
        }


    }
}
