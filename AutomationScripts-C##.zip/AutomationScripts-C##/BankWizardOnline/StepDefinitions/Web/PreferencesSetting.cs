﻿using BankWizardOnlineSpecflow.Pages;
using OpenQA.Selenium.Remote;
using System;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class PreferencesSetting
    {
        private readonly RemoteWebDriver _localDriver;

        private static BwoPreferences bwo_preferences;

        private static int selectionIndex = 1;

        public PreferencesSetting(RemoteWebDriver driver) => _localDriver = driver;

        public void SetPreferences(string sectionHeader, string sectionStatus)
        {
            bwo_preferences = new BwoPreferences(_localDriver);

            if (sectionStatus != "N/A")
            {
                if (sectionStatus.ToUpper() == "HIDE") selectionIndex = 2;

                switch (Convert.ToString(sectionHeader).Trim().ToUpper())
                {

                    case "ALL":

                        bwo_preferences.BtnradioAccountInformationSection(selectionIndex).Click();

                        bwo_preferences.BtnradioSwiftDataSection(selectionIndex).Click();

                        bwo_preferences.BtnradioFasterPaymentsDataSection(selectionIndex).Click();

                        bwo_preferences.BtnradioSepaDataSection(selectionIndex).Click();

                        bwo_preferences.BtnradioAdditionalDataSection(selectionIndex).Click();

                        break;

                    case "ACCOUNT INFORMATION SECTION":

                        bwo_preferences.BtnradioAccountInformationSection(selectionIndex).Click();

                        break;

                    case "SWIFT DATA SECTION":

                        bwo_preferences.BtnradioSwiftDataSection(selectionIndex).Click();

                        break;

                    case "FASTER PAYMENTS DATA SECTION":

                        bwo_preferences.BtnradioFasterPaymentsDataSection(selectionIndex).Click();

                        break;

                    case "SEPA DATA SECTION":

                        bwo_preferences.BtnradioSepaDataSection(selectionIndex).Click();

                        break;

                    case "ADDITIONAL DATA SECTION":

                        bwo_preferences.BtnradioAdditionalDataSection(selectionIndex).Click();

                        break;
                }
                
                selectionIndex = 1;
            }

        }
    }
}
