﻿using System;
using BankWizardOnlineSpecflow.Pages;
using NUnit.Framework;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class AdditionalInformationCheck
    {
        private readonly RemoteWebDriver _localDriver;

        private static BwoValidationIban bwo_bankwizardonlinevalidationiban;

        private static BwoAdditionalInformation bwo_additionalinformation;

        public AdditionalInformationCheck(RemoteWebDriver driver) => _localDriver = driver;

        public void AdditionalInformationVerification(string validateHeader, string validateDatapoints)
        {
            if (validateDatapoints != null && validateDatapoints != "N/A")
            {
                var tempvalidateDataPoints = validateDatapoints.Split(",");

                switch (Convert.ToString(validateHeader).ToUpper())
                {
                    case "DETAILS VALIDATE":

                        bwo_bankwizardonlinevalidationiban = new BwoValidationIban(_localDriver);

                        Assert.Multiple(() =>
                        {
                            Assert.AreEqual(tempvalidateDataPoints[0].Split(":")[0].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblDetailsCountry.Text.ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[0].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.valDetailsCountry.Text.ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[1].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblDetailsIban.Text.ToUpper());

                        });

                        break;

                    case "BBAN":

                        bwo_bankwizardonlinevalidationiban = new BwoValidationIban(_localDriver);

                        Assert.Multiple(() =>
                        {
                            Assert.AreEqual(tempvalidateDataPoints[0].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblBbanSortCode.Text.ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[1].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblBbanAccount.Text.ToUpper());

                        });
                        break;

                    case "BRANCH DETAILS":

                        bwo_bankwizardonlinevalidationiban = new BwoValidationIban(_localDriver);

                        Assert.Multiple(() =>
                        {
                            Assert.AreEqual(tempvalidateDataPoints[0].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblBranchName.Text.Split(Environment.NewLine)[1]
                                    .Trim().ToUpper());

                            var branchName =
                                bwo_bankwizardonlinevalidationiban.lblBranchSelection.Text.Split(Environment.NewLine);

                            Assert.AreEqual(tempvalidateDataPoints[1].Split(":")[1].ToUpper(),
                                branchName[1].Trim().ToUpper() + " " + branchName[2].Trim().ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[2].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblAddress1.Text.Split(Environment.NewLine)[1].Trim()
                                    .ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[3].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblAddress2.Text.Trim().ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[4].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblAddress3.Text.Trim().ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[5].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblAddressTown.Text.Trim().ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[6].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblAddressCounty.Text.Trim().ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[7].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblAddressPin.Text.Trim().ToUpper());

                            Assert.AreEqual(tempvalidateDataPoints[8].Split(":")[1].ToUpper(),
                                bwo_bankwizardonlinevalidationiban.lblAddressTelephone.Text.Split(Environment.NewLine)
                                    [1].Trim().ToUpper());

                        });
                        break;

                    case "SWIFT DATA":

                        bwo_additionalinformation = new BwoAdditionalInformation(_localDriver);

                        int swdTicker = 0;

                        Assert.Multiple(() =>
                        {
                            foreach (var detailsToValidated in tempvalidateDataPoints)
                            {
                                swdTicker += 1;

                                Assert.AreEqual(detailsToValidated.Split(":")[1].ToUpper(),
                                    bwo_additionalinformation.ValSwiftData(swdTicker).Text.Trim().ToUpper());

                            }

                        });
                        break;

                    case "FASTER PAYMENTS DATA":

                        bwo_additionalinformation = new BwoAdditionalInformation(_localDriver);

                        int fpdTicker = 0;

                        Assert.Multiple(() =>
                        {
                            foreach (var detailsToValidated in tempvalidateDataPoints)
                            {
                                fpdTicker += 1;

                                Assert.AreEqual(detailsToValidated.Split(":")[1].ToUpper(),
                                    bwo_additionalinformation.ValFasterPaymentsData(fpdTicker).Text.Trim().ToUpper());

                            }

                        });
                        break;

                    case "SEPA DATA":

                        bwo_additionalinformation = new BwoAdditionalInformation(_localDriver);

                        int sepaTicker = 0;

                        Assert.Multiple(() =>
                        {
                            foreach (var detailsToValidated in tempvalidateDataPoints)
                            {
                                sepaTicker += 1;

                                Assert.AreEqual(detailsToValidated.Split(":")[1].ToUpper(),
                                    bwo_additionalinformation.ValSepaData(sepaTicker).Text.Trim().ToUpper());

                            }

                        });
                        break;

                }
            }

        }

        public void AdditionalInformationDisplayStatusCheck(string lookOutHeader, string displayStatus)
        {
            bwo_additionalinformation = new BwoAdditionalInformation(_localDriver);

            string imgeName = string.Empty;

            switch (Convert.ToString(lookOutHeader).Trim().ToUpper())
            {
                case "SWIFT DATA":
                    imgeName = bwo_additionalinformation.imgSwiftData.GetAttribute("src").Trim().ToUpper();
                    break;

                case "FASTER PAYMENTS DATA":
                    imgeName = bwo_additionalinformation.imgFasterPaymentsData.GetAttribute("src").Trim().ToUpper();
                    break;

                case "SEPA DATA":
                    imgeName = bwo_additionalinformation.imgSepaData.GetAttribute("src").Trim().ToUpper();
                    break;

                case "ADDITIONAL DATA":
                    imgeName = bwo_additionalinformation.imgAdditionalData.GetAttribute("src").Trim().ToUpper();
                    break;

            }

            if (displayStatus.Trim().ToUpper() == "EXPANDED")
            {
                Assert.IsTrue(imgeName.Contains("UPARROW.GIF"), lookOutHeader + " Status Is Collapsed!!!");
            }
            else
            {
                Assert.IsTrue(imgeName.Contains("DOWNARROW.GIF"), lookOutHeader + " Status Is Expanded!!!");
            }

        }

        public void AdditonalInformationExpand(string datalinktoexpand)
        {

            bwo_additionalinformation = new BwoAdditionalInformation(_localDriver);

            switch (Convert.ToString(datalinktoexpand).ToUpper())
            {

                case "ACCOUNT INFORMATION":
                    bwo_additionalinformation.imgAccountInformation.Click();
                    break;

                case "SWIFT DATA":
                    bwo_additionalinformation.imgSwiftData.Click();
                    break;

                case "FASTER PAYMENTS DATA":
                    bwo_additionalinformation.imgFasterPaymentsData.Click();
                    break;

                case "SEPA DATA":
                    bwo_additionalinformation.imgSepaData.Click();
                    break;

                case "ADDITIONAL DATA":
                    bwo_additionalinformation.imgAdditionalData.Click();
                    break;
            }


        }
    }
}
