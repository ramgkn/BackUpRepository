﻿using BankWizardOnlineSpecflow.Pages;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class SearchPageDataKeyIn
    {
        private readonly RemoteWebDriver _localDriver;

        private static BwoVaidateaAccount bwo_vaidateaccountpage;

        private static BwoSearch bwo_searchpage;


        public SearchPageDataKeyIn(RemoteWebDriver driver)
        {
            _localDriver = driver;
            bwo_vaidateaccountpage = new BwoVaidateaAccount(driver);
            bwo_searchpage = new BwoSearch(driver);
        }

        public void PopulateSearchPage(string country, string fieldValue)
        {

            WebFunctions.ElementIsVisible(bwo_vaidateaccountpage.dlistCountry);

            var selectCountry = new SelectElement(bwo_vaidateaccountpage.dlistCountry);

            if (WebFunctions.DropDownValueCheck(bwo_vaidateaccountpage.dlistCountry, country) != "") selectCountry.SelectByText(country);

            _localDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);


            switch (country.Trim().ToUpper())
            {
                case "GERMANY":

                    WebFunctions.ElementIsVisible(bwo_searchpage.lblGermanybic);

                    bwo_searchpage.txtBicSearchInput.Click();

                    bwo_searchpage.txtBicSearchInput.SendKeys(fieldValue);

                    break;
            }

        }
    }
}
