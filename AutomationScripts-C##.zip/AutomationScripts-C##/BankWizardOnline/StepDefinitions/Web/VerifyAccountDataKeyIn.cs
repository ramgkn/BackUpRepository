﻿using BankWizardOnlineSpecflow.Pages;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class VerifyAccountDataKeyIn
    {
        private readonly RemoteWebDriver _localDriver;

        private static BwoVerfiyaccount bwo_verifyaccount;

        public VerifyAccountDataKeyIn(RemoteWebDriver driver) => _localDriver = driver;

        public void PopulateRadioButtonOnVerifyAccountPage(string hederSelection, string fieldKeyandValues)
        {
            bwo_verifyaccount = new BwoVerfiyaccount(_localDriver);

            string[] tempFieldKeyandValues = fieldKeyandValues.Split(",");

            switch (hederSelection.Trim().ToUpper())
            {
                case "VERIFICATION TYPE":

                    if (tempFieldKeyandValues[0].Trim().ToUpper() == "PERSONAL ACCOUNT CHECK")
                    { bwo_verifyaccount.radiobtnPersonalAccountCheck.Click(); }
                    else if (tempFieldKeyandValues[0].Trim().ToUpper() == "COMPANY ACCOUNT CHECK")
                    { bwo_verifyaccount.radiobtnCompanyAccountCheck.Click(); }

                    break;

                case "CHECK CONTEXT":
                    if (tempFieldKeyandValues[0].Trim().ToUpper() == "DIRECT DEBIT")
                    { bwo_verifyaccount.radiobtnDirectDebit.Click(); }
                    else if (tempFieldKeyandValues[0].Trim().ToUpper() == "DIRECT CREDIT")
                    { bwo_verifyaccount.radiobtnDirectCredit.Click(); }
                    break;

                case "OWNER TYPE":
                    if (tempFieldKeyandValues[0].Trim().ToUpper() == "SINGLE")
                    { bwo_verifyaccount.radiobtnSingle.Click(); }
                    else if (tempFieldKeyandValues[0].Trim().ToUpper() == "JOINT")
                    { bwo_verifyaccount.radiobtnJoint.Click(); }
                    break;


            }
        }

        public void PopulateTextFieldOnVerifyAccountPage(string headerSelection, string fieldKeyandValues)
        {
            bwo_verifyaccount = new BwoVerfiyaccount(_localDriver);

            string[] tempfieldKeyandValues = fieldKeyandValues.Split(",");

            switch (headerSelection.Trim().ToUpper())
            {
                case "ACCOUNT DETAILS":

                    bwo_verifyaccount.txtSortCode.SendKeys(GetFieldValue(tempfieldKeyandValues, 0));

                    bwo_verifyaccount.txtAccountNumber.SendKeys(GetFieldValue(tempfieldKeyandValues, 1));

                    break;

                case "PERSONAL DETAILS":

                    bwo_verifyaccount.txtFirstName.SendKeys(GetFieldValue(tempfieldKeyandValues, 0));

                    bwo_verifyaccount.txtSurname.SendKeys(GetFieldValue(tempfieldKeyandValues, 1));

                    bwo_verifyaccount.txtDateOfBirth.Click();

                    PopulateDateOfBirth(GetFieldValue(tempfieldKeyandValues, 2), headerSelection);

                    //bwo_verifyaccount.txtDateOfBirth.SendKeys(GetFieldValue(tempfieldKeyandValues, 2));

                    bwo_verifyaccount.txtHouseNumber.Click();

                    bwo_verifyaccount.txtHouseNumber.SendKeys(GetFieldValue(tempfieldKeyandValues, 3));

                    bwo_verifyaccount.txtFlat.SendKeys(GetFieldValue(tempfieldKeyandValues, 4));

                    bwo_verifyaccount.txtHouseName.SendKeys(GetFieldValue(tempfieldKeyandValues, 5));

                    bwo_verifyaccount.txtStreet.SendKeys(GetFieldValue(tempfieldKeyandValues, 6));

                    bwo_verifyaccount.txtPostcode.SendKeys(GetFieldValue(tempfieldKeyandValues, 7));

                    break;

                case "ACCOUNT SETUP DATE":

                    string[] tempAccountSetupDate = tempfieldKeyandValues[0].Split("-");

                    bwo_verifyaccount.txtAccountsetupDateYear.SendKeys(tempAccountSetupDate[0].Trim().ToUpper());

                    bwo_verifyaccount.txtAccountsetupDateMonth.SendKeys(tempAccountSetupDate[1].Trim().ToUpper());

                    bwo_verifyaccount.txtAccountsetupDateDay.SendKeys(tempAccountSetupDate[2].Trim().ToUpper());

                    break;

                case "COMPANY DETAILS":


                    bwo_verifyaccount.txtCompanyname.SendKeys(GetFieldValue(tempfieldKeyandValues, 0));

                    bwo_verifyaccount.txtCompanytype.SendKeys(GetFieldValue(tempfieldKeyandValues, 1));

                    bwo_verifyaccount.txtRegistrationnumber.SendKeys(GetFieldValue(tempfieldKeyandValues, 2));

                    bwo_verifyaccount.txtCompanyBuildingnumber.SendKeys(GetFieldValue(tempfieldKeyandValues, 3));

                    bwo_verifyaccount.txtCompanyflat.SendKeys(GetFieldValue(tempfieldKeyandValues, 4));

                    bwo_verifyaccount.txtCompanyBuildingname.SendKeys(GetFieldValue(tempfieldKeyandValues, 5));

                    bwo_verifyaccount.txtCompanystreet.SendKeys(GetFieldValue(tempfieldKeyandValues, 6));

                    bwo_verifyaccount.txtCompanypostcode.SendKeys(GetFieldValue(tempfieldKeyandValues, 7));

                    bwo_verifyaccount.txtCompanyPropFirstName.SendKeys(GetFieldValue(tempfieldKeyandValues, 8));

                    bwo_verifyaccount.txtCompanyPropSurname.SendKeys(GetFieldValue(tempfieldKeyandValues, 9));

                    bwo_verifyaccount.txtCompanyPropDob.Click();

                    PopulateDateOfBirth(GetFieldValue(tempfieldKeyandValues, 10), headerSelection);

                    //bwo_verifyaccount.txtCompanyPropDob.SendKeys(GetFieldValue(tempfieldKeyandValues, 10));
                    
                    break;


            }
        }

        private static string GetFieldValue(string[] pairKeyValue, int index)
        {
            string fieldValue = pairKeyValue[index].Split(":")[1].Trim().ToUpper();

            return fieldValue;
        }

        private void PopulateDateOfBirth(string dateOfBirth, string section)
        {
            //bwo_administrationManageAgrements.txtAgreementEndDate.Click();

            foreach (var date in dateOfBirth)
            {
                switch (section.Trim().ToUpper())
                {
                    case "PERSONAL DETAILS":

                        bwo_verifyaccount.txtDateOfBirth.SendKeys(date.ToString());

                        break;

                    case "COMPANY DETAILS":

                        bwo_verifyaccount.txtCompanyPropDob.SendKeys(date.ToString());

                        break;
                }

                

                //System.Threading.Thread.Sleep(1000);
            }
        }

    }
}
