﻿using BankWizardOnlineSpecflow.Pages;
using NUnit.Framework;
using OpenQA.Selenium.Remote;
using System;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class ValidationResultsCheck
    {
        private readonly RemoteWebDriver _localDriver;

        private static BwoSearch bwo_searchpage;

        private static BwoValidationResultsCheckGeneric bwo_validationresultscheckgeneric;

        private static BwoGlobalLookUp bwo_globallookup;

        private static BWO_VerifyCard bwo_verifycard;

        public ValidationResultsCheck(RemoteWebDriver driver)
        {
            this._localDriver = driver;

            bwo_searchpage = new BwoSearch(driver);

        }

        public void ValidationResultCheck(string validationForm, string expectedResult)
        {
            String[] tempExpectedResult = expectedResult.Split(",");

            bwo_validationresultscheckgeneric = new BwoValidationResultsCheckGeneric(_localDriver);

            switch (Convert.ToString(validationForm).Trim().ToUpper())
            {
                case "SEARCH":

                    bwo_searchpage = new BwoSearch(_localDriver);

                    StringAssert.Contains(tempExpectedResult[0], Convert.ToString(bwo_searchpage.imgSearchResult.GetAttribute("alt")));

                    break;

                case "GLOBAL LOOKUP":

                    bwo_globallookup = new BwoGlobalLookUp(_localDriver);

                    StringAssert.Contains(tempExpectedResult[0], Convert.ToString(bwo_globallookup.imgvalidationresult.GetAttribute("alt")));

                    break;

                case "VERIFY ADDRESS AND CVV":


                    bwo_verifycard = new BWO_VerifyCard(_localDriver);

                    StringAssert.Contains(tempExpectedResult[0], Convert.ToString(bwo_verifycard.imgOverallResult.GetAttribute("src")));

                    break;

                case "VERIFY CARD HOLDER DETAILS":

                    bwo_verifycard = new BWO_VerifyCard(_localDriver);

                    StringAssert.Contains(tempExpectedResult[0], Convert.ToString(bwo_verifycard.imgMatchingResult.GetAttribute("src")));

                    break;


                case "FIELDVALIDATION":

                    bwo_verifycard = new BWO_VerifyCard(_localDriver);

                    var fldTicker = 0;

                    tempExpectedResult = expectedResult.Split(";");

                    if (tempExpectedResult.Length == 1)
                    {
                        Assert.AreEqual(tempExpectedResult[0].ToUpper(), bwo_verifycard.lblValidationSummary1.Text.Trim().ToUpper());

                    }
                    else if (tempExpectedResult.Length > 1)
                    {
                        foreach (var expectedresult in tempExpectedResult)
                        {
                            var ticker = fldTicker;

                            Assert.Multiple(() =>
                            {
                                Assert.AreEqual(expectedresult.ToUpper(),
                                    bwo_verifycard.LblValidationSummary(ticker + 1).Text.Trim().ToUpper());
                            });

                            fldTicker += 1;
                        }
                    }

                    break;

                default:

                    StringAssert.Contains(tempExpectedResult[0], Convert.ToString(bwo_validationresultscheckgeneric.imgvalidationChk.GetAttribute("src")));
                    break;

            }


            if (tempExpectedResult.Length > 1 && Convert.ToString(validationForm).Trim().ToUpper() != "FIELDVALIDATION")
            {

                if (Convert.ToString(validationForm).Trim().ToUpper() == "SEARCH")
                {
                    StringAssert.Contains(tempExpectedResult[1].Split("-")[0], bwo_searchpage.valnumberofmathces.GetAttribute("value"));
                }
                else if (tempExpectedResult[1].Split(" ")[0].Trim().ToUpper() == "ERROR")
                {
                    StringAssert.Contains(tempExpectedResult[1], Convert.ToString(bwo_validationresultscheckgeneric.msgvalidationerrChk.Text));
                }
                else if (tempExpectedResult[1].Split(" ")[0].Trim().ToUpper() == "WARNING")
                {
                    StringAssert.Contains(tempExpectedResult[1], Convert.ToString(bwo_validationresultscheckgeneric.msgvalidationwarningChk.Text));
                }

                if (tempExpectedResult.Length > 2) StringAssert.Contains(tempExpectedResult[2], Convert.ToString(bwo_validationresultscheckgeneric.msgvalidationChk.Text));

            }

        }
    }
}
