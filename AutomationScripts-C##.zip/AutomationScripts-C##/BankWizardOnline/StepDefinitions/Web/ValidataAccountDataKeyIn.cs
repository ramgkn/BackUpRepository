﻿using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using BankWizardOnlineSpecflow.Pages;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class ValidataAccountDataKeyIn
    {
        private readonly RemoteWebDriver _localDriver;

        private static BwoVaidateaAccount bwo_validateaccount;

        public ValidataAccountDataKeyIn(RemoteWebDriver driver) => _localDriver = driver;

        public void PopulateDataWithInFields(string country, string bankBranchCode, string branchCode, string accountNumber, string chkDigit)
        {
            bwo_validateaccount = new BwoVaidateaAccount(_localDriver);

            WebFunctions.ElementIsVisible(bwo_validateaccount.dlistCountry);

            var selectCountry = new SelectElement(bwo_validateaccount.dlistCountry);

            if (WebFunctions.DropDownValueCheck(bwo_validateaccount.dlistCountry, country) != "") selectCountry.SelectByText(country);

            _localDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            switch (country)
            {
                case "Austria":

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccountnumber);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(accountNumber);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankBranchcode);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(bankBranchCode);

                    break;

                case "Belgium":

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankBranchcode);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(bankBranchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccountnumber);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(accountNumber);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanCheckdigit);

                    bwo_validateaccount.txtBban3.Click();

                    bwo_validateaccount.txtBban3.SendKeys(chkDigit);

                    break;

                case "Netherlands":

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankidentifier);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(bankBranchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccountnumber);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(accountNumber);

                    break;

                case "Portugal":
                case "France":

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankcode);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(bankBranchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankbranchcode);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(branchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccountnumber);

                    bwo_validateaccount.txtBban3.Click();

                    bwo_validateaccount.txtBban3.SendKeys(accountNumber);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanCheckdigits);

                    bwo_validateaccount.txtBban4.Click();

                    bwo_validateaccount.txtBban4.SendKeys(chkDigit);

                    break;

                case "Spain":

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankcode);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(bankBranchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankbranchcode);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(branchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanCheckdigits);

                    bwo_validateaccount.txtBban3.Click();

                    bwo_validateaccount.txtBban3.SendKeys(chkDigit);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccountnumber);

                    bwo_validateaccount.txtBban4.Click();

                    bwo_validateaccount.txtBban4.SendKeys(accountNumber);

                    break;

                case "Italy":


                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanCheckdigits);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(chkDigit);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankcode);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(bankBranchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankbranchcode);

                    bwo_validateaccount.txtBban3.Click();

                    bwo_validateaccount.txtBban3.SendKeys(branchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccountnumber);

                    bwo_validateaccount.txtBban4.Click();

                    bwo_validateaccount.txtBban4.SendKeys(accountNumber);

                    break;

                case "Germany":
                case "Denmark":


                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanBankBranchcode);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(bankBranchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccountnumber);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(accountNumber);

                    break;

                case "United Kingdom":


                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbansortcode);

                    bwo_validateaccount.txtBban1.Click();

                    bwo_validateaccount.txtBban1.SendKeys(bankBranchCode);

                    WebFunctions.ElementIsVisible(bwo_validateaccount.lblBbanAccount);

                    bwo_validateaccount.txtBban2.Click();

                    bwo_validateaccount.txtBban2.SendKeys(accountNumber);

                    break;
            }

            bwo_validateaccount.btnSubmitValidation.Click();
        }
    }
}