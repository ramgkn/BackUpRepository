﻿using System;
using BankWizardOnlineSpecflow.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class AdministrationManageAgreement
    {
        private readonly RemoteWebDriver _localDriver;

        private static Dictionary<string, string> agreementDetails;

        private static Dictionary<string, string> actionValidation;

        private static Dictionary<string, string> actionAccountVerification;

        private static Dictionary<string, string> actionSearch;

        private static Dictionary<string, string> actionCardVerification;

        private static Dictionary<string, string> inforcedataset;



        private static BWO_AdministrationManageAgrements bwo_administrationManageAgrements;

        public AdministrationManageAgreement(RemoteWebDriver driver) => _localDriver = driver;

        public void CancelAgreements()
        {

            bwo_administrationManageAgrements = new BWO_AdministrationManageAgrements(_localDriver);

            IWebElement tableAgreements = bwo_administrationManageAgrements.tblAgreements;

            IList<IWebElement> tableRow = tableAgreements.FindElements(By.TagName("tr"));

            for (int tblRow = 0; tblRow <= tableRow.Count; tblRow ++)
            {   

                tableAgreements = bwo_administrationManageAgrements.tblAgreements;

                IList<IWebElement> temptableRow = tableAgreements.FindElements(By.TagName("tr"));

                foreach (IWebElement row in temptableRow)
                {
                    IList<IWebElement> rowTd = row.FindElements(By.TagName("td"));

                    if (rowTd.Count > 0)
                    {
                        if (rowTd[3].Text.Equals("No") && rowTd[4].Text.Equals("Edit"))
                        {
                            rowTd[4].FindElement(By.TagName("a")).Click();

                            bwo_administrationManageAgrements.chkeckboxAgreementCancel.Click();

                            bwo_administrationManageAgrements.btnSave.Click();

                            tblRow = 0;

                            break;
                        }

                    }

                    tblRow += 1;
                }

            }

        }

        public void AgreementValidataionAssertion(string agreementsatus)
        {
            AgreemenInForceDataSet(agreementsatus);

            string expectedString = inforcedataset["StartDate"] + inforcedataset["EndDate"] + inforcedataset["AgreementType"] + inforcedataset["Cancelled"] + inforcedataset["EditLink"];

            expectedString = expectedString.Replace("N/A", "-").Replace(" ", "").ToUpper();

            string actualString = AgreementInForceValidataion(expectedString);

            NUnit.Framework.Assert.AreEqual(expectedString, actualString);

        }

        public string AgreementInForceValidataion(string expectedAgreement)
        {
            
            bwo_administrationManageAgrements = new BWO_AdministrationManageAgrements(_localDriver);

            IWebElement tableAgreements = bwo_administrationManageAgrements.tblAgreements;

            IList<IWebElement> tableRow = tableAgreements.FindElements(By.TagName("tr"));

            int tblRow = 1;

            string actualString = string.Empty;

            do
            {
                IList<IWebElement> temptableRow = tableAgreements.FindElements(By.TagName("tr"));

                string temRowColor = bwo_administrationManageAgrements.rowBackGroundColor(tblRow+1).GetCssValue("background-color").Replace(" ", "").ToUpper();
                

                if (temRowColor == inforcedataset["RowColor"].Replace(" ", "").ToUpper())
                {
                    actualString = temptableRow[tblRow].Text.Replace(" ", "").ToUpper();

                }

                if (expectedAgreement == actualString) break;

                actualString = string.Empty;

                tblRow += 1;


            } while (tblRow <= tableRow.Count);

           
            return actualString;
                       

        }

        public void FillInAgreementDetails(string fieldValue)
        {
            AgreementDetailsDataSet(fieldValue);

            
            bwo_administrationManageAgrements = new BWO_AdministrationManageAgrements(_localDriver);

            string agreementType = agreementDetails["Agreement Type"];

            WebFunctions.ElementIsVisible(bwo_administrationManageAgrements.dlistAgreementType);            

            var selectAgreementType = new SelectElement(bwo_administrationManageAgrements.dlistAgreementType);            

            if (WebFunctions.DropDownValueCheck(bwo_administrationManageAgrements.dlistAgreementType, agreementType) != "") selectAgreementType.SelectByText(agreementType);
                       
            PopulateStartDate(agreementDetails["StartDate"]);

            string temp_agreementtype = agreementType.Trim().ToUpper();

            if (temp_agreementtype == "EXPIRY DATE" || temp_agreementtype == "CLICK AND EXPIRY") { PopulateEndDate(agreementDetails["EndDate"]);}

            if (agreementDetails["Show EULA To This Customer"].ToUpper() == "YES") bwo_administrationManageAgrements.chkeckboxShowEula.Click();

            if (agreementDetails["Send Expiry Emails"].ToUpper() == "YES") bwo_administrationManageAgrements.chkeckboxWarnEmail.Click();

            if (agreementDetails["Show Reminders On Screen"].ToUpper() == "YES") bwo_administrationManageAgrements.chkeckboxShowReminderOnScreen.Click();

            if (agreementDetails["Reminder threshold"].ToUpper() != "")
            {
                bwo_administrationManageAgrements.txtReminderThreshold.Clear();

                bwo_administrationManageAgrements.txtReminderThreshold.SendKeys(agreementDetails["Reminder threshold"]);

            }

        }

        public void FillInActionDetails(string fieldValue)
        {
            bwo_administrationManageAgrements = new BWO_AdministrationManageAgrements(_localDriver);

            ActionDetailsDataSet(fieldValue);

            string action;

            if (actionValidation["Available"].ToUpper() == "YES")
            {
                action = "Validation";

                bwo_administrationManageAgrements.checkboxAvailable(action).Click();

                if (actionValidation["Click Limit"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtClickLimit(action).SendKeys(actionValidation["Click Limit"]);

                if (actionValidation["Send Reminder"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtSendReminder(action).SendKeys(actionValidation["Send Reminder"]);
            }

            if (actionAccountVerification["Available"].ToUpper() == "YES")
            {
                action = "Account Verification";

                bwo_administrationManageAgrements.checkboxAvailable(action).Click();

                if (actionValidation["Click Limit"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtClickLimit(action).SendKeys(actionAccountVerification["Click Limit"]);

                if (actionValidation["Send Reminder"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtSendReminder(action).SendKeys(actionAccountVerification["Send Reminder"]);

                if (actionAccountVerification["Personal Account"].ToUpper() == "YES") bwo_administrationManageAgrements.chkeckboxAccountVerificationPersonalAccount.Click();

                if (actionAccountVerification["Company Account"].ToUpper() == "YES") bwo_administrationManageAgrements.chkeckboxAccountVerificationCompanyAccount.Click();
            }

            if (actionSearch["Available"].ToUpper() == "YES")
            {
                action = "Search";

                bwo_administrationManageAgrements.checkboxAvailable(action).Click();

                if (actionValidation["Send Reminder"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtClickLimit(action).SendKeys(actionSearch["Click Limit"]);

                if (actionValidation["Send Reminder"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtSendReminder(action).SendKeys(actionSearch["Send Reminder"]);
            }

            if (actionCardVerification["Available"].ToUpper() == "YES")
            {
                action = "Card Verification";

                bwo_administrationManageAgrements.checkboxAvailable(action).Click();

                if (actionValidation["Send Reminder"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtClickLimit(action).SendKeys(actionCardVerification["Click Limit"]);

                if (actionValidation["Send Reminder"].ToUpper() != "N/A") bwo_administrationManageAgrements.txtSendReminder(action).SendKeys(actionCardVerification["Send Reminder"]);

                if (actionCardVerification["AvsCvv"].ToUpper() == "YES") bwo_administrationManageAgrements.chkeckboxCardVerificationAvsCvv.Click();

                if (actionCardVerification["Card Holder Match"].ToUpper() == "YES") bwo_administrationManageAgrements.chkeckboxCardVerificationCardHolderMatch.Click();
            }

        }

        private void AgreementDetailsDataSet(string fieldValue)
        {

            string[] tempfieldValue = fieldValue.Split(",");

            agreementDetails = new Dictionary<string, string>
            {
                ["Agreement Type"] = tempfieldValue[0].Split(":")[1],
                ["StartDate"] = tempfieldValue[1].Split(":")[1],
                ["EndDate"] = tempfieldValue[2].Split(":")[1],
                ["AgreementCancelled"] = tempfieldValue[3].Split(":")[1],
                ["Show EULA To This Customer"] = tempfieldValue[4].Split(":")[1],
                ["Send Expiry Emails"] = tempfieldValue[5].Split(":")[1],
                ["Show Reminders On Screen"] = tempfieldValue[6].Split(":")[1],
                ["Reminder threshold"] = tempfieldValue[7].Split(":")[1]
            };
        }

        private void ActionDetailsDataSet(string fieldValue)
        {
            string[] tempfieldValue = fieldValue.Split(",");

            actionValidation = new Dictionary<string, string>
            {
                ["Available"] = tempfieldValue[0].Split(":")[1],
                ["Click Limit"] = tempfieldValue[1].Split(":")[1],
                ["Click Count"] = tempfieldValue[2].Split(":")[1],
                ["Send Reminder"] = tempfieldValue[3].Split(":")[1]
            };

            actionAccountVerification = new Dictionary<string, string>
            {
                ["Available"] = tempfieldValue[4].Split(":")[1],
                ["Click Limit"] = tempfieldValue[5].Split(":")[1],
                ["Click Count"] = tempfieldValue[6].Split(":")[1],
                ["Send Reminder"] = tempfieldValue[7].Split(":")[1],
                ["Personal Account"] = tempfieldValue[8].Split(":")[1],
                ["Company Account"] = tempfieldValue[9].Split(":")[1],
            };

            actionSearch = new Dictionary<string, string>
            {
                ["Available"] = tempfieldValue[10].Split(":")[1],
                ["Click Limit"] = tempfieldValue[11].Split(":")[1],
                ["Click Count"] = tempfieldValue[12].Split(":")[1],
                ["Send Reminder"] = tempfieldValue[13].Split(":")[1]
            };

            actionCardVerification = new Dictionary<string, string>
            {
                ["Available"] = tempfieldValue[14].Split(":")[1],
                ["Click Limit"] = tempfieldValue[15].Split(":")[1],
                ["Click Count"] = tempfieldValue[16].Split(":")[1],
                ["Send Reminder"] = tempfieldValue[17].Split(":")[1],
                ["AvsCvv"] = tempfieldValue[18].Split(":")[1],
                ["Card Holder Match"] = tempfieldValue[19].Split(":")[1],
            };
        }

        //******************************************************************************
        private void AgreemenInForceDataSet(string fieldValue)
        {

            string[] tempfieldValue = fieldValue.Split(";");

            inforcedataset = new Dictionary<string, string>
            {
                ["RowColor"] = tempfieldValue[0].Split(":")[1],
                ["Cancelled"] = tempfieldValue[1].Split(":")[1],
                ["EditLink"] = tempfieldValue[2].Split(":")[1],
                ["StartDate"] = agreementDetails["StartDate"],
                ["EndDate"] = agreementDetails["EndDate"],
                ["AgreementType"] = agreementDetails["Agreement Type"]
            };
        }

        private void PopulateStartDate(string startDate)

        {
            string tempStartDate = startDate.ToUpper();

            if (tempStartDate != "N/A")
            {
                
                if (tempStartDate.Contains("TODAY")) tempStartDate = FormatDate(tempStartDate);

                agreementDetails["StartDate"] = tempStartDate;

                bwo_administrationManageAgrements.txtAgreementStartDate.Click();

                foreach (var date in tempStartDate)
                {
                    bwo_administrationManageAgrements.txtAgreementStartDate.SendKeys(date.ToString());

                    //System.Threading.Thread.Sleep(1000);
                }
            }
        }

        private void PopulateEndDate(string endDate)
        {
            string tempEndDate = endDate.ToUpper();

            if (tempEndDate != "N/A")
            {
                if (tempEndDate.Contains("TODAY")) tempEndDate = FormatDate(tempEndDate);

                agreementDetails["EndDate"] = tempEndDate;

                bwo_administrationManageAgrements.txtAgreementEndDate.Click();

                foreach (var date in tempEndDate)
                {
                    bwo_administrationManageAgrements.txtAgreementEndDate.SendKeys(date.ToString());

                    //System.Threading.Thread.Sleep(1000);
                }
            }
        }

        private static string FormatDate(string date)
        {
            string[] inputDate = date.ToUpper().Split("TODAY");

            string stringDate = DateTime.Today.AddDays(Convert.ToDouble(inputDate[1])).ToString("dd/MM/yyyy");

            return stringDate;
        }
    }
}
