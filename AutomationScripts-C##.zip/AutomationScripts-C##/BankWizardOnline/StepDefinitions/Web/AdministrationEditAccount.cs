﻿using BankWizardOnlineSpecflow.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using BankWizardOnlineSpecflow.ReportHelper;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class AdministrationEditAccount
    {
        private readonly RemoteWebDriver _localDriver;

        private string _tempWaspaccount;

        private int _rowIndex;

        private static BwoAdministrationEditAccount bwo_administrationeditaccount;

        private static BwoAdministration bwo_administration;

        private static BwoValidationIban bwo_validataioniban;

        private static BwoGlobalLookUp bwo_globallookup;

        private static AdministrationManageAgreement administrationmanageagreement;

        // ReSharper disable once InconsistentNaming
        [ThreadStatic]
        private static Dictionary<string, string> specificaccountDetail;// = new Dictionary<string, string>(6);

        public AdministrationEditAccount(RemoteWebDriver driver) => _localDriver = driver;

        public void AdminstrationEditAccountDataKeyIn(string fieldItem, string fieldValue)
        {
            bwo_administrationeditaccount = new BwoAdministrationEditAccount(_localDriver);

            bwo_globallookup = new BwoGlobalLookUp(_localDriver);

            switch (Convert.ToString(fieldItem).ToUpper())
            {

                case "WASP ACCOUNT":

                    Random randomNum = new Random();

                    _tempWaspaccount = randomNum.Next(0, 9999).ToString().PadLeft(6, '0');

                    bwo_administrationeditaccount.txtwaspaccounts.SendKeys(_tempWaspaccount);

                    SpecFlowHooks.BinderSpecFlowHooks.ExtraCommentsForSteps = ": " + _tempWaspaccount;

                    break;

                case "COMPANY":

                    bwo_administrationeditaccount.txtcompany.SendKeys(fieldValue);
                    break;

                case "CONTACT":

                    bwo_administrationeditaccount.txtcontact.SendKeys(fieldValue);
                    break;

                case "EMAIL":

                    bwo_administrationeditaccount.txtemail.SendKeys(fieldValue);
                    break;

                case "CUSTOMER DATABASE ID":

                    bwo_administrationeditaccount.txtcustomerdatabasdeid.SendKeys(fieldValue);
                    break;

                case "EXPERIAN CONTACT":

                    bwo_administrationeditaccount.txtexperiancontact.SendKeys(fieldValue);
                    break;

                case "IBAN":

                    bwo_validataioniban = new BwoValidationIban(_localDriver);

                    bwo_validataioniban.txtIban.SendKeys(fieldValue);

                    break;

                case "BIC":

                    bwo_globallookup.lblCategoryBic.SendKeys(fieldValue);

                    break;

                case "COUNTRY":

                    bwo_globallookup.lblCategoryCountry.SendKeys(fieldValue);

                    break;

                case "BANK":

                    bwo_globallookup.lblCategoryBank.SendKeys(fieldValue);

                    break;

                case "ADDRESS":

                    bwo_globallookup.lblCategoryAddress.SendKeys(fieldValue);

                    break;

                case "AGREEMENT DETAILS":

                    administrationmanageagreement = new AdministrationManageAgreement(_localDriver);

                    administrationmanageagreement.FillInAgreementDetails(fieldValue);

                    break;

                case "ACTION DETAILS":

                    administrationmanageagreement = new AdministrationManageAgreement(_localDriver);

                    administrationmanageagreement.FillInActionDetails(fieldValue);

                    break;

            }
        }

        public void AdministrationSearchWithInPage(string searchValue)
        {
            _localDriver.Navigate().Refresh();

            bwo_administration = new BwoAdministration(_localDriver);

            bwo_administrationeditaccount =  new BwoAdministrationEditAccount(_localDriver);

            if (searchValue.Trim().ToUpper() == "AUTO")
            {
                SpecFlowHooks.BinderSpecFlowHooks.ExtraCommentsForSteps = ": " + _tempWaspaccount;

                searchValue = _tempWaspaccount;

            }

            IWebElement tableElement = bwo_administrationeditaccount.tblaccounts;

            //rowIndex = WebFunctions.Searchindatatable(tableElement, wasp_account, 1);            

            _rowIndex = WebFunctions.RowIndexFromTable(tableElement, searchValue);

            specificaccountDetail = new Dictionary<string, string>(6)
            {
                {"Company", bwo_administration.HdrCompany(_rowIndex).Text},
                {"Agreement type", bwo_administration.HdrAgreementtype(_rowIndex).Text},
                {"Future agreement", bwo_administration.HdrFutureagreement(_rowIndex).Text},
                {"Agreement status", bwo_administration.ImgAgreementstatus(_rowIndex).GetAttribute("src")},
                {"Agreement tooltip", bwo_administration.ImgAgreementstatus(_rowIndex).GetAttribute("Title")}
            };

        }

        public void AdministrationClickForEditdView(string waspAccount)
        {
            bwo_administrationeditaccount = new BwoAdministrationEditAccount(_localDriver);

            bwo_administration = new BwoAdministration(_localDriver);

            IWebElement tableElement = bwo_administrationeditaccount.tblaccounts;

            if (waspAccount.Trim().ToUpper() == "AUTO") waspAccount = _tempWaspaccount;

            _rowIndex = WebFunctions.SearchInDataTable(tableElement, waspAccount, 1);

            bwo_administration.HdrWaspaccount(_rowIndex).Click();
        }

        public void AdministrationCancelAccount()
        {
            SpecFlowHooks.BinderSpecFlowHooks.ExtraCommentsForSteps = ": " + _tempWaspaccount;

            bwo_administrationeditaccount.chkCancelled.Click();

            bwo_administrationeditaccount.btnsave.Click();
        }

        public void AdministrationValidateAccountDetails(string fieldKey, string fieldValue)
        {

            StringAssert.Contains(fieldValue.ToUpper(), specificaccountDetail[fieldKey].ToUpper());

        }

        public void ValidationMessage(string fieldKey, string fieldValue)
        {
            string expectedResult = bwo_administrationeditaccount.fieldvalidationerror.Text.ToUpper();

            if (fieldKey.ToUpper().Contains("VALIDATION SUMMARY"))
            {
                expectedResult = bwo_administrationeditaccount.validationsummaryerrors.Text.ToUpper();

                expectedResult = expectedResult.Replace("\r\n", " ");
            }
                        
            StringAssert.Contains(fieldValue.ToUpper(), expectedResult.ToUpper());

        }
    }
}
