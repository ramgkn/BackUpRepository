﻿using BankWizardOnlineSpecflow.Pages;
using OpenQA.Selenium.Remote;
using System;

namespace BankWizardOnlineSpecflow.StepDefinitions.Web
{
    class SearchEvent
    {
        private readonly RemoteWebDriver _localDriver;

        //private static BwoSearch bwo_searchpage;

        private static BwoLandingPage bwo_landingpage;

        private static BwoValidationIban bwo_validationiban;

        private static BwoAdministration bwo_administration;

        private static BwoAdministrationEditAccount bwo_administrationeditaccount;

        private static BwoVerfiyaccount bwo_verifyaccount;

        private static BwoGenericEvents bwo_genericevents;

        private static BwoPreferences bwo_preferences;

        private static BWO_VerifyCard bwo_verifycard;

        private static BWO_AdministrationManageAgrements bwo_administrationmanageagrements;

        public SearchEvent(RemoteWebDriver driver) => _localDriver = driver;

        public void SearchEventActivity(string eventItem, string eventPage)
        {

            switch (Convert.ToString(eventPage).Trim().ToUpper())
            {
                case "BANK WIZARD SEARCH":

                    bwo_genericevents = new BwoGenericEvents(_localDriver);

                    if (eventItem.Trim().ToUpper() == "SEARCH") { bwo_genericevents.btnSearch.Click(); }

                    break;

                case "BANK WIZARD VALIDATION":

                    bwo_landingpage = new BwoLandingPage(_localDriver);

                    if (eventItem.Trim().ToUpper() == "SEARCH") { bwo_landingpage.linkSearch.Click(); }
                    else if (eventItem.Trim().ToUpper() == "VALIDATE ACCOUNT") { bwo_landingpage.linkValidateaccount.Click(); }
                    else if (eventItem.Trim().ToUpper() == "VALIDATE IBAN") { bwo_landingpage.linkValidateIban.Click(); }
                    else if (eventItem.Trim().ToUpper() == "ADMINISTRATION") { bwo_landingpage.linkAdministration.Click(); }
                    else if (eventItem.Trim().ToUpper() == "VERIFY ACCOUNT") { bwo_landingpage.linkVerifyaccount.Click(); }
                    else if (eventItem.Trim().ToUpper() == "GLOBAL LOOKUP") { bwo_landingpage.linkGloballookup.Click(); }
                    else if (eventItem.Trim().ToUpper() == "PREFERENCES") { bwo_landingpage.linkPreferences.Click(); }
                    else if (eventItem.Trim().ToUpper() == "VERIFY CARD") { bwo_landingpage.linkVerifycard.Click(); }
                    else if (eventItem.Trim().ToUpper() == "USER GUIDE") { bwo_landingpage.linkUserguide.Click(); }

                    break;

                case "BANK WIZARD IBAN VALIDATION":

                    bwo_validationiban = new BwoValidationIban(_localDriver);

                    if (eventItem.Trim().ToUpper() == "VALIDATE IBAN") { bwo_validationiban.btnValidate.Click(); }

                    break;

                case "ADMINISTER ACCOUNT":

                    bwo_administration = new BwoAdministration(_localDriver);

                    bwo_administrationeditaccount = new BwoAdministrationEditAccount(_localDriver);

                    if (eventItem.Trim().ToUpper() == "ADD ACCOUNT") { bwo_administration.hlinkAddaccount.Click(); }
                    else if (eventItem.Trim().ToUpper() == "SAVE") { bwo_administrationeditaccount.btnsave.Click(); }

                    break;

                case "BANK WIZARD VERIFICATION":

                    bwo_verifyaccount = new BwoVerfiyaccount(_localDriver);

                    if (eventItem.Trim().ToUpper() == "VERIFY") { bwo_verifyaccount.btnVerify.Click(); }

                    break;

                case "BANK WIZARD GLOBAL LOOKUP":

                    bwo_genericevents = new BwoGenericEvents(_localDriver);

                    bwo_genericevents.btnSearch.Click();

                    break;

                case "USER PREFERENCES":

                    bwo_preferences = new BwoPreferences(_localDriver);

                    bwo_preferences.BtnSave.Click();

                    break;

                case "CARD VERIFICATION":

                    bwo_verifycard = new BWO_VerifyCard(_localDriver);

                    bwo_verifycard.btnSubmitCardVerification.Click();

                    break;

                case "EDIT ACCOUNT":

                    _localDriver.Navigate().Refresh();

                    bwo_administrationmanageagrements = new BWO_AdministrationManageAgrements(_localDriver);

                    bwo_administrationmanageagrements.linkAddAgreement.Click();

                    break;

                case "AGREEMENT":

                    bwo_administrationmanageagrements = new BWO_AdministrationManageAgrements(_localDriver);

                    bwo_administrationmanageagrements.btnSave.Click();

                    break;


            }
        }
    }
}
