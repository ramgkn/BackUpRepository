﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using BoDi;
using etaf.api.utilities.CustomFunctions;
using etaf.generic.utilities;
using ETAF_WEB_UTILITIES.Scripted.Web;
using OpenQA.Selenium.Remote;
using Org.BouncyCastle.Bcpg.OpenPgp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using static ETAF_WEB_UTILITIES.Scripted.Web.SeleniumContext;

namespace BankWizardOnlineSpecflow.ReportHelper
{
    // ReSharper disable once ClassNeverInstantiated.Global
    class SpecFlowHooks
    {

        [Binding]
        public class BinderSpecFlowHooks
        {
            public static string BasePath;
            public static List<string>bwo_version = new List<string>();
            private static string coreconfigPath;
            private static string projectName;
            private static string runId;
            private static string stepStatus;
            private static string stepComment;
            private static string debugMode;
            private static string featureId;
            private static string scenarioId;
            private static string stepId;
            private static string nodeUrl;
            private static string scenarioStatus;
            private static string scenarioExecutionId;
            private static string jiraTicketInfo;
            private static string[] webtagLookup;
            private static readonly List<string> TicketAttachments = new List<string>();

            private readonly IObjectContainer _objectContainer;
            private static SeleniumContext seleniumContext;
            //private static FeatureContext _featureContext;


            //Global Variable for Extend report            
            private static AventStack.ExtentReports.ExtentReports extent;
            private ScenarioContext _scenarioContext;
            private RemoteWebDriver _driver;

            [ThreadStatic]
            public static string ExtraCommentsForSteps;
            [ThreadStatic]
            private static ExtentTest featureName;
            [ThreadStatic]
            private static ExtentTest scenario;
            [ThreadStatic]
            private static string hubBrowser;
            [ThreadStatic]
            private static Dictionary<String, String> scenarioDetailsForJira;


            // ReSharper disable once InconsistentNaming
            public BinderSpecFlowHooks(IObjectContainer objectContainer, ScenarioContext ScenarioContext, FeatureContext featureContext)
            {
                _objectContainer = objectContainer;
                //_featureContext = featureContext;
                _scenarioContext = ScenarioContext;

            }


            [BeforeTestRun]
            public static void InitializeReport()
            {

                // ReSharper disable once RedundantNameQualifier
                BasePath = System.IO.Path.GetFullPath(Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, @"..\"));

                coreconfigPath = BasePath + @"Configuration\ETAF_Core_Config.xml";

                Console.WriteLine("Execution In Progress For RunID: " + runId + " Project Name: " + projectName);

                debugMode = ReadWriteConfigFile.GetXMLData(coreconfigPath, "DebugMode");

                if ((runId == "ETAF" && debugMode.ToUpper() == "OFF") || (runId == null && debugMode.ToUpper() == "OFF"))
                {
                    string projectId = ReadWriteConfigFile.GetXMLData(coreconfigPath, "project_id");

                    string[] projectInfo = { projectId, "norun", "BDD-Specflow" };

                    runId = Database_Conn.DB_StoredProcedure("INSERT_RUN", projectInfo, BasePath, debugMode.ToUpper());

                    string[] etafRunId = { runId };

                    projectName = Database_Conn.DB_StoredProcedure("GET_PROJECT_NAME", etafRunId, BasePath, debugMode.ToUpper());

                }
                else
                {

                    projectName = "ETAF_PROJECT";

                    runId = "ETAF";
                }


                Console.WriteLine("Execution In Progress For RunID: " + runId + " Project Name: " + projectName);

                ExtentV3HtmlReporter htmlReporter = new ExtentV3HtmlReporter(BasePath + @"ExtentReport_Local\" + runId + @"\Local_Report_" + projectName + "_" + runId + "_" + DateTime.Now.ToString("mm_dd_yyyy_HHMMss") + ".html");

                htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;

                extent = new AventStack.ExtentReports.ExtentReports();

                extent.AttachReporter(htmlReporter);

            }

            [BeforeFeature]
            public static void BeforeFeature(FeatureContext featureContext)
            {

                scenarioDetailsForJira = new Dictionary<string, string>() { ["FeatureName"] = String.Empty, ["ScenarioTitle"] = String.Empty, ["TestSteps"] = String.Empty };

                featureName = extent.CreateTest<Feature>(featureContext.FeatureInfo.Title);

                string[] featureTags = featureContext.FeatureInfo.Tags.Select(s => s.ToUpperInvariant()).ToArray();

                if (featureTags.Contains("IGNORE")) featureName.Skip("Skipped");

                scenarioDetailsForJira["FeatureName"] = featureContext.FeatureInfo.Title;

            }

            [BeforeScenario]
            // ReSharper disable once InconsistentNaming
            public async Task BeforeScenarioAsync(ScenarioContext ScenarioContext, FeatureContext featureContext)
            {
                this._scenarioContext = ScenarioContext;

                scenarioStatus = "PASSED";

                webtagLookup = ScenarioContext.ScenarioInfo.Tags.Select(s => s.ToUpperInvariant()).ToArray();

                if (webtagLookup.Contains("ETAFFWEB"))
                {

                    hubBrowser = featureContext.FeatureInfo.Tags.First().ToUpper();

                    nodeUrl = ReadWriteConfigFile.GetNodeUrl(BasePath + @"ReportUtilities\\Grid_Start_Up\\gridConfig.xml", hubBrowser.ToUpper());

                    if (ApigeeHelper.CheckUrlExists(nodeUrl) == false)
                    {
                        Batch_File_Trigger.Run_Batch_File(BasePath + @"ReportUtilities\\Grid_Start_Up\\", "Grid_StartUp.bat");

                        await Task.Delay(5000);
                    }

                    BrowserType contextBrowser = (BrowserType)Enum.Parse(typeof(BrowserType), hubBrowser);

                    seleniumContext = new SeleniumContext(contextBrowser, BasePath, nodeUrl);

                    //*** enable browser capabilities for webbased testing: 

                    _objectContainer.RegisterInstanceAs(seleniumContext);

                    //*** enable browser capabilities for webbased testing: 

                    _driver = seleniumContext.WebDriver;
                }

                string[] featureInfo = { featureContext.FeatureInfo.Title, featureContext.FeatureInfo.Description, runId };

                featureId = Database_Conn.DB_StoredProcedure("insert_feature", featureInfo, BasePath, debugMode.ToUpper());

                string[] scenarioInfo = { _scenarioContext.ScenarioInfo.Title, _scenarioContext.ScenarioInfo.Title, featureId, hubBrowser };

                scenarioId = Database_Conn.DB_StoredProcedure("insert_scenario", scenarioInfo, BasePath, debugMode.ToUpper());

                string[] executionId = { runId, featureId, scenarioId };

                scenarioExecutionId = Database_Conn.DB_StoredProcedure("INSERT_SCENARIO_EXECUTION", executionId, BasePath, debugMode.ToUpper());

                scenario = featureName.CreateNode<Scenario>(_scenarioContext.ScenarioInfo.Title);

                scenarioDetailsForJira["ScenarioTitle"] = "Scenario: " + _scenarioContext.ScenarioInfo.Title;

            }

            [BeforeStep]
            public void BeforeStep()
            {
                stepStatus = "PASSED";

                stepComment = "";

                string[] scenarioStepInfo = { _scenarioContext.StepContext.StepInfo.Text, scenarioId, _scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString() };

                stepId = Database_Conn.DB_StoredProcedure("insert_step", scenarioStepInfo, BasePath, debugMode.ToUpper());

                string[] scenarioStepExecutionInfo = { stepStatus, scenarioExecutionId, stepId, _scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString() };

                Database_Conn.DB_StoredProcedure("insert_step_execution", scenarioStepExecutionInfo, BasePath, debugMode.ToUpper());

            }



            [AfterStep]
            public void AfterStep()
            {
                var stepType = _scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();

                scenarioDetailsForJira["TestSteps"] = scenarioDetailsForJira["TestSteps"] + Environment.NewLine + stepType + ": " + _scenarioContext.StepContext.StepInfo.Text;

                if (_scenarioContext.TestError == null)
                {
                    TestStepPassed(stepType);

                }
                else if (_scenarioContext.TestError != null)

                {
                    TestStepFailed(stepType);

                    string jiraStatus = ReadWriteConfigFile.GetXMLData(coreconfigPath, "JiraEnabled").ToUpper();

                    if (jiraStatus == "ON") CreateJiraTicket();

                    
                }

                if (_scenarioContext.ScenarioExecutionStatus == ScenarioExecutionStatus.StepDefinitionPending) StepDefinitionPending(stepType);

                ExtraCommentsForSteps = String.Empty;

                string[] stepExecutionStatus = { stepStatus, stepComment, stepId, stepType };

                Database_Conn.DB_StoredProcedure("update_step_execution_status", stepExecutionStatus, BasePath, debugMode.ToUpper());
            }

            [AfterScenario]
            public void CleanUp()
            {
                string[] scenarioExecutionStatus = { scenarioId, scenarioStatus };

                Database_Conn.DB_StoredProcedure("update_scenario_execution_status", scenarioExecutionStatus, BasePath, debugMode.ToUpper());

                //*** enable browser capabilities for webbased testing:

                if (webtagLookup.Contains("ETAFFWEB")) _driver.Quit();

                Console.WriteLine("Execution in progress for RunID = " + runId + " Project_Name= " + projectName);
            }

            [AfterTestRun]
            public static void TearDownReport()
            {

                if (debugMode.ToUpper() == "OFF")
                {

                    Console.WriteLine("Initiating Java Report Utility!");

                    Batch_File_Trigger.Run_Batch_File(BasePath + "ReportUtilities\\", "Trigger_Report_Master.bat", runId, projectName, nodeUrl);

                }
                else
                {

                    List<string> temp_bwo_version = bwo_version.Distinct().ToList();
                                        
                    extent.AddSystemInfo("BWO Version", string.Join(";", temp_bwo_version));
                    
                    //Flush report once test completes: 

                    extent.Flush();

                }

            }

            private void TestStepPassed(string stepType)
            {

                string stepInfoPass = _scenarioContext.StepContext.StepInfo.Text + ExtraCommentsForSteps;

                if (stepType == "Given")
                    scenario.CreateNode<Given>(stepType + ": " + stepInfoPass);
                else if (stepType == "When")
                    scenario.CreateNode<When>(stepType + ": " + stepInfoPass);
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(stepType + ": " + stepInfoPass);
                else if (stepType == "And")
                    scenario.CreateNode<And>(stepType + ": " + stepInfoPass);
            }


            private void TestStepFailed(string stepType)
            {
                stepStatus = "FAILED";

                string stepInfo = _scenarioContext.StepContext.StepInfo.Text + ExtraCommentsForSteps;

                if (stepType == "Given")
                {
                    scenario.CreateNode<Given>(stepType + ": " + stepInfo).Fail(_scenarioContext.TestError.Message);//ScenarioContext.Current.TestError.InnerException);
                    
                }
                else if (stepType == "When")
                {

                    scenario.CreateNode<When>(stepType + ": " + stepInfo).Fail(_scenarioContext.TestError.Message);

                }
                else if (stepType == "Then")
                {
                    scenario.CreateNode<Then>(stepType + ": " + stepInfo).Fail(_scenarioContext.TestError.Message);
                }

                stepComment = _scenarioContext.TestError.ToString();

                scenario.Log(Status.Fail, stepComment);

                if (webtagLookup.Contains("ETAFFWEB"))
                {
                    var screenshotAttachment = GetScreenShot.Capture(_driver, webtagLookup[0] + $"{DateTime.Now:_yyyyMMdd_HHmmssff}", BasePath);

                    TicketAttachments.Add(screenshotAttachment);

                    //*** enable browser capabilities for webbased testing: 

                    scenario.AddScreenCaptureFromPath(screenshotAttachment);

                }


            }

            private void StepDefinitionPending(string stepType)
            {
                if (stepType == "Given")
                    scenario.CreateNode<Given>(_scenarioContext.StepContext.StepInfo.Text).Skip("Step Definition Pending");
                else if (stepType == "When")
                    scenario.CreateNode<When>(_scenarioContext.StepContext.StepInfo.Text).Skip("Step Definition Pending");
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(_scenarioContext.StepContext.StepInfo.Text).Skip("Step Definition Pending");
            }

            private void CreateJiraTicket()
            {
                scenarioDetailsForJira["TestSteps"] = scenarioDetailsForJira["TestSteps"] + Environment.NewLine + "Failure Comment" + stepComment;

                Dictionary<string, string> jiraDetails = new Dictionary<string, string>();

                IList<string> jiraItems = new List<string>() { "JiraLink", "JiraUserName", "JiraPassword", "JiraProjectId" };

                foreach (string item in jiraItems)
                {
                    jiraDetails.Add(item, ReadWriteConfigFile.GetXMLData(coreconfigPath, item));
                }

                Dictionary<String, String> jiraTicketStatus = JiraExtension.CreateJiraTicket(jiraDetails["JiraLink"], jiraDetails["JiraUserName"], jiraDetails["JiraPassword"], jiraDetails["JiraProjectId"], scenarioDetailsForJira, TicketAttachments.ToArray());

                if (jiraTicketStatus != null) jiraTicketInfo = Environment.NewLine + " Action Taken: Jira Ticket Has been created:" + Environment.NewLine + "Ticket Number: <a href = '" + jiraTicketStatus["JiraTicketLink"] + "'>" + jiraTicketStatus["JiraTicket"] + "</a>";

                scenario.CreateNode<Then>(jiraTicketInfo).Fail("");

                stepComment = Convert.ToString(_scenarioContext.TestError.Message) + jiraTicketInfo;
            }

        }

    }

}
