﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoGenericEvents
    {
        private readonly RemoteWebDriver _driver;

        public BwoGenericEvents(RemoteWebDriver driver) => _driver = driver;

        public IWebElement btnSearch => _driver.FindElementByXPath("//*[@id='searchcategories']/fieldset/input[2]");

        public IWebElement btnHelp => _driver.FindElementByXPath("//input[@id='helplink']");
    }
}
