﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    public class BwoLandingPage
    {
        private readonly RemoteWebDriver _driver;

        public BwoLandingPage(RemoteWebDriver driver) => _driver = driver;

        public IWebElement linkValidateaccount => _driver.FindElementByXPath("//div[contains(text(),'Validate account')]");

        public IWebElement linkValidateIban => _driver.FindElementByXPath("//div[contains(text(),'Validate IBAN')]");

        public IWebElement linkVerifyaccount => _driver.FindElementByXPath("//div[contains(text(),'Verify account')]");

        public IWebElement linkSearch => _driver.FindElementByXPath("//div[contains(text(),'Search')]");

        public IWebElement linkGloballookup => _driver.FindElementByXPath("//div[contains(text(),'Global lookup')]");

        public IWebElement linkVerifycard => _driver.FindElementByXPath("//div[contains(text(),'Verify card')]");

        public IWebElement linkHome => _driver.FindElementByXPath("//div[contains(text(),'Home')]");

        public IWebElement linkAdministration => _driver.FindElementByXPath("//div[contains(text(),'Administration')]");

        public IWebElement linkConfiguration => _driver.FindElementByXPath("//div[contains(text(),'Configuration')]");

        public IWebElement linkLogout => _driver.FindElementByXPath("//div[contains(text(),'Logout')]");

        public IWebElement linkPreferences => _driver.FindElementByXPath("//div[contains(text(),'Preferences')]");

        public IWebElement linkUserguide => _driver.FindElementByXPath("//div[contains(text(),'User guide')]");

        public IWebElement hdrvalidationpage => _driver.FindElementByXPath("//h1[@class='content-header']");

        public IWebElement lblbwo_version => _driver.FindElementByXPath("//body/div[@id='wrapper']/div[@id='footer']/div[1]/div[2]");


    }


}

