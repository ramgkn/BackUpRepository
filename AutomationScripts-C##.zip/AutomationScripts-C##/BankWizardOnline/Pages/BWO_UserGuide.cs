﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    // ReSharper disable once InconsistentNaming
    class BWO_UserGuide
    {
        private readonly RemoteWebDriver _localDriver;

        public BWO_UserGuide(RemoteWebDriver driver) => _localDriver = driver;

        public IWebElement ClickHyperLink(string linkText) => _localDriver.FindElementByXPath("//a[contains(text(),'" + linkText + "')]");
        
        public IWebElement HdrlinkText(string linkText) => _localDriver.FindElementByXPath("//a[contains(text(),'" + linkText + "')]");

        public IWebElement linkWhatIsBankWizardOnline => _localDriver.FindElementByXPath("//a[contains(text(),'What is Bank Wizard Online')]");

        public IWebElement hdrWhatIsBankWizardOnline => _localDriver.FindElementByXPath("//h1[contains(text(),'What is Bank Wizard Online')]");

        public IWebElement linkValidatingAccounts => _localDriver.FindElementByXPath("//a[contains(text(),'Validating accounts')]");

        public IWebElement hdrValidatingAccounts => _localDriver.FindElementByXPath("//h1[contains(text(),'Validating accounts')]");

    }
}
