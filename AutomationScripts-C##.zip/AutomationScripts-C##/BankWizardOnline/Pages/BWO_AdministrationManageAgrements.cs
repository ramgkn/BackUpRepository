﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    // ReSharper disable once InconsistentNaming
    class BWO_AdministrationManageAgrements
    {
        private readonly RemoteWebDriver _localDriver;
        public BWO_AdministrationManageAgrements(RemoteWebDriver driver) => _localDriver = driver;

        public IWebElement tblAgreements => _localDriver.FindElementByXPath("//div[@id='content']//table");

        public IWebElement chkeckboxAgreementCancel => _localDriver.FindElementByXPath("//input[@id='Cancelled']");

        public IWebElement btnSave => _localDriver.FindElementByXPath("//input[@id='SubmitAdmin']");

        public IWebElement btnCancel => _localDriver.FindElementByXPath("//input[@id='cancel']");

        public IWebElement linkAddAgreement => _localDriver.FindElementByXPath("//a[contains(text(),'Add agreement')]");


        public IWebElement dlistAgreementType => _localDriver.FindElementByXPath("//select[@id='AgreementType']");

        public IWebElement txtAgreementStartDate => _localDriver.FindElementByXPath("//input[@id='StartDate']");

        public IWebElement txtAgreementEndDate => _localDriver.FindElementByXPath("//input[@id='EndDate']");

        public IWebElement chkeckboxShowEula => _localDriver.FindElementByXPath("//input[@id='Eval']");

        public IWebElement chkeckboxWarnEmail => _localDriver.FindElementByXPath("//input[@id='WarnEmail']");
        public IWebElement chkeckboxShowReminderOnScreen => _localDriver.FindElementByXPath("//input[@id='DisplayWarningOnScreen']");

        public IWebElement txtReminderThreshold => _localDriver.FindElementByXPath("//input[@id='expiryThreshold']");

        // ReSharper disable once InconsistentNaming
        public IWebElement checkboxAvailable(string action) => _localDriver.FindElementByXPath("//td[contains(text(),'" + action + "')]/following-sibling::td[1]/input");

        // ReSharper disable once InconsistentNaming
        public IWebElement txtClickLimit(string action) => _localDriver.FindElementByXPath("//td[contains(text(),'" + action + "')]/following-sibling::td[2]/input");

        // ReSharper disable once InconsistentNaming
        public IWebElement txtClickCount(string action) => _localDriver.FindElementByXPath("//td[contains(text(),'" + action + "')]/following-sibling::td[3]/input");

        // ReSharper disable once InconsistentNaming
        public IWebElement txtSendReminder(string action) => _localDriver.FindElementByXPath("//td[contains(text(),'" + action + "')]/following-sibling::td[4]/input");

        public IWebElement chkeckboxAccountVerificationPersonalAccount => _localDriver.FindElementByXPath("//input[@id='Actions_1__PersonalAccountCheck']");

        public IWebElement chkeckboxAccountVerificationCompanyAccount => _localDriver.FindElementByXPath("//input[@id='Actions_1__CompanyAccountCheck']");

        public IWebElement chkeckboxCardVerificationAvsCvv => _localDriver.FindElementByXPath("//input[@id='Actions_3__AvsCvvCheck']");

        public IWebElement chkeckboxCardVerificationCardHolderMatch => _localDriver.FindElementByXPath("//input[@id='Actions_3__CardHolderMatchCheck']");

        public IWebElement rowBackGroundColor(int rowID) => _localDriver.FindElementByXPath("//div[@id='content']//table//tr["+ rowID +"]");








    }
}
