﻿using System;
using BankWizardOnlineSpecflow.ReportHelper;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    public class BwoLoginPage
    {
        private readonly RemoteWebDriver _driver;

        private static BwoLandingPage bwo_landingpage;

        public BwoLoginPage(RemoteWebDriver driver) => _driver = driver;

        IWebElement txtUserName => _driver.FindElementByXPath("//input[@name='BAM_USERNAME']");

        IWebElement txtPassword => _driver.FindElementByXPath("//input[@name='BAM_PASSWORD']");

        IWebElement txtpassphrase1 => _driver.FindElementByXPath("//input[@name='PATHM_LTR1']");

        IWebElement lblpassphrase1 => _driver.FindElementByXPath("//ul[@class='passphrase-list']//li[1]");

        IWebElement txtpassphrase2 => _driver.FindElementByXPath("//input[@name='PATHM_LTR2']");

        IWebElement lblpassphrase2 => _driver.FindElementByXPath("//ul[@class='passphrase-list']//li[2]");

        IWebElement btnLogin => _driver.FindElementByXPath("//button[@class='btn btn-primary']");


        public void EnterUserNameAndPassword(string userName, string password)
        {
            txtUserName.SendKeys(userName);

            txtPassword.SendKeys(password);
        }

        public void EnterPassPhrase(string passphrase)
        {
            char passphrase1 = passphrase.ToCharArray()[Convert.ToInt32(lblpassphrase1.Text.Split(" ")[2])-1];

            char passphrase2 = passphrase.ToCharArray()[Convert.ToInt32(lblpassphrase2.Text.Split(" ")[2]) - 1];            

            txtpassphrase1.SendKeys(passphrase1.ToString());

            txtpassphrase2.SendKeys(passphrase2.ToString());

        }

        public void ClickLogin()
        {
            btnLogin.Click();

            SpecFlowHooks.BinderSpecFlowHooks.bwo_version.Add(bwo_version(_driver));
        }

        public static string bwo_version(RemoteWebDriver driver) 
        {
            bwo_landingpage = new BwoLandingPage(driver);

            return Convert.ToString(bwo_landingpage.lblbwo_version.Text);
        }
    }
}
