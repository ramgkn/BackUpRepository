﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    public  class BwoAdministrationEditAccount
    {
        private readonly RemoteWebDriver _driver;

        public BwoAdministrationEditAccount(RemoteWebDriver driver) => _driver = driver;

        //public IWebElement tblaccounts => _driver.FindElementByXPath("//div[@id='content']/child::h2[contains(text(),'Agreements')]/following-sibling::table");

        public IWebElement tblaccounts => _driver.FindElementByXPath("//table[@id='accounts']");

        public IWebElement txtwaspaccounts => _driver.FindElementByXPath("//*[@id='AccountNumber']");

        public IWebElement txtcompany => _driver.FindElementByXPath("//*[@id='Company']");

        public IWebElement txtcontact=> _driver.FindElementByXPath("//*[@id='Contact']");

        public IWebElement txtemail => _driver.FindElementByXPath("//*[@id='Email']");

        public IWebElement txtcustomerdatabasdeid => _driver.FindElementByXPath("//*[@id='Reference']");

        public IWebElement txtexperiancontact=> _driver.FindElementByXPath("//*[@id='SalesContact']");

        public IWebElement btnsave => _driver.FindElementByXPath("//*[@id='SubmitAdmin']");

        public IWebElement chkCancelled => _driver.FindElementByXPath("//*[@id='Cancelled']");

        public IWebElement btncancel => _driver.FindElementByXPath("//*[@id='cancel']");

        public IWebElement lnkhelp => _driver.FindElementByXPath("//*[@id='helplink']");

        public IWebElement fieldvalidationerror => _driver.FindElementByXPath("//span[@class='field-validation-error']");

        public IWebElement validationsummaryerrors => _driver.FindElementByXPath("//div[@class='validation-summary-errors']//ul");

        

    }


}
