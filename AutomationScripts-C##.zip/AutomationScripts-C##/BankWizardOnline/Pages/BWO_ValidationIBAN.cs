﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages

{
    class BwoValidationIban
    {
        private readonly RemoteWebDriver _localDriver;
        public BwoValidationIban(RemoteWebDriver driver) => _localDriver = driver;

        public IWebElement lblIban => _localDriver.FindElementByXPath("//label[@class='validate']");

        public IWebElement btnNewDetails => _localDriver.FindElementByXPath("//input[@id='newdetails']");

        public IWebElement btnAmendDetails => _localDriver.FindElementByXPath("//input[@id='amenddetails']");

        public IWebElement lnkHelp => _localDriver.FindElementByXPath("//input[@id='helplink']");


        public IWebElement txtIban => _localDriver.FindElementByXPath("//input[@id='IBAN']");

        public IWebElement btnValidate => _localDriver.FindElementByXPath("//input[@id='SubmitValidationIBAN']");

        public IWebElement hdrDetailsvalidated => _localDriver.FindElementByXPath("//h2[contains(text(),'Details validated')]");


        public IWebElement lblDetailsCountry => _localDriver.FindElementByXPath("//fieldset[1]//div[1]//child::label");
        

        public IWebElement valDetailsCountry => _localDriver.FindElementByXPath("//label[contains(text(),'Country')]/following-sibling::strong");

        public IWebElement lblDetailsIban => _localDriver.FindElementByXPath("//label[contains(text(),'IBAN')]/following-sibling::strong");

        public IWebElement hdrBban => _localDriver.FindElementByXPath("//h2[contains(text(),'BBAN')]");

        public IWebElement lblBbanSortCode => _localDriver.FindElementByXPath("//label[contains(text(),'Sort code')]/following-sibling::strong");

        public IWebElement lblBbanAccount => _localDriver.FindElementByXPath("//label[contains(text(),'Account')]/following-sibling::strong");

        public IWebElement imgvalidationChk => _localDriver.FindElementByXPath("//form[@id='formValidationIBAN']//img");

        public IWebElement msgvalidationerrChk => null;

        public IWebElement msgvalidationChk => null;

        public IWebElement imgValidationResult => _localDriver.FindElementByXPath("//h3[@class='content-header']/following-sibling::img");

        public IWebElement lblBranchName => _localDriver.FindElementByXPath("//*[@id='formValidationIBAN']/fieldset[4]/div[1]");

        public IWebElement lblBranchSelection => _localDriver.FindElementByXPath("//label[contains(text(),'Branch')]/following-sibling::select");

        public IWebElement lblAddress1 => _localDriver.FindElementByXPath("//div[@id='branchdata']//div[1]");
        public IWebElement lblAddress2 => _localDriver.FindElementByXPath("//div[@id='branchdata']//div[2]");
        public IWebElement lblAddress3 => _localDriver.FindElementByXPath("//div[@id='branchdata']//div[3]");
        public IWebElement lblAddressTown => _localDriver.FindElementByXPath("//div[@id='branchdata']//div[4]");
        public IWebElement lblAddressCounty => _localDriver.FindElementByXPath("//div[@id='branchdata']//div[5]");
        public IWebElement lblAddressPin => _localDriver.FindElementByXPath("//div[@id='branchdata']//div[6]");
        public IWebElement lblAddressTelephone => _localDriver.FindElementByXPath("//div[@id='branchdata']//div[7]");

    }
}
