﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    // ReSharper disable once InconsistentNaming
    class BWO_VerifyCard
    {

        private readonly RemoteWebDriver _localDriver;

        public BWO_VerifyCard(RemoteWebDriver driver) => _localDriver = driver;

        //Enter the details you want to verify - Section
        
        public IWebElement btnradioVerifyAddressAndCvv => _localDriver.FindElementByXPath("//label[@class='first-field-checkbox']/following-sibling::input[1]");
        
        public IWebElement btnradioVerifyCardHolderDetails => _localDriver.FindElementByXPath("//label[@class='first-field-checkbox']/following-sibling::input[2]");

        //Card details

        public IWebElement checkboxCustPresent => _localDriver.FindElementByXPath("//input[@id='CustPresent']");

        public IWebElement dropdownCardType => _localDriver.FindElementByXPath("//select[@id='CardType']");

        public IWebElement txtCardNumber => _localDriver.FindElementByXPath("//input[@id='CardNumber']");

        public IWebElement txtValidFromMonth => _localDriver.FindElementByXPath("//input[@id='ValidFromMonth']");

        public IWebElement txtValidFromYear => _localDriver.FindElementByXPath("//input[@id='ValidFromYear']");

        public IWebElement txtExpiresMonth => _localDriver.FindElementByXPath("//input[@id='ExpiresMonth']");

        public IWebElement txtSecurityCode => _localDriver.FindElementByXPath("//input[@id='SecurityCode']");

        public IWebElement txtExpiresYear => _localDriver.FindElementByXPath("//input[@id='ExpiresYear']");

        public IWebElement txtIssueNumber => _localDriver.FindElementByXPath("//input[@id='IssueNumber']");

        public IWebElement txtNameOnCard => _localDriver.FindElementByXPath("//input[@id='NameOnCard']");

        //Address details

        public IWebElement txtHouseNumber => _localDriver.FindElementByXPath("//input[@id='HouseNumber']");

        public IWebElement txtFlat => _localDriver.FindElementByXPath("//input[@id='Flat']");

        public IWebElement txtHouseName => _localDriver.FindElementByXPath("//input[@id='HouseName']");

        public IWebElement txtStreet => _localDriver.FindElementByXPath("//input[@id='Street']");

        public IWebElement txtPostCode => _localDriver.FindElementByXPath("//input[@id='PostCode']");

        //Personal details

        public IWebElement txtFirstName => _localDriver.FindElementByXPath("//input[@id='FirstName']");

        public IWebElement txtSurname => _localDriver.FindElementByXPath("//input[@id='Surname']");

        public IWebElement txtDob => _localDriver.FindElementByXPath("//input[@id='Dob']");

        public IWebElement LblValidationSummary(int index) => _localDriver.FindElementByXPath("//*[@id='ValidationSummary']/div/ul/li[" + index + "]");

        //public IWebElement lblValidationSummary1 => _localDriver.FindElementByXPath("//h1[@class='content-header']/following-sibling::div/div/ul");

        public IWebElement lblValidationSummary1 => _localDriver.FindElementByXPath("//div[@class='validation-summary-errors']//ul");

        

        //SubmitCardVerification

        public IWebElement btnSubmitCardVerification => _localDriver.FindElementByXPath("//input[@id='SubmitCardVerification']");

        //Card verification - Result Verificataion (Verify address and CVV)

        //Details verified

        public IWebElement lblCardType => _localDriver.FindElementByXPath("//label[contains(text(),'Card type')]/following-sibling::strong");

        public IWebElement lblCardNumber => _localDriver.FindElementByXPath("//label[contains(text(),'Card number')]/following-sibling::strong");

        public IWebElement lblStartDate => _localDriver.FindElementByXPath("//label[contains(text(),'Start date')]/following-sibling::strong");

        public IWebElement lblExpiryDate=> _localDriver.FindElementByXPath("//label[contains(text(),'Expiry date')]/following-sibling::strong");

        public IWebElement lblIssueNumber => _localDriver.FindElementByXPath("//label[contains(text(),'Issue number')]/following-sibling::strong");

        public IWebElement lblNameOnTheCard => _localDriver.FindElementByXPath("//label[contains(text(),'Name on the card')]/following-sibling::strong");

        public IWebElement lblAddress => _localDriver.FindElementByXPath("//label[contains(text(),'Address')]/following-sibling::strong");

        public IWebElement lblCustomerPresent => _localDriver.FindElementByXPath("//label[contains(text(),'Customer present')]/following-sibling::strong");


        //Verificataion Results
        public IWebElement imgOverallResult => _localDriver.FindElementByXPath("//label[contains(text(),'Overall result')]/following-sibling::div[1]/img[1]");

        public IWebElement lblOverallResult => _localDriver.FindElementByXPath("//label[contains(text(),'Overall Result')]/following-sibling::strong");

        public IWebElement imgMatchingResult => _localDriver.FindElementByXPath("//body/div[@id='wrapper']/div[@id='container']/div[@id='content']/form[@id='formCardVerification']/fieldset/img[1]");

        public IWebElement imgCvvMatch => _localDriver.FindElementByXPath("//label[contains(text(),'CVV match')]/following-sibling::img");
        public IWebElement imgAvsMatch => _localDriver.FindElementByXPath("//label[contains(text(),'AVS match')]/following-sibling::img");

        public IWebElement imgPostCodeMatch => _localDriver.FindElementByXPath("//label[contains(text(),'Post code match')]/following-sibling::img");

        //Card data

        public IWebElement lblType => _localDriver.FindElementByXPath("//label[contains(text(),'Type')]/following-sibling::strong");

        public IWebElement lblSubType => _localDriver.FindElementByXPath("//label[contains(text(),'Sub type')]/following-sibling::strong");

        public IWebElement lblScheme => _localDriver.FindElementByXPath("//label[contains(text(),'Scheme')]/following-sibling::strong");

        public IWebElement lblIssuer => _localDriver.FindElementByXPath("//label[contains(text(),'Issuer')]/following-sibling::strong");

        public IWebElement lblDetails => _localDriver.FindElementByXPath("//label[contains(text(),'Details')]/following-sibling::ul/strong");

        //VERIFY CARD HOLDER DETAILS

        public IWebElement lblCardCheckResult => _localDriver.FindElementByXPath("//label[contains(text(),'Card Check Result')]/following-sibling::strong");

        public IWebElement imgPersonalDetailsScore => _localDriver.FindElementByXPath("//label[contains(text(),'Personal details score')]/following-sibling::img");
        public IWebElement lblAddressMatch => _localDriver.FindElementByXPath("//label[contains(text(),'Address match')]/following-sibling::strong");


    }
}
