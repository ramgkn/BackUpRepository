﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoVerfiyaccount
    {
        private readonly RemoteWebDriver _localDriver;
        public BwoVerfiyaccount(RemoteWebDriver driver) => _localDriver = driver;

        //Enter the details you want to verify section
        public IWebElement radiobtnPersonalAccountCheck => _localDriver.FindElementByXPath("//label[@class='first-field-checkbox']/following-sibling::input[1]");

        public IWebElement radiobtnCompanyAccountCheck => _localDriver.FindElementByXPath("//label[@class='first-field-checkbox']/following-sibling::input[2]");

        public IWebElement radiobtnDirectDebit => _localDriver.FindElementByXPath("//label[contains(text(),'Check context')]//following-sibling::input[1]");

        public IWebElement radiobtnDirectCredit => _localDriver.FindElementByXPath("//label[contains(text(),'Check context')]//following-sibling::input[2]");


        //Account Details
        public IWebElement txtSortCode => _localDriver.FindElementByXPath("//input[@id='SortCode']");

        public IWebElement txtAccountNumber => _localDriver.FindElementByXPath("//input[@id='AccountNumber']");

        //Personal details

        public IWebElement txtFirstName => _localDriver.FindElementByXPath("//input[@id='FirstName']");

        public IWebElement txtSurname => _localDriver.FindElementByXPath("//input[@id='Surname']");

        public IWebElement txtDateOfBirth => _localDriver.FindElementByXPath("//input [@id='Dob']");

        public IWebElement txtHouseNumber => _localDriver.FindElementByXPath("//input [@id='HouseNumber']");

        public IWebElement txtFlat => _localDriver.FindElementByXPath("//input[@id='Flat']");

        public IWebElement txtHouseName => _localDriver.FindElementByXPath("//input[@id='HouseName']");

        public IWebElement txtStreet => _localDriver.FindElementByXPath("//input[@id='Street']");

        public IWebElement txtPostcode => _localDriver.FindElementByXPath("//input[@id='PostCode']");

        //Company details

        public IWebElement txtCompanyname => _localDriver.FindElementByXPath("//label[contains(text(),'Company name')]/following-sibling::input");

        public IWebElement txtCompanytype => _localDriver.FindElementByXPath("//label[contains(text(),'Type')]/following-sibling::select");
        public IWebElement txtRegistrationnumber => _localDriver.FindElementByXPath("//label[contains(text(),'Registration number')]/following-sibling::input");
        public IWebElement txtCompanyBuildingnumber => _localDriver.FindElementByXPath("//label[contains(text(),'Building number')]/following-sibling::input");
        public IWebElement txtCompanyflat => _localDriver.FindElementByXPath("//div[@id='company']//label[contains(text(),'Flat')]/following-sibling::input[1]");
        public IWebElement txtCompanyBuildingname => _localDriver.FindElementByXPath("//div[@id='company']//label[contains(text(),'Flat')]/following-sibling::input[2]");
        public IWebElement txtCompanystreet => _localDriver.FindElementByXPath("//div[@id='company']//label[@class='first-field'][contains(text(),'Street')]/following-sibling::input");
        public IWebElement txtCompanypostcode => _localDriver.FindElementByXPath("//div[@id='company']//label[@class='first-field'][contains(text(),'Postcode')]/following-sibling::input");

        //Proprietor details 

        public IWebElement txtCompanyPropFirstName => _localDriver.FindElementByXPath("//input[@id='CompanyPropFirstName']");

        public IWebElement txtCompanyPropSurname => _localDriver.FindElementByXPath("//input[@id='CompanyPropSurname']");

        public IWebElement txtCompanyPropDob => _localDriver.FindElementByXPath("//input[@id='CompanyPropDob']");

        //Further account details

        public IWebElement txtAccountsetupDateYear => _localDriver.FindElementByXPath("//input[@id='ActY']");

        public IWebElement txtAccountsetupDateMonth => _localDriver.FindElementByXPath("//input[@id='ActM']");

        public IWebElement txtAccountsetupDateDay => _localDriver.FindElementByXPath("//input[@id='ActD']");

        public IWebElement radiobtnSingle => _localDriver.FindElementByXPath("//label[contains(text(),'Owner type')]/following-sibling::input[1]");

        public IWebElement radiobtnJoint => _localDriver.FindElementByXPath("//label[contains(text(),'Owner type')]/following-sibling::input[2]");



        public IWebElement btnVerify => _localDriver.FindElementByXPath("//input[@id='SubmitVerification']");

        


        //Verification results - Personal & Company

        public IWebElement imgbxAccountMatchStatus => _localDriver.FindElementByXPath("//label[@class='match'][contains(text(),'Account match')]/following-sibling::span/img");        

        public IWebElement imgPersonalDetailScore => _localDriver.FindElementByXPath("//label[contains(text(),'Personal details score')]/following-sibling::img");

        public IWebElement imgAddressScore => _localDriver.FindElementByXPath("//label[contains(text(),'Address score')]/following-sibling::img");

        public IWebElement imgAccountSetupDateScore => _localDriver.FindElementByXPath("//label[contains(text(),'Account setup date score')]/following-sibling::img");

        public IWebElement imgbxOwnerTypeMatchStatus => _localDriver.FindElementByXPath("//label[@class='match'][contains(text(),'Owner type')]/following-sibling::span/img");
        
        public IWebElement imgCompanyNameScore => _localDriver.FindElementByXPath("//label[contains(text(),'Company name score')]/following-sibling::img");

        public IWebElement imgCompanyNameAndAddressScore => _localDriver.FindElementByXPath("//label[contains(text(),'Company name and address score')]/following-sibling::img");

        public IWebElement imgCompanyTypeMatchStatus => _localDriver.FindElementByXPath("//label[@class='match'][contains(text(),'Company type')]/following-sibling::span/img");

        public IWebElement imgRegistrationNumberMatchStatus => _localDriver.FindElementByXPath("//label[@class='match'][contains(text(),'Registration number')]/following-sibling::span/img");

        public IWebElement imgProprietorDetailsScore => _localDriver.FindElementByXPath("//label[contains(text(),'Proprietor details score')]/following-sibling::img");

    }
}
