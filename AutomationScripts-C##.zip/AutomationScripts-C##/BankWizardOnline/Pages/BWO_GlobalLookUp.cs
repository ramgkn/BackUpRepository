﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoGlobalLookUp
    {

        private readonly RemoteWebDriver _localDriver;

        public BwoGlobalLookUp(RemoteWebDriver driver) => _localDriver = driver;

        public IWebElement lblCategoryBic => _localDriver.FindElementByXPath("//*[@id='Category0']");

        public IWebElement lblCategoryCountry => _localDriver.FindElementByXPath("//*[@id='Category1']");

        public IWebElement lblCategoryBank => _localDriver.FindElementByXPath("//*[@id='Category2']");

        public IWebElement lblCategoryAddress => _localDriver.FindElementByXPath("//*[@id='Category3']");

        public IWebElement imgvalidationresult => _localDriver.FindElementByXPath("//*[@id='resultpage']/img");

    }
}
