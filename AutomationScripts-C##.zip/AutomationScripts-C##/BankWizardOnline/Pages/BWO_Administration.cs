﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    public class BwoAdministration
    {

        private readonly RemoteWebDriver _driver;

        public BwoAdministration(RemoteWebDriver driver) => _driver = driver;

        public IWebElement tblaccounts => _driver.FindElementByXPath("//table[@id='accounts']");

        public IWebElement hlinkAddagreement => _driver.FindElementByXPath("//a[contains(text(),'Add agreement')]");

        public IWebElement hlinkAddaccount => _driver.FindElementByXPath("//a[contains(text(),'Add account')]");


        public IWebElement HdrWaspaccount (int rowIndex) => _driver.FindElementByXPath("//tr[" + rowIndex + "]//td[1]");

        public IWebElement HdrCompany(int rowIndex) => _driver.FindElementByXPath("//tr[" + rowIndex + "]//td[2]");

        public IWebElement HdrAgreementtype(int rowIndex) => _driver.FindElementByXPath("//tr[" + rowIndex + "]//td[3]");

        public IWebElement HdrFutureagreement(int rowIndex) => _driver.FindElementByXPath("//tr[" + rowIndex + "]//td[4]");

        public IWebElement ImgAgreementstatus(int rowIndex) => _driver.FindElementByXPath("//tr[" + rowIndex + "]//td[5]//img[1]");

        public IWebElement hdraddaccount => _driver.FindElementByXPath("//*[@id='content']/h1");




    }
}
