﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoAdditionalInformation
    {

        private readonly RemoteWebDriver _driver;

        public BwoAdditionalInformation(RemoteWebDriver driver) => _driver = driver;

        public IWebElement btnNewDetails => _driver.FindElementByXPath("//input[@id='newdetails']");
        public IWebElement btnAmendDetails => _driver.FindElementByXPath("//input[@id='amenddetails']");
        public IWebElement btnHelp => _driver.FindElementByXPath("//input[@id='helplink']");

        //Additional Information - Account information 
        public IWebElement imgAccountInformation => _driver.FindElementByXPath("//img[@id='accountInformationimg']");
        public IWebElement LblAccountInformation(int rowIndex) => _driver.FindElementByXPath("//div[@id='accountInformationdiv']//child::tr[ " + rowIndex + "]");
        public IWebElement ValAccountInformation(int rowIndex) => _driver.FindElementByXPath("//div[@id='accountInformationdiv']//child::tr[ " + rowIndex + "]/child::td[2]");


        //Additional Information - SWIFT data
        public IWebElement imgSwiftData => _driver.FindElementByXPath("//img[@id='swiftdataimg']");
        public IWebElement LblSwiftData(int rowIndex) => _driver.FindElementByXPath("//div[@id='swiftdatadiv']//child::tr[ " + rowIndex + "]");
        public IWebElement ValSwiftData(int rowIndex) => _driver.FindElementByXPath("//div[@id='swiftdatadiv']//child::tr[ " + rowIndex + "]/child::td[2]");


        //Additional Information - Faster Payments Data
        public IWebElement imgFasterPaymentsData => _driver.FindElementByXPath("//img[@id='fasterpaymentsdataimg']");
        public IWebElement LblFasterPaymentsData(int rowIndex) => _driver.FindElementByXPath("//div[@id='fasterpaymentsdatadiv']//child::tr[ " + rowIndex + "]");
        public IWebElement ValFasterPaymentsData(int rowIndex) => _driver.FindElementByXPath("//div[@id='fasterpaymentsdatadiv']//child::tr[ " + rowIndex + "]/child::td[2]");

        //Additional Information - Faster Payments Data
        public IWebElement imgSepaData => _driver.FindElementByXPath("//img[@id='sepadataimg']");
        public IWebElement LblSepaData(int rowIndex) => _driver.FindElementByXPath("//div[@id='sepadatadiv']//child::tr[ " + rowIndex + "]");
        public IWebElement ValSepaData(int rowIndex) => _driver.FindElementByXPath("//div[@id='sepadatadiv']//child::tr[ " + rowIndex + "]/child::td[2]");
        public IWebElement imgAdditionalData => _driver.FindElementByXPath("//img[@id='additionaldataimg']");
    }

}
