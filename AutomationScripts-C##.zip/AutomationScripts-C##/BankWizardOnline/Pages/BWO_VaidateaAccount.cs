﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoVaidateaAccount
    {
        private readonly RemoteWebDriver _localDriver;

        public BwoVaidateaAccount(RemoteWebDriver driver) => _localDriver = driver;
     
        public IWebElement dlistCountry => _localDriver.FindElementByXPath("//select[@id='countries']");

        public IWebElement dlistCheckinglevel => _localDriver.FindElementByXPath("//select[@id='checkinglevels']");

                        
        public IWebElement lblBbanAccountnumber => _localDriver.FindElementByXPath("//label[@id='lblBbanAccount number']");

        
        public IWebElement lblBbanBankidentifier => _localDriver.FindElementByXPath("//label[@id='lblBbanBank identifier']");

        
        public IWebElement lblBbanBankcode => _localDriver.FindElementByXPath("//label[@id='lblBbanBank code']");

        public IWebElement lblBbansortcode => _localDriver.FindElementByXPath("//label[@id='lblBbanSort code']");
        
        public IWebElement txtBban1 => _localDriver.FindElementByXPath("//input[@id='Bban1']");
        
        public IWebElement lblBbanBankbranchcode => _localDriver.FindElementByXPath("//label[@id='lblBbanBranch code']");

        public IWebElement lblBbanBankBranchcode => _localDriver.FindElementByXPath("//label[@id='lblBbanBank-branch code']");


        public IWebElement lblBbanAccount => _localDriver.FindElementByXPath("//label[@id='lblBbanAccount']");

        public IWebElement txtBban2 => _localDriver.FindElementByXPath("//input[@id='Bban2']");

        public IWebElement lblBbanCheckdigits => _localDriver.FindElementByXPath("//label[@id='lblBbanCheck digits']");

        public IWebElement lblBbanCheckdigit => _localDriver.FindElementByXPath("//label[@id='lblBbanCheck digit']");

        public IWebElement txtBban3 => _localDriver.FindElementByXPath("//input[@id='Bban3']");     
        
        public IWebElement txtBban4 => _localDriver.FindElementByXPath("//input[@id='Bban4']");        

        public IWebElement btnSubmitValidation => _localDriver.FindElementByXPath("//input[@id='SubmitValidation']");

        public IWebElement imgvalidationChk => _localDriver.FindElementByXPath("//form[@id='formValidation']//img");        


    }
}
