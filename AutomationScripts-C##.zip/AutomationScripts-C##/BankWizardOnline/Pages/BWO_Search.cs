﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoSearch
    {
        private readonly RemoteWebDriver _localDriver;

        public BwoSearch(RemoteWebDriver driver) => _localDriver = driver;


        //Search Request Page

        public IWebElement lblCategorybranch => _localDriver.FindElementByXPath("//*[@id='lblCategorybranch']");

        public IWebElement lblCategoryaddress => _localDriver.FindElementByXPath("//*[@id='lblCategoryaddress']");
        
        public IWebElement lblCategorybic => _localDriver.FindElementByXPath("//*[@id='lblCategorybic']");        

        public IWebElement lblCategoryall => _localDriver.FindElementByXPath("//*[@id='lblCategoryall']");

        public IWebElement lblGermanyall => _localDriver.FindElementByXPath("//*[@id='searchcategories']/ul/li[1]/label");

        public IWebElement lblGermanybic => _localDriver.FindElementByXPath("//*[@id='searchcategories']/ul/li[2]/label");



        public IWebElement txtCategory0 => _localDriver.FindElementByXPath("//input [@id='Category0']");

        public IWebElement txtCategory1 => _localDriver.FindElementByXPath("//input [@id='Category1']");

        public IWebElement txtCategory2 => _localDriver.FindElementByXPath("//input [@id='Category2']");

        public IWebElement txtCategory3 => _localDriver.FindElementByXPath("//input [@id='Category3']");

        public IWebElement txtCategory4 => _localDriver.FindElementByXPath("//select[@id='countries']");

        public IWebElement txtAllSearchInput => _localDriver.FindElementByXPath("//input [@id='AllSearchInput']");

        public IWebElement txtBicSearchInput => _localDriver.FindElementByXPath("//input [@id='BICSearchInput']");

        public IWebElement btnSearch => _localDriver.FindElementByXPath("//input[@class='searchButtonRight searchbutton']");




        //Search Response Page

        public IWebElement imgSearchResult => _localDriver.FindElementByXPath("//*[@id='resultpage']/img");
        public IWebElement valnumberofmathces => _localDriver.FindElementByXPath("//input [@id='SearchMatches']");

    }
}
