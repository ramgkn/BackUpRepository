﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoValidationResultsCheckGeneric
    {
        private readonly RemoteWebDriver _localDriver;

        public BwoValidationResultsCheckGeneric(RemoteWebDriver driver) => _localDriver = driver;

        public IWebElement imgvalidationChk => _localDriver.FindElementByXPath("//h3[contains(text(),'Validation results')]/following-sibling::img");

        public IWebElement msgvalidationChk => _localDriver.FindElementByXPath("//li[@class='report-item-msg']");

        public IWebElement msgvalidationerrChk => _localDriver.FindElementByXPath("//li[@class='report-item error']");

        public IWebElement msgvalidationwarningChk => _localDriver.FindElementByXPath("//li[@class='report-item warning']");

        public IWebElement btAmendDetails => _localDriver.FindElementByXPath("//input[@id='amenddetails']");

        



    }
}
