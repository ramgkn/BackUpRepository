﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace BankWizardOnlineSpecflow.Pages
{
    class BwoPreferences
    {
        private readonly RemoteWebDriver _localDriver;

        public BwoPreferences(RemoteWebDriver driver) => _localDriver = driver;

        public IWebElement BtnradioAccountInformationSection(int displayStatus) => _localDriver.FindElementByXPath("//label[contains(text(),'Account information section')]/following-sibling::input[" + displayStatus + "]");

        public IWebElement BtnradioSwiftDataSection(int displayStatus) => _localDriver.FindElementByXPath("//label[contains(text(),'SWIFT data section')]/following-sibling::input[" + displayStatus + "]");

        public IWebElement BtnradioFasterPaymentsDataSection(int displayStatus) => _localDriver.FindElementByXPath("//label[contains(text(),'Faster Payments data section')]/following-sibling::input[" + displayStatus + "]");

        public IWebElement BtnradioSepaDataSection(int displayStatus) => _localDriver.FindElementByXPath("//label[contains(text(),'SEPA data section')]/following-sibling::input[" + displayStatus + "]");

        public IWebElement BtnradioAdditionalDataSection(int displayStatus) => _localDriver.FindElementByXPath("//label[contains(text(),'Additional data section')]/following-sibling::input[" + displayStatus + "]");

        // ReSharper disable once InconsistentNaming
        public IWebElement BtnSave => _localDriver.FindElementByXPath("//input[@id='SubmitAdmin']");

        // ReSharper disable once InconsistentNaming
        public IWebElement BtnReset => _localDriver.FindElementByXPath("//input[@id='cancel']");







    }
}
